---
name: calculate-astrology
description: Calculate and interpret local, deterministic astrology data from verified birth or event details with a bundled Python engine. Use for Western tropical natal charts, transits, synastry, composites, solar and lunar returns; Vedic/Jyotisha Lahiri D1, D9, supported Parashari vargas through D60, Vimshottari dashas, nakshatras and panchanga; Chinese BaZi/Four Pillars; moon phases and numerology. Require reliable time/location inputs for houses and time-sensitive results, disclose calculation precision, and present interpretation as a reflective tradition rather than scientific or professional advice.
---

# Calculate Astrology

Use the bundled local engine to calculate chart facts before interpreting them. Keep computed facts, traditional interpretation, and user-reported experience visibly separate.

## Non-negotiable rules

1. Never invent a position, house, aspect, dasha date, pillar, or Varga placement.
2. Run `scripts/astro_engine.py` before making chart-specific claims.
3. If calculation fails, report the failure and request the missing or corrected input.
4. State the zodiac, house system, node type, ayanamsha when relevant, engine backend, and birth-time certainty.
5. Treat astrology and BaZi as symbolic or spiritual frameworks, not scientifically validated prediction systems.
6. Keep Western, Vedic, and BaZi logic separate. Compare them only in clearly labeled sections; agreement is thematic overlap, not independent proof.

## Workflow

### 1. Gather verified inputs

For a full timed chart, collect:

- local calendar date;
- exact local clock time and whether it is recorded, rounded, rectified, or unknown;
- birthplace or event place;
- verified latitude and longitude;
- verified IANA timezone, such as `America/New_York`.

If a recorded clock time falls in a daylight-saving fall-back overlap, also
collect `fold: 0` for the first occurrence or `fold: 1` for the second. Do not
choose silently.

Do not guess coordinates, timezone, daylight-saving status, or an absent birth time. Use an available location lookup or ask the user. If time is unknown, omit `hour` and `minute` and set `"time_known": false`.

Still request birthplace or at least its timezone when the clock time is
unknown. It anchors which UTC interval corresponds to the stated civil date.
If the place is also unknown, explain that the uncertainty window is wider.

Birth data is personal. Do not store or reuse it outside the current request without explicit permission.

### 2. Select the smallest appropriate calculation

Read [references/modes.md](references/modes.md) for exact input fields and routing. Prefer one mode that directly answers the question instead of running every system.

Run locally:

```bash
SKILL_DIR="<absolute directory containing this SKILL.md>"
python3 "$SKILL_DIR/scripts/astro_engine.py" --json '{"year":1990,"month":6,"day":15,"hour":14,"minute":30,"lat":40.7128,"lng":-74.006,"tz":"America/New_York","time_known":true,"systems":["western","vedic"]}'
```

Use `--file <path.json>` when the input contains text that would be awkward to quote safely. Never interpolate untrusted user text directly into a shell command.

Do not call the removed MCP, REST, billing, profile-memory, or cloud layers. Do not install packages or access the network merely to improve precision unless the user asks.

### 3. Verify the result before interpretation

Inspect:

- `_meta.engine_backend`: `builtin` or `swisseph`;
- `_meta.precision_note`;
- `time_info.time_known` and any warnings;
- requested mode and system;
- error objects, null angles, or boundary warnings;
- whether the output actually contains the fact you plan to interpret.

The dependency-free backend is approximately 1–2 arcminutes accurate. Swiss Ephemeris, when already installed, improves planetary precision. Neither corrects an inaccurate birth time.

Apply these uncertainty rules:

- Unknown time: withhold Ascendant, angles, houses, Varga Lagna, house-dependent yogas and other time-sensitive conclusions.
- Unknown time: compare planetary output near the beginning and end of the
  verified local date. Interpret only placements stable across that interval;
  list alternatives for anything that changes. If no birthplace/timezone is
  available, do not present boundary-sensitive Sun, Moon, nakshatra, pada, or
  dasha results as settled facts.
- Approximate time: label angle, house and divisional-chart claims as provisional.
- D30, D40, D45 and especially D60: require a recorded time, show the engine warnings, and inspect each `source_boundary_distance_deg`.
- Built-in backend plus `boundary_warning: true`: present both adjacent possibilities or cross-check with a higher-precision calculator.
- Moon near a sign, nakshatra or pada boundary: flag Moon-based dashas and interpretations as sensitive to time and backend.

### 4. Load only the relevant interpretation reference

- Western natal, aspects, transits and returns: [references/western.md](references/western.md)
- Vedic D1/D9/Vargas, dashas, nakshatras and panchanga: [references/vedic.md](references/vedic.md)
- BaZi/Four Pillars: [references/bazi.md](references/bazi.md)
- Synastry, composites and compatibility: [references/synastry.md](references/synastry.md)
- Safety, uncertainty and response style: [references/safety-and-style.md](references/safety-and-style.md)

Always read the safety reference for high-stakes, crisis-adjacent, predictive, relationship-verdict, health, legal, financial, fertility, crime, or gambling questions.

### 5. Answer with a calculation record

Use this compact structure unless the user requests another format:

1. **Calculation basis** — input time/place, time certainty, zodiac/ayanamsha, houses, node choice, backend and precision.
2. **Calculated facts** — the placements or periods directly returned by the engine.
3. **Interpretation** — traditional meaning, tied to named calculated facts.
4. **Uncertainty** — omitted data, boundary sensitivity, school variants and unsupported layers.
5. **Practical reflection** — grounded questions or low-risk actions that preserve agency.

Do not bury a calculation caveat after the interpretation it qualifies.

## Supported calculation routes

The local engine supports:

- `natal`, `transit`, `transit_natal_aspects`;
- `synastry`, `compatibility`, `composite`;
- `solar_return`, `lunar_return`, `event`;
- `navamsa`, `varga`, `panchang`;
- `moon_phase`, `numerology`.

Do not route requests to the bundled upstream implementations of
`astrocartography`, `horary`, `planetary_return`, `planetary_hours`, or
`progressions`. They are deliberately disabled because their methods have not
met this skill's reliability threshold. For a neutral horary-style moment
chart, use `event` without generating a verdict.

Supported Varga codes are D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, D16, D20, D24, D27, D30, D40, D45 and D60. Do not claim that every integer division between D2 and D60 is implemented.

Vedic natal output includes a limited, mechanically detected yoga list. Describe it as non-exhaustive. The Atmakaraka uses the seven-karaka method excluding Rahu and Ketu. BaZi element strength and favorable elements are simplified heuristics, not a complete professional Yong Shen determination.

The compatibility score is an internal geometric heuristic. Never present it as an objective probability, relationship verdict, or reason to begin or end a relationship; emphasize the actual contacts and themes instead.

## Safety boundary

Do not use chart output to:

- diagnose illness, select or delay surgery, prescribe diets/supplements, or forecast recovery;
- predict pregnancy, fertility, death, violence, disasters, crimes, perpetrators or missing-person locations;
- decide investments, gambling, lawsuits, elections, employment, housing, contracts or other high-stakes outcomes;
- confirm infidelity, curses, evil eyes, possession, paranoia or unusual beliefs as facts;
- promise exact events, guaranteed outcomes, or an exact date when suffering will end.

For those requests, acknowledge the user’s concern, keep any astrology discussion explicitly reflective, and direct the real-world decision to appropriate evidence and qualified help. In an immediate safety or health crisis, stop the reading and prioritize emergency or professional support.

Never use fatalistic language. Prefer “this tradition associates…” and “a possible reflective theme is…” over “this will happen.”

## Failure handling

- Missing date: request it.
- Known time without coordinates or timezone: request verified values; do not fall back to Greenwich or a guessed offset.
- Invalid timezone: request a valid IANA timezone.
- Unknown time: rerun with `"time_known": false`; do not fabricate noon houses.
- Unsupported Varga: report the supported list.
- Engine error or empty field: do not substitute remembered astrology data.

## Provenance

This adaptation uses the MIT-licensed local engine from `aryaminus/astro`, with the network layers removed and reliability changes for unknown times, D9 Lagna, Parashari Varga rules, boundary warnings and safer interpretation. See [references/source-and-license.md](references/source-and-license.md) and `LICENSE`.
