#!/usr/bin/env node

import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { castAll } from './runtime/cast.mjs';
import { vedicMd } from './runtime/md/format.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const birth = {
  date: '1990-06-15', time: '14:30', lat: 40.7128, lon: -74.006,
  tz: 'America/New_York', place: 'New York',
};
const cast = castAll(birth);

assert.equal(cast.meta.houseSystem, 'whole-sign');
assert.equal(cast.vedic.ascendant.signName, 'Virgo');
assert.equal(cast.vedic.vargas.D9.asc.signName, 'Gemini');
assert.equal(cast.vedic.vargas.D60.moon.signName, 'Aries');
assert.equal(Object.keys(cast.vedic.vargas).length, 22);
assert.equal(cast.vedic.karakas.byKaraka.AK, 'venus');
assert.equal(cast.vedic.ashtakavarga.sav.length, 12);
assert.ok(cast.vedic.arudhas.A1);
assert.ok(cast.vedic.dashas.length >= 9);
assert.ok(cast.jaimini.charaDasha.majors.length === 24);
assert.ok(cast.panchanga.tithi.label);
assert.ok(cast.nakshatras.moon.name);
assert.ok(cast.hd.type);
assert.ok(cast.matrix.points.E);

const md = vedicMd(cast, { name: 'Fixture' }, { vargas: ['D1', 'D9', 'D10', 'D60'] });
for (const heading of ['Vimshottari dasha', 'Chara karakas', 'Arudha lagnas', 'Ashtakavarga', 'Chara Dasha', 'Rashi drishti', 'Nakshatra']) {
  assert.ok(md.includes(heading), `Markdown missing ${heading}`);
}

const cli = spawnSync(process.execPath, [join(here, 'calculate.mjs'), '--date', birth.date, '--time', birth.time,
  '--lat', String(birth.lat), '--lon', String(birth.lon), '--tz', birth.tz, '--view', 'json'], { encoding: 'utf8' });
assert.equal(cli.status, 0, cli.stderr);
assert.equal(JSON.parse(cli.stdout).vedic.vargas.D10.sun.signName, 'Gemini');

const unknown = castAll({ ...birth, time: null, timeUnknown: true });
assert.equal(unknown.hd, null);
assert.equal(unknown.meta.noonCast, true);
assert.ok(unknown.meta.caveats.length > 0);

process.stdout.write('Portable calculator self-test passed.\n');
