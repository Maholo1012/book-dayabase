---
name: chart-desk-calculator
description: Calculate local, deterministic spiritual-system charts from birth data with no API or network connection. Use for Vedic/Jyotish natal charts, D1/D9/D10/D60 and other divisional charts, Vimshottari dashas, Jaimini calculations, panchanga, ashtakavarga, arudhas, aspects, nakshatras, Human Design mechanics and bodygraphs, Matrix of Destiny charts, tropical positions, structured JSON, Markdown reports, or SVG chart graphics.
---

# Chart Desk Calculator

Calculate chart data locally with the bundled Node.js runtime. Treat the runtime as a calculator, not an interpretive authority.

## Workflow

1. Collect the local birth date, exact local birth time, latitude, longitude, and IANA time zone. Preserve the birthplace label when available.
2. If the time is unknown, pass `--time-unknown`. Never invent or approximate a time.
3. Read [conventions-and-limits.md](references/conventions-and-limits.md) before the first calculation in a conversation or whenever accuracy, unknown-time handling, calculation conventions, or unsupported features matter.
4. Run `node scripts/calculate.mjs` from this skill directory. Use [usage.md](references/usage.md) for command examples.
5. Prefer JSON when another agent or workflow will consume the data. Prefer Vedic Markdown or a focused report for human review. Generate SVG only when the user asks for a visual chart.
6. Check `meta.caveats`, `meta.timeUnknown`, calculation conventions, and requested chart coverage before presenting results.
7. Separate source-calculated facts from interpretations. Label interpretive statements and avoid guaranteed predictions.

## Output selection

- Use `--view vedic` for a readable Jyotish report containing placements, selected vargas, panchanga, Vimshottari, karakas, arudhas, ashtakavarga, Jaimini layers, strength, and aspects.
- Use `--view json` for the complete structured result.
- Use `--view dashas` for a focused Vimshottari timeline.
- Use `--view human-design` or `human-design-svg` for Human Design mechanics or a bodygraph.
- Use `--view matrix` or `matrix-svg` for Matrix of Destiny.
- Use `--view atlas` for Vedic, Human Design, and Matrix in one Markdown pack.
- Use `--view varga-svg --varga N --style north|south` for a Vedic chart graphic.
- Use `--view tropical-svg` for a tropical wheel.

## Guardrails

- Require coordinates and an IANA time zone; a place name alone is insufficient for the local runtime.
- Stay within the validated 1700–2100 date range.
- State that Vedic results use Lahiri ayanamsa, whole-sign houses, and mean nodes.
- Do not claim D40 support. Use `node scripts/calculate.mjs --list-vargas` to inspect the supported set.
- With an unknown birth time, prominently disclose the noon cast and do not treat Ascendant, houses, vargas, arudhas, exact timing, panchanga, or Human Design as verified.
- Do not silently replace conflicting chart data supplied by the user. Show the discrepancy and compare conventions first.
- Do not present symbolic-system output as scientific proof, diagnosis, or professional advice.

## Verification

Run `node scripts/self-test.mjs` after moving, editing, or repairing this skill. Review [credits-and-licenses.md](references/credits-and-licenses.md) before redistributing modified runtime files.
