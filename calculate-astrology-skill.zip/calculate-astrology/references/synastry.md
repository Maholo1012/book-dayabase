# Relationship-chart guide

Synastry compares two natal skies. A composite chart uses midpoints to
symbolize the relationship as its own pattern. Neither measures love,
compatibility, consent, honesty, abuse, or the future of a relationship.

## Workflow

1. State each person's time certainty.
2. If either time is unknown, omit angle and house comparisons and flag the
   Moon as potentially approximate.
3. Start with mutual Sun, Moon, Mercury, Venus, and Mars contacts.
4. Add Saturn for commitment, limits, or pressure and Jupiter for confidence or
   growth.
5. Describe both a constructive expression and a friction point.
6. Translate the pattern into a conversation prompt or observable behavior.

## High-value pairings

| Contact | Reflective topic |
|---|---|
| Sun–Moon | Identity and emotional rhythm |
| Moon–Moon | Emotional pacing and comfort |
| Mercury–Mercury | Communication and interpretation |
| Venus–Mars | Attraction, affection, and desire style |
| Saturn to personal planets | Reliability, inhibition, duty, or endurance |
| Jupiter to personal planets | Encouragement, excess, meaning, or growth |

An aspect can be lived in many ways. Squares and oppositions are not automatic
failure; trines and conjunctions are not automatic success.

## Compatibility score

The score is an internal weighting of selected aspects. If the user asks for
it, label it “experimental geometry score,” show the underlying contacts, and
do not convert it into a probability or recommendation. Never advise someone
to stay, leave, trust, distrust, marry, or avoid another person because of it.

## Composite chart

Reliable times are required because the bundled composite includes angles and
houses. Read it as a symbolic description of the relationship dynamic, not as
a third person's literal fate.
