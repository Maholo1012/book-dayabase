# Book Database — Instructions and Templates

Version: 1.0

## Quick reference

**Required:** a GitHub account, web browser, and extracted starter folder. Use a computer for the initial folder upload.

**Run command:** none. Version 1 has no scripts to install or run.

**Expected result:** your public repository displays the book catalog, and the sample link opens a downloadable TXT file.

## 1. Extract the starter

1. Download `book-database-starter.zip`.
2. On Windows, right-click it, select **Extract All…**, then **Extract**. On Mac, double-click it.
3. Open the extracted `book-database-starter` folder. Some extractors create an extra enclosing folder; open the folder that directly contains `README.md`, the two numbered guides, `books`, and `catalog`.

Upload the contents of this folder. Uploading the ZIP by itself will leave a ZIP file on GitHub rather than an unpacked catalog.

## 2. Create the GitHub repository

1. Sign in at [GitHub](https://github.com/).
2. Open [New repository](https://github.com/new).
3. Select your personal account under **Owner**.
4. Enter `book-database` under **Repository name**. If that name is already used in your account, choose another name.
5. Optional description: `A browsable book collection with a CSV inventory.`
6. Select **Public** for visibility.
7. Leave the initialization options for README, .gitignore, and license off; this starter already has a README, and each book has its own sharing terms.
8. Click **Create repository**.

## 3. Upload the starter contents

1. On the empty repository's Quick Setup page, click **uploading an existing file**. If the repository already contains files, use **Add file → Upload files**.
2. Open your extracted starter folder in File Explorer or Finder.
3. Select its contents: the three Markdown files, the `books` folder, and the `catalog` folder.
4. Drag those selected items into GitHub's upload area. Drag the contents, not the enclosing `book-database-starter` folder.
5. Inspect the upload paths. They should include `README.md`, `catalog/books.csv`, and `books/reference/starter_sample_v1.txt`. They should not start with `book-database-starter/`.
6. Enter the commit message `Add book database starter`.
7. Save the upload using **Commit changes** or **Propose changes**, whichever GitHub shows. For a new personal repository, save to the default branch if offered. If GitHub creates a pull request instead, open it and merge it to publish the files on the default branch.
8. Return to the repository's main **Code** page. Your README catalog should appear below the file list.

If your browser cannot drag folders, upload the three root Markdown files first. Then choose **Add file → Create new file**, enter `catalog/books.csv` as the filename, paste the starter CSV contents, and save. Repeat for `books/reference/starter_sample_v1.txt`. Including slashes in the filename creates the folder path.

## 4. Test before adding books

1. Click **Open sample** in the README table.
2. Confirm that the file contains `A TINY BOOKSHELF`.
3. Use **Download raw file** (the download icon) to save the sample. Open the downloaded file and confirm the same heading.
4. Copy your repository's address from the browser.
5. Open it in a private/incognito window while signed out. Confirm the catalog and sample are accessible.

Expected repository address: `https://github.com/YOUR-USERNAME/book-database`.
`YOUR-USERNAME` is a placeholder; share the actual address from your browser.

## 5. Add your first book

Start with a file no larger than 25 MiB for browser upload. PDF, EPUB, TXT, and MD are suitable storage formats; an EPUB may need to be downloaded and opened in an ebook reader.

1. Give the file a clear name, such as `author_short_title_v1.pdf`.
2. In your GitHub repository, open `books`, then `reference`.
3. Click **Add file → Upload files**.
4. Choose your book and save with a message such as `Add first reference book`.
5. Open the uploaded file and verify the path: `books/reference/author_short_title_v1.pdf`.

To create another subject folder, select **Add file → Create new file** at the repository root. Enter `books/astrology/KEEP.txt`, type `Book files for this subject go here.`, and save. Open `books/astrology` and upload your book there. The small placeholder keeps the new folder present; you can delete it after adding a book.

## 6. Add the CSV inventory entry

1. Open `catalog/books.csv` on GitHub.
2. Click the pencil icon (**Edit this file**).
3. Add one line below the sample using the existing column order.
4. Keep the header line unchanged and save the edit.

| Column | What to enter |
| --- | --- |
| `id` | Next unused ID, such as `BOOK-002` |
| `title` | Actual title |
| `author` | Actual author |
| `year` | Edition/publication year, or blank |
| `subject` | Main subject, such as `astrology` |
| `tags` | Semicolon-separated search terms |
| `format` | `PDF`, `EPUB`, `TXT`, or `MD` |
| `file_path` | Exact repository path, or blank for external links |
| `external_url` | Authorized HTTPS access link, or blank for uploaded files |
| `sharing_basis` | Why this edition can be shared, or `authorized-link` |
| `permission_source` | License/permission reference, source URL, or explanation |
| `notes` | Edition, language, scan status, or other useful details |

Copyable example — replace the fictional values with your book's actual details:

```csv
BOOK-002,My Study Handbook,Your Name,2026,reference,study;reference,PDF,books/reference/my_study_handbook_v1.pdf,,own-work,Written by me and approved for public sharing,English
```

A title containing a comma must be wrapped in double quotes: `"Crystals, Color, and Care"`. For a literal double quote inside a quoted field, use two double quotes. Keep each record on a single line in this beginner version.

For an external book, leave `file_path` empty, put the authorized link in `external_url`, and use `authorized-link` as the sharing basis. Link to a publisher or authorized source; check its access requirements.

## 7. Add the clickable README entry

1. Return to the root and open `README.md`.
2. Click **Edit this file**.
3. Add a row below the sample row in the book catalog table.
4. Use this template, replacing all fictional details:

```markdown
| BOOK-002 | My Study Handbook | Your Name | Reference | PDF | [Open book](books/reference/my_study_handbook_v1.pdf) |
```

5. Save, then click the new link to verify it.

For an external book, replace the path inside parentheses with its authorized HTTPS URL. Paths in this table are relative to the root README; do not add `../` before `books/`.

## 8. Share access

Send readers your repository's actual URL. They can browse the catalog and download a book from its file page. Test the link on another device before sending a whole collection.

To download the collection as a ZIP, open the repository's **Code** menu and choose **Download ZIP**.

## Troubleshooting

| Problem | Likely cause | Exact fix |
| --- | --- | --- |
| Only a ZIP appears | Archive was uploaded without extraction | Extract locally, then upload its contents with folder paths preserved |
| No landing-page catalog | README ended up inside an extra folder | Upload `README.md` to the root and preserve the documented root layout |
| Book link returns 404 | Path or capitalization differs | Compare the file's GitHub path with the README link and CSV entry; correct both |
| CSV columns shift | A field has an unquoted comma | Put double quotes around that entire field |
| CSV changes do not appear in the README | The catalogs are maintained separately | Update the README table too |
| Browser rejects the book | File exceeds the upload limit | Keep a smaller suitable copy or use an authorized external link |
| EPUB does not preview | Browser lacks an ebook preview | Download and open it in an EPUB reader |
| External link asks for permission | Destination has restricted access | Adjust sharing if you control it and have permission, or use an authorized public source |
| Reader cannot access repository | Visibility is private or URL is wrong | Verify Public visibility and copy the actual repository address |

## Larger files

GitHub's browser uploader allows up to **25 MiB per file** and **100 files per upload**. Ordinary Git uploads allow files up to **100 MiB**; larger files need Git LFS. For Version 1, the simplest route for large books is an authorized external link. Git LFS setup and storage/bandwidth allowances are a later upgrade.

## Final checklist

- [ ] Root README displays correctly.
- [ ] Original sample download works.
- [ ] First book opens/downloads.
- [ ] Its CSV row and README link agree.
- [ ] Sharing basis is recorded.
- [ ] Intended readers can access the repository and any external link.

Next upgrade: generate the README table from the CSV so each book only needs one metadata edit.

## Sources

GitHub interface and upload guidance checked October 2, 2026. Button wording may vary with the repository's branch settings.

- [Create a repository](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)
- [Upload files and size limits](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
- [View raw content and download files](https://docs.github.com/en/repositories/working-with-files/using-files/viewing-and-understanding-files)
