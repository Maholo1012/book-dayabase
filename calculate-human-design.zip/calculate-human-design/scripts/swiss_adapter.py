#!/usr/bin/env python3
"""Swiss Ephemeris swetest adapter with ZIP extraction and strict fallback detection."""

from __future__ import annotations

import re
import stat
import subprocess
import tempfile
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path


class SwissEphemerisError(RuntimeError):
    pass


def _segment_code(year: int) -> str:
    start = (year // 600) * 600
    century = abs(start) // 100
    return f"m{century:02d}" if start < 0 else f"{century:02d}"


class SwissRuntime:
    def __init__(
        self,
        *,
        archive: str | Path | None = None,
        swetest: str | Path | None = None,
        ephe_dir: str | Path | None = None,
        years: tuple[int, ...] = (),
    ) -> None:
        self.archive = Path(archive).expanduser().resolve() if archive else None
        self.swetest = Path(swetest).expanduser().resolve() if swetest else None
        self.ephe_dir = Path(ephe_dir).expanduser().resolve() if ephe_dir else None
        self.years = years
        self._temp: tempfile.TemporaryDirectory[str] | None = None
        self.version = "unknown"

    def __enter__(self) -> "SwissRuntime":
        if self.archive:
            self._prepare_archive()
        if not self.swetest or not self.swetest.is_file():
            raise SwissEphemerisError("A working swetest binary or Swiss Ephemeris ZIP is required")
        if not self.ephe_dir or not self.ephe_dir.is_dir():
            raise SwissEphemerisError("An ephemeris directory or Swiss Ephemeris ZIP is required")
        completed = subprocess.run(
            [str(self.swetest), "-h"], check=False, capture_output=True, text=True
        )
        match = re.search(
            r"\bversion\s*:\s*([0-9][^\s]*)",
            completed.stdout + completed.stderr,
            re.IGNORECASE,
        )
        if match:
            self.version = match.group(1).rstrip(",;")
        return self

    def __exit__(self, *_exc: object) -> None:
        if self._temp:
            self._temp.cleanup()

    def _prepare_archive(self) -> None:
        assert self.archive is not None
        if not self.archive.is_file() or not zipfile.is_zipfile(self.archive):
            raise SwissEphemerisError(f"Not a readable Swiss Ephemeris ZIP: {self.archive}")
        self._temp = tempfile.TemporaryDirectory(prefix="human-design-swiss-")
        root = Path(self._temp.name)
        segments = {_segment_code(year) for year in self.years} or {"18"}
        with zipfile.ZipFile(self.archive) as bundle:
            names = bundle.namelist()
            binary_name = next((n for n in names if n.endswith("/bin/swetest")), None)
            if not binary_name:
                raise SwissEphemerisError("The ZIP does not contain bin/swetest")
            selected = [binary_name]
            for segment in sorted(segments):
                for prefix in ("sepl", "semo"):
                    suffix = f"/ephe/{prefix}_{segment}.se1"
                    match = next((n for n in names if n.endswith(suffix)), None)
                    if not match:
                        raise SwissEphemerisError(f"The ZIP lacks {prefix}_{segment}.se1")
                    selected.append(match)
            for optional in ("/ephe/seleapsec.txt", "/ephe/seorbel.txt"):
                match = next((n for n in names if n.endswith(optional)), None)
                if match:
                    selected.append(match)
            for member in selected:
                relative = (
                    Path("bin/swetest")
                    if member == binary_name
                    else Path("ephe") / Path(member).name
                )
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                with bundle.open(member) as source, target.open("wb") as destination:
                    while chunk := source.read(1024 * 1024):
                        destination.write(chunk)
        binary = root / "bin" / "swetest"
        binary.chmod(binary.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        self.swetest = binary
        self.ephe_dir = root / "ephe"

    @staticmethod
    def _utc_parts(moment: datetime) -> tuple[str, str]:
        if moment.tzinfo is None:
            raise SwissEphemerisError("Datetime must be timezone-aware")
        moment = moment.astimezone(timezone.utc)
        date = f"{moment.day}.{moment.month}.{moment.year}"
        seconds = moment.second + moment.microsecond / 1_000_000.0
        time = f"{moment.hour:02d}:{moment.minute:02d}:{seconds:09.6f}"
        return date, time

    def _run(
        self,
        moment: datetime,
        sequence: str,
        *extra_flags: str,
    ) -> str:
        assert self.swetest is not None and self.ephe_dir is not None
        date, time = self._utc_parts(moment)
        command = [
            str(self.swetest),
            f"-b{date}",
            f"-utc{time}",
            f"-p{sequence}",
            "-fPls",
            "-g,",
            "-head",
            "-eswe",
            "-speed",
            "-ep",
            f"-edir{self.ephe_dir}",
            *extra_flags,
        ]
        completed = subprocess.run(command, check=False, capture_output=True, text=True)
        combined = completed.stdout + "\n" + completed.stderr
        if completed.returncode != 0:
            raise SwissEphemerisError(combined.strip() or "swetest failed")
        if re.search(r"not found|fallback|moshier|warning", combined, re.IGNORECASE):
            raise SwissEphemerisError("Swiss Ephemeris file fallback detected: " + combined.strip())
        return completed.stdout

    def positions(self, moment: datetime, *, node: str = "true") -> tuple[dict[str, float], dict[str, float]]:
        if node not in {"true", "mean"}:
            raise SwissEphemerisError("node must be 'true' or 'mean'")
        planet_output = self._run(moment, "0123456789")
        node_output = self._run(
            moment,
            "t" if node == "true" else "m",
            "-true",
            "-noaberr",
            "-nodefl",
        )
        name_map = {
            "Sun": "Sun",
            "Moon": "Moon",
            "Mercury": "Mercury",
            "Venus": "Venus",
            "Mars": "Mars",
            "Jupiter": "Jupiter",
            "Saturn": "Saturn",
            "Uranus": "Uranus",
            "Neptune": "Neptune",
            "Pluto": "Pluto",
            "true Node": "NorthNode",
            "mean Node": "NorthNode",
        }
        longitudes: dict[str, float] = {}
        speeds: dict[str, float] = {}
        for line in (planet_output + "\n" + node_output).splitlines():
            parts = [part.strip() for part in line.split(",")]
            if len(parts) != 3 or parts[0] not in name_map:
                continue
            name = name_map[parts[0]]
            longitudes[name] = float(parts[1]) % 360.0
            speeds[name] = float(parts[2])
        expected = {"Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto", "NorthNode"}
        missing = sorted(expected - set(longitudes))
        if missing:
            raise SwissEphemerisError("Could not parse swetest output for: " + ", ".join(missing))
        longitudes["Earth"] = (longitudes["Sun"] + 180.0) % 360.0
        longitudes["SouthNode"] = (longitudes["NorthNode"] + 180.0) % 360.0
        speeds["Earth"] = speeds["Sun"]
        speeds["SouthNode"] = speeds["NorthNode"]
        ordered = ("Sun", "Earth", "NorthNode", "SouthNode", "Moon", "Mercury", "Uranus", "Venus", "Mars", "Neptune", "Saturn", "Jupiter", "Pluto")
        return ({name: longitudes[name] for name in ordered}, {name: speeds[name] for name in ordered})

    def sun_longitude(self, moment: datetime) -> float:
        output = self._run(moment, "0")
        for line in output.splitlines():
            parts = [part.strip() for part in line.split(",")]
            if len(parts) == 3 and parts[0] == "Sun":
                return float(parts[1]) % 360.0
        raise SwissEphemerisError("Could not parse swetest output for Sun")

    def design_time(self, birth_utc: datetime, *, tolerance_seconds: float = 0.25) -> datetime:
        if birth_utc.tzinfo is None:
            raise SwissEphemerisError("Birth datetime must be timezone-aware")
        birth_utc = birth_utc.astimezone(timezone.utc)
        birth_sun = self.sun_longitude(birth_utc)
        target = (birth_sun - 88.0) % 360.0
        lower = birth_utc - timedelta(days=110)
        upper = birth_utc - timedelta(days=70)

        def signed_error(moment: datetime) -> float:
            return ((self.sun_longitude(moment) - target + 180.0) % 360.0) - 180.0

        low_error, high_error = signed_error(lower), signed_error(upper)
        if not (low_error <= 0 <= high_error):
            raise SwissEphemerisError("Could not bracket the 88-degree design date")
        while (upper - lower).total_seconds() > tolerance_seconds:
            middle = lower + (upper - lower) / 2
            if signed_error(middle) < 0:
                lower = middle
            else:
                upper = middle
        return lower + (upper - lower) / 2


def runtime_years(*moments: datetime) -> tuple[int, ...]:
    years = {moment.astimezone(timezone.utc).year for moment in moments}
    years |= {year - 1 for year in years}
    return tuple(sorted(years))
