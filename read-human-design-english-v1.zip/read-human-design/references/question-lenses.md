# Human Design Question Lenses

## Universal interpretation pattern

Use three layers for every material conclusion:

1. **Chart fact:** Identify the calculated type, authority, center, channel, or other field supporting the point.
2. **Possible experience:** Use language such as *may*, *might*, *can be prone to*, or *worth observing*. Do not write interpretations as fixed personality facts.
3. **Reality check:** Give a question or tracking method capable of disproving the interpretation.

Also state what the chart does **not** establish. Projector does not mean "cannot be an entrepreneur"; Emotional Authority does not mean "irrational"; an open Ego does not mean "no willpower."

When a user asks for a definitive answer such as "Am I suited to this?", "Should I quit?", or "Should I end the relationship?", explain at the beginning that the chart cannot establish that outcome. Then offer decision-process hypotheses the user can test.

Keep practical evidence separate from chart interpretation. It is appropriate to mention cash flow, market demand, safety, communication, or qualified advice. Do not invent universal numerical thresholds such as a required number of clients or months of savings. Use numbers only when grounded in the user's actual situation, calculations, or a clearly identified professional source.

## General self-understanding

Do not list every planet in order. Organize the reading around five questions:

1. Under what conditions do I enter major experiences? — Type and Strategy
2. How do I reach my own answer among several options? — Authority
3. How do I learn, experiment, form relationships, and receive projections? — Profile
4. Which energy or expression patterns are relatively consistent? — Defined channels and centers
5. Where might I absorb or amplify context? — Undefined centers

Develop only three to five points most relevant to the user's current life. Place remaining fields under a brief "possible future exploration" note.

## Work direction

Human Design does not generate a career title from a type or gate. Translate "Which career should I choose?" into:

- How do opportunities enter my life?
- How might I avoid agreeing too quickly under pressure?
- Which patterns around sustainable output, focus, expression, leadership, or resources appear consistent?
- What pace, environment, and collaboration boundaries may be worth testing?
- Which evidence is still missing: skills, market demand, income, transition cost, portfolio feedback?

Offer two or three **work-condition hypotheses**, not career prescriptions. Attach a practical test to each, such as comparing self-initiated work with responding to a real request during a two-week project.

## Entrepreneurship

Start with the limit: every Human Design type can become an entrepreneur, and a chart cannot establish whether someone should start a business or leave a job.

When asked whether to resign, say that the available information is insufficient unless paid demand, delivery capacity, cash flow, family obligations, benefits loss, and risk tolerance are known. Suggest reversible tests that do not require changing employment status.

Consider in order:

1. **Opportunity entry:** Is the user responding to real demand, receiving recognition/invitation, or mainly escaping discomfort?
2. **Decision process:** How should major partnerships, pricing, hiring, investment, and launches pass through the calculated Authority?
3. **Sustainable energy:** Is short-term energy borrowed from people or context being mistaken for lasting capacity? Are rest, decisions, and output separated?
4. **Team and expression:** Which channels suggest stable themes around expression, guidance, resources, rhythm, or depth? How might recognition, response, information, or clarity affect them?
5. **Business evidence:** Customer interviews, willingness to pay, delivery cost, cash flow, and legal risk remain necessary and cannot be replaced by the chart.

Optional experiment: For 14 days, log each important business commitment, what triggered it, the Authority process, bodily or emotional signals, later impressions, and the one-week result. Later review supports learning; it does not create one universal waiting period.

## Intimate relationships

Do not use one person's chart to diagnose another person. Do not treat two types as a compatibility score or recommend marriage or separation based on a chart.

For a single-person relationship question, examine:

- Whether major commitments passed through the user's actual Strategy and Authority.
- Whether undefined Emotional, Ego, G, Splenic, or Throat centers coincide with people-pleasing, proving, identity attachment, fear of release, or attention-seeking.
- How the Profile's themes of network, retreat, experimentation, projection, or life stages appear in relationships.
- Which channels may support hypotheses about communication, intimacy, community agreements, independence, or emotional rhythm.

With two complete charts, compare each person's Strategy and Authority and the time each may need around the same decision. Do not claim electromagnetic, compromise, dominance, or companionship channel dynamics unless a validated connection-chart engine was actually run.

Relationship experiments must be mutual, consensual, and stoppable. For example, each person can process one meaningful choice according to their own Authority and then compare answers. Do not require all Authorities to delay their response.

## Ending a focused answer

Conclude with:

- **One hypothesis most worth testing now**
- **One reversible action**, such as logging, interviewing, trying a small pilot, delaying a commitment when the calculated Authority supports it, or clarifying a boundary
- **One falsification condition:** a real-world result that would indicate the interpretation is not useful
