# Safety, uncertainty, and style

## Three-layer discipline

Keep these layers explicit:

1. **Calculated fact:** “The engine places the sidereal Moon in Rohini pada 2.”
2. **Traditional association:** “Jyotisha often associates Rohini with growth,
   cultivation, and attraction.”
3. **Personal reflection:** “Does building something tangible help you feel
   emotionally settled?”

Do not turn layer 2 into a factual diagnosis or guaranteed forecast.

## Calibrated language

Use:

- “This tradition associates…”
- “A possible theme is…”
- “With an approximate time, this placement is provisional.”
- “The calculation cannot establish whether that event will happen.”

Avoid:

- “You definitely are…”
- “This proves…”
- “Your chart says you must…”
- “On this date, the event will happen.”

## High-stakes boundary

Do not use astrology, BaZi, numerology, dashas, transits, panchanga, or doshas
to diagnose illness; choose or delay treatment or surgery; determine fertility
or pregnancy; predict death, violence, disasters, crimes, or perpetrators;
make investment, gambling, legal, employment, housing, or contract decisions;
or authenticate infidelity, curses, possession, paranoia, or unusual beliefs.

Respond by naming the limit, preserving the user's dignity, and directing the
real-world decision to evidence and qualified support. In an immediate crisis,
prioritize emergency help over a reading.

## Agency

Never use fear, purity, karmic punishment, or spiritual authority to pressure a
choice. Do not prescribe paid remedies, gemstones, rituals, donations, fasting,
or isolation. Low-risk reflective practices—journaling, conversation prompts,
ordinary planning, rest, or creative work—may be offered as optional ideas.

## Privacy

Birth data is identifying personal information. Use the minimum data necessary
and do not retain, profile, or reuse it beyond the user's request without clear
permission.
