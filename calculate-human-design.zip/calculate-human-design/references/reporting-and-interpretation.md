# Reporting and Interpretation

## Recommended report order

1. State the verified input moment in UTC and the node choice.
2. State the calculation route and rules version.
3. Present the six core mechanics: type, strategy, authority, profile, definition, and incarnation cross.
4. List defined and undefined centers and active channels.
5. Present variables and planetary activations only when useful to the user's question.
6. Surface precision warnings and, for uncertain times, stable versus changing fields.
7. Add interpretation only from user-approved or clearly identified references.

## Language boundary

Separate these categories explicitly:

- **Calculated:** “The supplied longitude maps to Gate 38, line 1 under this wheel convention.”
- **Convention-derived:** “Both channel endpoints are active, so the Root and Spleen are defined in this graph.”
- **Interpretive:** “Some Human Design schools associate this pattern with …”

Use tentative, reflective phrasing for interpretations. Do not present themes as diagnoses, objective personality measurements, destiny, relationship verdicts, or reasons to ignore evidence and professional advice.

## Source discipline

- Cite the rules source and version when describing mechanics.
- If the user requests meanings, ask which school or source to use when materially different interpretations could change the result.
- Do not manufacture gate, line, channel, cross, variable, or fixation meanings from numeric output.
- If no interpretation reference is supplied or available, provide the verified mechanics and offer a question-oriented reflection rather than authoritative meaning.

## Useful uncertainty phrasing

- “This field remains the same across all sampled times.”
- “This field changes within the stated interval; the reported weight is an algorithmic estimate from the selected scan method.”
- “This activation is near a line boundary, so small input or ephemeris differences may change the line.”
- “The exact time is insufficiently resolved for a confident substructure claim.”
