#!/usr/bin/env python3
"""Dependency-free Human Design mechanics derived from SharpAstrology.HumanDesign 1.2.0."""

from __future__ import annotations

import json
import math
from collections import deque
from pathlib import Path
from typing import Any, Iterable, Mapping


SKILL_ROOT = Path(__file__).resolve().parent.parent
RULES_PATH = SKILL_ROOT / "assets" / "hd_rules.json"

PLANETS = (
    "Sun",
    "Earth",
    "NorthNode",
    "SouthNode",
    "Moon",
    "Mercury",
    "Uranus",
    "Venus",
    "Mars",
    "Neptune",
    "Saturn",
    "Jupiter",
    "Pluto",
)

HD_OFFSET = 3.875
DEGREE_PER_GATE = 5.625
DEGREE_PER_LINE = 0.9375
DEGREE_PER_COLOR = 0.15625
DEGREE_PER_TONE = DEGREE_PER_COLOR / 6.0
DEGREE_PER_BASE = DEGREE_PER_TONE / 5.0

PROFILE_TO_ANGLE = {
    "1/3": "Right",
    "1/4": "Right",
    "2/4": "Right",
    "2/5": "Right",
    "3/5": "Right",
    "3/6": "Right",
    "4/6": "Right",
    "4/1": "Juxtaposition",
    "5/1": "Left",
    "5/2": "Left",
    "6/2": "Left",
    "6/3": "Left",
}

TYPE_STRATEGY = {
    "Generator": "Wait to respond",
    "Manifesting Generator": "Wait to respond, then inform when appropriate",
    "Manifestor": "Inform before acting",
    "Projector": "Wait for recognition and invitation",
    "Reflector": "Wait through a lunar cycle for major decisions",
}

SPLIT_NAMES = {
    0: "Empty",
    1: "Single",
    2: "Split",
    3: "Triple Split",
    4: "Quadruple Split",
}


class HumanDesignError(ValueError):
    """Raised when an input cannot produce a trustworthy chart."""


def load_rules() -> dict[str, Any]:
    if not RULES_PATH.is_file():
        raise HumanDesignError(f"Rules file is missing: {RULES_PATH}")
    with RULES_PATH.open(encoding="utf-8") as handle:
        return json.load(handle)


def normalize_degrees(value: float) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise HumanDesignError("Longitude must be a finite number")
    result = math.fmod(number, 360.0)
    if abs(result) < 1e-13:
        return 0.0
    return result + 360.0 if result < 0 else result


def opposite(longitude: float) -> float:
    return normalize_degrees(longitude + 180.0)


def _distance_to_boundary(value: float, width: float) -> float:
    remainder = value % width
    return min(remainder, width - remainder) * 3600.0


def activation_of(longitude: float, rules: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Map tropical longitude to gate, line, color, tone, and base."""
    rules = rules or load_rules()
    longitude = normalize_degrees(float(longitude))
    x = normalize_degrees(longitude - HD_OFFSET)
    gate_index = min(int(math.floor(x / DEGREE_PER_GATE)), 63)
    within_gate = math.fmod(x, DEGREE_PER_GATE)
    line_index = min(int(math.floor(within_gate / DEGREE_PER_LINE)), 5)
    within_line = math.fmod(x, DEGREE_PER_LINE)
    color_index = min(int(math.floor(within_line / DEGREE_PER_COLOR)), 5)
    within_color = math.fmod(x, DEGREE_PER_COLOR)
    tone_index = min(int(math.floor(within_color / DEGREE_PER_TONE)), 5)
    within_tone = math.fmod(x, DEGREE_PER_TONE)
    base_index = min(int(math.floor(within_tone / DEGREE_PER_BASE)), 4)
    within_base = math.fmod(x, DEGREE_PER_BASE)

    distances = {
        "gate": round(_distance_to_boundary(x, DEGREE_PER_GATE), 6),
        "line": round(_distance_to_boundary(x, DEGREE_PER_LINE), 6),
        "color": round(_distance_to_boundary(x, DEGREE_PER_COLOR), 6),
        "tone": round(_distance_to_boundary(x, DEGREE_PER_TONE), 6),
        "base": round(_distance_to_boundary(x, DEGREE_PER_BASE), 6),
    }
    warnings: list[str] = []
    thresholds = {"gate": 30.0, "line": 15.0, "color": 5.0, "tone": 2.0, "base": 1.0}
    for level, threshold in thresholds.items():
        if distances[level] <= threshold:
            warnings.append(
                f"{level.title()} is within {distances[level]:.3f} arcseconds of a boundary."
            )

    gate = int(rules["gate_order"][gate_index])
    return {
        "longitude": longitude,
        "gate": gate,
        "line": line_index + 1,
        "color": color_index + 1,
        "tone": tone_index + 1,
        "base": base_index + 1,
        "color_percentage": round((within_color / DEGREE_PER_COLOR) * 100.0, 6),
        "tone_percentage": round((within_tone / DEGREE_PER_TONE) * 100.0, 6),
        "base_percentage": round((within_base / DEGREE_PER_BASE) * 100.0, 6),
        "boundary_distance_arcsec": distances,
        "boundary_warnings": warnings,
    }


def canonical_longitudes(values: Mapping[str, Any]) -> dict[str, float]:
    aliases = {
        "north node": "NorthNode",
        "north_node": "NorthNode",
        "truenode": "NorthNode",
        "true node": "NorthNode",
        "mean node": "NorthNode",
        "south node": "SouthNode",
        "south_node": "SouthNode",
    }
    result: dict[str, float] = {}
    for raw_name, raw_value in values.items():
        compact = str(raw_name).replace("-", " ").strip()
        name = aliases.get(compact.lower(), compact.replace(" ", ""))
        match = next((planet for planet in PLANETS if planet.lower() == name.lower()), None)
        if match:
            result[match] = normalize_degrees(float(raw_value))
    if "Sun" in result and "Earth" not in result:
        result["Earth"] = opposite(result["Sun"])
    if "NorthNode" in result and "SouthNode" not in result:
        result["SouthNode"] = opposite(result["NorthNode"])
    missing = [planet for planet in PLANETS if planet not in result]
    if missing:
        raise HumanDesignError("Missing required longitudes: " + ", ".join(missing))
    return {planet: result[planet] for planet in PLANETS}


def activations_from_longitudes(
    values: Mapping[str, Any], rules: Mapping[str, Any] | None = None
) -> dict[str, dict[str, Any]]:
    rules = rules or load_rules()
    longitudes = canonical_longitudes(values)
    return {planet: activation_of(longitudes[planet], rules) for planet in PLANETS}


def active_gates(*activation_sets: Mapping[str, Mapping[str, Any]]) -> set[int]:
    return {
        int(activation["gate"])
        for activation_set in activation_sets
        for activation in activation_set.values()
    }


def active_channels(gates: Iterable[int], rules: Mapping[str, Any]) -> list[tuple[int, int]]:
    gate_set = {int(gate) for gate in gates}
    return [
        (int(first), int(second))
        for first, second in rules["channels"]
        if int(first) in gate_set and int(second) in gate_set
    ]


def connected_components(
    channels: Iterable[tuple[int, int]], rules: Mapping[str, Any]
) -> tuple[dict[str, int], int]:
    center_by_gate = {int(k): v for k, v in rules["gate_centers"].items()}
    graph: dict[str, set[str]] = {}
    for first, second in channels:
        left, right = center_by_gate[first], center_by_gate[second]
        graph.setdefault(left, set()).add(right)
        graph.setdefault(right, set()).add(left)
    components: dict[str, int] = {}
    component_id = 0
    for center in sorted(graph):
        if center in components:
            continue
        component_id += 1
        queue = deque([center])
        components[center] = component_id
        while queue:
            current = queue.popleft()
            for neighbor in sorted(graph[current]):
                if neighbor not in components:
                    components[neighbor] = component_id
                    queue.append(neighbor)
    return components, component_id


def determine_type(components: Mapping[str, int]) -> str:
    if not components:
        return "Reflector"
    if "Sacral" not in components:
        if "Throat" not in components:
            return "Projector"
        throat_component = components["Throat"]
        if any(components.get(center) == throat_component for center in ("Heart", "Emotions", "Root")):
            return "Manifestor"
        return "Projector"
    if "Throat" not in components:
        return "Generator"
    throat_component = components["Throat"]
    if any(
        components.get(center) == throat_component
        for center in ("Heart", "Emotions", "Root", "Sacral")
    ):
        return "Manifesting Generator"
    return "Generator"


def determine_authority(components: Mapping[str, int], chart_type: str) -> str:
    if "Emotions" in components:
        return "Emotional (Solar Plexus)"
    if "Sacral" in components:
        return "Sacral"
    if "Spleen" in components:
        return "Splenic"
    if "Heart" in components:
        if chart_type == "Manifestor":
            return "Ego Manifested"
        if chart_type == "Projector":
            return "Ego Projected"
        raise HumanDesignError(f"Unexpected {chart_type} with Heart authority")
    if (
        "Self" in components
        and "Throat" in components
        and components["Self"] == components["Throat"]
    ):
        return "Self-Projected"
    return "Lunar (28-Day Cycle)" if chart_type == "Reflector" else "Mental (Sounding Board)"


def _activation_provenance(
    gates1: set[int], gates2: set[int], label1: str, label2: str
) -> dict[str, str]:
    output: dict[str, str] = {}
    for gate in range(1, 65):
        in_first, in_second = gate in gates1, gate in gates2
        if in_first and in_second:
            output[str(gate)] = "Mixed"
        elif in_first:
            output[str(gate)] = label1
        elif in_second:
            output[str(gate)] = label2
        else:
            output[str(gate)] = "None"
    return output


def comparison_channel_activations(
    gates1: set[int], gates2: set[int], rules: Mapping[str, Any]
) -> dict[str, str]:
    output: dict[str, str] = {}
    for raw_first, raw_second in rules["channels"]:
        first, second = int(raw_first), int(raw_second)
        first_state = (1 if first in gates1 else 0) | (2 if first in gates2 else 0)
        second_state = (1 if second in gates1 else 0) | (2 if second in gates2 else 0)
        key = f"{first}-{second}"
        if first_state == 0 or second_state == 0:
            state = "None"
        elif first_state == second_state == 1:
            state = "First Dominating"
        elif first_state == second_state == 2:
            state = "Second Dominating"
        elif first_state == second_state == 3:
            state = "Companion"
        elif first_state == 3 and second_state == 1 or second_state == 3 and first_state == 1:
            state = "Compromise — First Dominating"
        elif first_state == 3 and second_state == 2 or second_state == 3 and first_state == 2:
            state = "Compromise — Second Dominating"
        else:
            state = "Magnetic"
        output[key] = state
    return output


def _center_provenance(
    components: Mapping[str, int],
    channel_states: Mapping[str, str],
    rules: Mapping[str, Any],
    *,
    first_label: str = "First",
    second_label: str = "Second",
) -> dict[str, dict[str, Any]]:
    centers = sorted(set(rules["gate_centers"].values()))
    output: dict[str, dict[str, Any]] = {}
    channels = [tuple(map(int, pair)) for pair in rules["channels"]]
    center_by_gate = {int(k): v for k, v in rules["gate_centers"].items()}
    for center in centers:
        related_states: list[str] = []
        for first, second in channels:
            if center not in (center_by_gate[first], center_by_gate[second]):
                continue
            state = channel_states[f"{first}-{second}"]
            if state != "None":
                related_states.append(state)
        if center not in components:
            provenance = "Undefined"
        elif related_states and all(state == "First Dominating" for state in related_states):
            provenance = first_label
        elif related_states and all(state == "Second Dominating" for state in related_states):
            provenance = second_label
        else:
            provenance = "Mixed"
        output[center] = {
            "defined": center in components,
            "component": components.get(center),
            "provenance": provenance,
        }
    return output


def _fixation_lookup(
    planet: str, gate: int, line: int, rules: Mapping[str, Any]
) -> set[str]:
    value = rules.get("fixations", {}).get(planet, {}).get(f"{gate}.{line}")
    if not value or value == "None":
        return set()
    if value == "Juxtaposed":
        return {"Exalted", "Detriment"}
    return {str(value)}


def _harmonics(gate: int, rules: Mapping[str, Any]) -> list[int]:
    # Gates.HarmonicGates() in the source always evaluates the activation gate
    # first, then its channel partners in Channels enum order.  The order is
    # significant for FixingStateChangedByComparer even though the final flags
    # are order-independent.
    gate = int(gate)
    if not 1 <= gate <= 64:
        raise HumanDesignError(f"Invalid gate for harmonic lookup: {gate}")
    if not 1 <= gate <= 64:
        raise HumanDesignError(f"Invalid gate for harmonic lookup: {gate}")
    matches = [gate]
    for first, second in rules["channels"]:
        first, second = int(first), int(second)
        partner: int | None = None
        if first == gate:
            partner = second
        elif second == gate:
            partner = first
        if partner is not None and partner not in matches:
            matches.append(partner)
    return matches


def planetary_fixations(
    primary: Mapping[str, Mapping[str, Any]],
    comparer: Mapping[str, Mapping[str, Any]],
    rules: Mapping[str, Any],
    *,
    baseline_activations: Iterable[Mapping[str, Mapping[str, Any]]] = (),
    additional_comparer_activations: Iterable[Mapping[str, Mapping[str, Any]]] = (),
) -> dict[str, dict[str, Any]]:
    """Calculate fixing states using the source's 2/3/4-set semantics.

    ``primary`` and ``baseline_activations`` belong to the target chart side.
    ``comparer`` and ``additional_comparer_activations`` may add a state and
    are the only sets that can set ``changed_by_comparer``.  Leaving both
    optional collections empty preserves the natal two-set behavior.
    """
    baseline_sets = (primary, *tuple(baseline_activations))
    comparer_sets = (comparer, *tuple(additional_comparer_activations))
    output: dict[str, dict[str, Any]] = {}
    for planet, activation in primary.items():
        gate, line = int(activation["gate"]), int(activation["line"])
        states = _fixation_lookup(planet, gate, line, rules)
        changed = False
        for harmonic in _harmonics(gate, rules):
            for activation_set in baseline_sets:
                for other_planet, other in activation_set.items():
                    if int(other["gate"]) == harmonic:
                        states |= _fixation_lookup(other_planet, gate, line, rules)
            comparer_states: set[str] = set()
            for activation_set in comparer_sets:
                for other_planet, other in activation_set.items():
                    if int(other["gate"]) == harmonic:
                        comparer_states |= _fixation_lookup(other_planet, gate, line, rules)
            if not comparer_states.issubset(states):
                states |= comparer_states
                changed = True
        if states == {"Exalted", "Detriment"}:
            label = "Juxtaposed"
        elif states:
            label = sorted(states)[0]
        else:
            label = "None"
        output[planet] = {"state": label, "changed_by_comparer": changed}
    return output


def _variable(name: str, activation: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "name": name,
        "orientation": "Left" if int(activation["tone"]) <= 3 else "Right",
        "color": int(activation["color"]),
        "tone": int(activation["tone"]),
        "base": int(activation["base"]),
        "boundary_warnings": list(activation.get("boundary_warnings", [])),
    }


def build_natal_chart(
    personality_longitudes: Mapping[str, Any],
    design_longitudes: Mapping[str, Any],
    *,
    metadata: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    rules = load_rules()
    personality = activations_from_longitudes(personality_longitudes, rules)
    design = activations_from_longitudes(design_longitudes, rules)
    personality_gates = active_gates(personality)
    design_gates = active_gates(design)
    gates = personality_gates | design_gates
    channels = active_channels(gates, rules)
    components, splits = connected_components(channels, rules)
    chart_type = determine_type(components)
    authority = determine_authority(components, chart_type)
    profile = f"{personality['Sun']['line']}/{design['Sun']['line']}"
    if profile not in PROFILE_TO_ANGLE:
        raise HumanDesignError(f"Calculated nonstandard profile {profile}; verify inputs and conventions")
    angle = PROFILE_TO_ANGLE[profile]
    cross_key = f"{angle}:{personality['Sun']['gate']}"
    cross = rules["incarnation_crosses"].get(cross_key)
    if not cross:
        raise HumanDesignError(f"No incarnation-cross mapping for {cross_key}")
    channel_states = comparison_channel_activations(personality_gates, design_gates, rules)
    boundary_warnings = [
        f"{side} {planet}: {warning}"
        for side, values in (("Personality", personality), ("Design", design))
        for planet, activation in values.items()
        for warning in activation["boundary_warnings"]
    ]
    return {
        "schema_version": "1.0",
        "calculation": {
            **dict(metadata or {}),
            "system": "Human Design",
            "zodiac": "tropical",
            "design_solar_arc_degrees": 88.0,
            "strategy_mapping": "Toolkit conventional labels; not an upstream 1.2.0 API field",
            "node_choice": (metadata or {}).get("node_choice", "unspecified"),
            "rules_source": rules["source"],
        },
        "summary": {
            "type": chart_type,
            "strategy": TYPE_STRATEGY[chart_type],
            "authority": authority,
            "profile": profile,
            "definition": SPLIT_NAMES[splits],
            "incarnation_cross": cross,
            "incarnation_cross_gates": [
                personality["Sun"]["gate"],
                personality["Earth"]["gate"],
                design["Sun"]["gate"],
                design["Earth"]["gate"],
            ],
        },
        "variables": {
            "digestion": _variable("Digestion", design["Sun"]),
            "awareness": _variable("Awareness", personality["Sun"]),
            "environment": _variable("Environment", design["NorthNode"]),
            "perspective": _variable("Perspective", personality["NorthNode"]),
        },
        "personality_activations": personality,
        "design_activations": design,
        "personality_fixations": planetary_fixations(personality, design, rules),
        "design_fixations": planetary_fixations(design, personality, rules),
        "active_gates": sorted(gates),
        "gate_provenance": _activation_provenance(
            personality_gates, design_gates, "Personality", "Design"
        ),
        "active_channels": [f"{a}-{b}" for a, b in channels],
        "channel_provenance": channel_states,
        "centers": _center_provenance(
            components,
            channel_states,
            rules,
            first_label="Personality",
            second_label="Design",
        ),
        "connected_components": components,
        "boundary_warnings": boundary_warnings,
    }


def build_comparison(
    first_chart: Mapping[str, Any],
    second_chart: Mapping[str, Any],
    *,
    comparison_type: str,
    first_label: str,
    second_label: str,
    second_activations: Mapping[str, Mapping[str, Any]] | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    rules = load_rules()
    comparison_kind = comparison_type.strip().lower()
    if comparison_kind not in {"composite", "transit"}:
        raise HumanDesignError("comparison_type must be 'composite' or 'transit'")
    if comparison_kind == "transit" and second_activations is None:
        raise HumanDesignError("Transit comparison requires second_activations")
    if comparison_kind == "composite" and second_activations is not None:
        raise HumanDesignError("Composite comparison does not accept second_activations")

    comparison_sets: dict[str, Any]
    if comparison_kind == "transit":
        personality = {
            planet: dict(activation)
            for planet, activation in first_chart["personality_activations"].items()
        }
        design = {
            planet: dict(activation)
            for planet, activation in first_chart["design_activations"].items()
        }
        transit = {
            planet: dict(activation)
            for planet, activation in (second_activations or {}).items()
        }
        first_gates = active_gates(personality, design)
        second_gates = active_gates(transit)
        comparison_sets = {
            "personality_activations": personality,
            "design_activations": design,
            "transit_activations": transit,
            "personality_fixations": planetary_fixations(
                personality,
                transit,
                rules,
                baseline_activations=(design,),
            ),
            "design_fixations": planetary_fixations(
                design,
                transit,
                rules,
                baseline_activations=(personality,),
            ),
            "transit_fixations": planetary_fixations(
                transit,
                personality,
                rules,
                additional_comparer_activations=(design,),
            ),
        }
        warning_sets = (
            ("Natal Personality", personality),
            ("Natal Design", design),
            ("Transit", transit),
        )
    else:
        p1_personality = {
            planet: dict(activation)
            for planet, activation in first_chart["personality_activations"].items()
        }
        p1_design = {
            planet: dict(activation)
            for planet, activation in first_chart["design_activations"].items()
        }
        p2_personality = {
            planet: dict(activation)
            for planet, activation in second_chart["personality_activations"].items()
        }
        p2_design = {
            planet: dict(activation)
            for planet, activation in second_chart["design_activations"].items()
        }
        first_gates = active_gates(p1_personality, p1_design)
        second_gates = active_gates(p2_personality, p2_design)
        comparison_sets = {
            "p1_personality_activations": p1_personality,
            "p1_design_activations": p1_design,
            "p2_personality_activations": p2_personality,
            "p2_design_activations": p2_design,
            "p1_personality_fixations": planetary_fixations(
                p1_personality,
                p2_personality,
                rules,
                baseline_activations=(p1_design,),
                additional_comparer_activations=(p2_design,),
            ),
            "p1_design_fixations": planetary_fixations(
                p1_design,
                p2_personality,
                rules,
                baseline_activations=(p1_personality,),
                additional_comparer_activations=(p2_design,),
            ),
            "p2_personality_fixations": planetary_fixations(
                p2_personality,
                p1_personality,
                rules,
                baseline_activations=(p2_design,),
                additional_comparer_activations=(p1_design,),
            ),
            "p2_design_fixations": planetary_fixations(
                p2_design,
                p1_personality,
                rules,
                baseline_activations=(p2_personality,),
                additional_comparer_activations=(p1_design,),
            ),
        }
        warning_sets = (
            (first_label + " Personality", p1_personality),
            (first_label + " Design", p1_design),
            (second_label + " Personality", p2_personality),
            (second_label + " Design", p2_design),
        )
    combined = first_gates | second_gates
    channels = active_channels(combined, rules)
    components, splits = connected_components(channels, rules)
    channel_states = comparison_channel_activations(first_gates, second_gates, rules)
    active_channel_states = {
        channel: state for channel, state in channel_states.items() if state != "None"
    }
    return {
        "schema_version": "1.0",
        "comparison_type": comparison_kind,
        "labels": {"first": first_label, "second": second_label},
        "metadata": {
            **dict(metadata or {}),
            "system": "Human Design",
            "zodiac": "tropical",
            "rules_source": rules["source"],
        },
        "active_gates": sorted(combined),
        "gate_provenance": _activation_provenance(first_gates, second_gates, first_label, second_label),
        "active_channels": [f"{a}-{b}" for a, b in channels],
        "channel_activations": channel_states,
        "active_channel_activations": active_channel_states,
        "centers": _center_provenance(
            components,
            channel_states,
            rules,
            first_label=first_label,
            second_label=second_label,
        ),
        "connected_components": components,
        "splits": splits,
        "definition": SPLIT_NAMES[splits],
        "boundary_warnings": [
            f"{side} {planet}: {warning}"
            for side, values in warning_sets
            for planet, activation in values.items()
            for warning in activation.get("boundary_warnings", [])
        ],
        **comparison_sets,
    }


def chart_fingerprint(chart: Mapping[str, Any]) -> tuple[Any, ...]:
    return (
        tuple((p, int(chart["personality_activations"][p]["gate"])) for p in PLANETS),
        tuple((p, int(chart["design_activations"][p]["gate"])) for p in PLANETS),
        int(chart["personality_activations"]["Sun"]["line"]),
        int(chart["design_activations"]["Sun"]["line"]),
    )


def validate_chart(chart: Mapping[str, Any]) -> list[str]:
    errors: list[str] = []
    rules = load_rules()
    required = (
        "schema_version",
        "calculation",
        "summary",
        "variables",
        "personality_activations",
        "design_activations",
        "personality_fixations",
        "design_fixations",
        "active_gates",
        "gate_provenance",
        "active_channels",
        "channel_provenance",
        "centers",
        "connected_components",
        "boundary_warnings",
    )
    for key in required:
        if key not in chart:
            errors.append(f"Missing top-level key: {key}")

    if chart.get("schema_version") != "1.0":
        errors.append("Unsupported or missing schema_version")
    calculation = chart.get("calculation", {})
    if not isinstance(calculation, Mapping):
        errors.append("calculation must be an object")
    else:
        if calculation.get("system") != "Human Design":
            errors.append("calculation.system must be Human Design")
        if calculation.get("zodiac") != "tropical":
            errors.append("calculation.zodiac must be tropical")
        if calculation.get("node_choice") not in {"true", "mean", "unspecified"}:
            errors.append("calculation.node_choice must be true, mean, or unspecified")
        if calculation.get("strategy_mapping") != "Toolkit conventional labels; not an upstream 1.2.0 API field":
            errors.append("calculation.strategy_mapping is missing or unsupported")
        try:
            solar_arc = float(calculation.get("design_solar_arc_degrees"))
        except (TypeError, ValueError):
            solar_arc = float("nan")
        if solar_arc != 88.0:
            errors.append("calculation.design_solar_arc_degrees must be 88")
        if calculation.get("rules_source") != rules["source"]:
            errors.append("calculation.rules_source does not match the bundled rules")

    structural_ready = True
    for side in ("personality_activations", "design_activations"):
        if side not in chart:
            structural_ready = False
            continue
        if not isinstance(chart[side], Mapping):
            errors.append(f"{side} must be an object")
            structural_ready = False
            continue
        missing_planets = [planet for planet in PLANETS if planet not in chart[side]]
        extra_planets = sorted(set(chart[side]) - set(PLANETS))
        if missing_planets:
            errors.append(f"{side} is missing: " + ", ".join(missing_planets))
            structural_ready = False
        if extra_planets:
            errors.append(f"{side} has unexpected bodies: " + ", ".join(extra_planets))
        for planet in PLANETS:
            if planet not in chart[side]:
                continue
            activation = chart[side][planet]
            if not isinstance(activation, Mapping):
                errors.append(f"{side}.{planet} must be an object")
                structural_ready = False
                continue
            try:
                longitude = float(activation.get("longitude"))
                values = {
                    "gate": int(activation.get("gate", 0)),
                    "line": int(activation.get("line", 0)),
                    "color": int(activation.get("color", 0)),
                    "tone": int(activation.get("tone", 0)),
                    "base": int(activation.get("base", 0)),
                }
            except (TypeError, ValueError):
                errors.append(f"{side}.{planet} has non-numeric activation fields")
                structural_ready = False
                continue
            ranges = {"gate": 64, "line": 6, "color": 6, "tone": 6, "base": 5}
            for field, maximum in ranges.items():
                if not 1 <= values[field] <= maximum:
                    errors.append(f"{side}.{planet} has invalid {field}")
                    structural_ready = False
            if not 0.0 <= longitude < 360.0:
                errors.append(f"{side}.{planet} longitude must be in [0, 360)")
                structural_ready = False
                continue
            mapped = activation_of(longitude, rules)
            for field in ranges:
                if values[field] != int(mapped[field]):
                    distance = float(mapped["boundary_distance_arcsec"][field])
                    if distance > 0.001:
                        errors.append(f"{side}.{planet} {field} disagrees with its longitude")
            for field in ("color_percentage", "tone_percentage", "base_percentage"):
                try:
                    percentage = float(activation.get(field))
                except (TypeError, ValueError):
                    errors.append(f"{side}.{planet} has invalid {field}")
                    continue
                if not 0.0 <= percentage <= 100.0:
                    errors.append(f"{side}.{planet} {field} must be between 0 and 100")

    if not structural_ready:
        return errors

    personality = chart["personality_activations"]
    design = chart["design_activations"]
    for label, activations in (("Personality", personality), ("Design", design)):
        if abs(((float(activations["Earth"]["longitude"]) - float(activations["Sun"]["longitude"])) % 360) - 180) > 1e-5:
            errors.append(f"{label} Earth is not opposite the Sun")
        if abs(((float(activations["SouthNode"]["longitude"]) - float(activations["NorthNode"]["longitude"])) % 360) - 180) > 1e-5:
            errors.append(f"{label} South Node is not opposite the North Node")

    personality_gates = active_gates(personality)
    design_gates = active_gates(design)
    gates = personality_gates | design_gates
    channels = active_channels(gates, rules)
    components, splits = connected_components(channels, rules)
    channel_states = comparison_channel_activations(personality_gates, design_gates, rules)
    chart_type = determine_type(components)
    profile = f"{personality['Sun']['line']}/{design['Sun']['line']}"
    angle = PROFILE_TO_ANGLE.get(profile)
    cross = rules["incarnation_crosses"].get(f"{angle}:{personality['Sun']['gate']}") if angle else None
    expected_summary = {
        "type": chart_type,
        "strategy": TYPE_STRATEGY[chart_type],
        "authority": determine_authority(components, chart_type),
        "profile": profile,
        "definition": SPLIT_NAMES[splits],
        "incarnation_cross": cross,
        "incarnation_cross_gates": [
            personality["Sun"]["gate"],
            personality["Earth"]["gate"],
            design["Sun"]["gate"],
            design["Earth"]["gate"],
        ],
    }
    expected_values = {
        "summary": expected_summary,
        "variables": {
            "digestion": _variable("Digestion", design["Sun"]),
            "awareness": _variable("Awareness", personality["Sun"]),
            "environment": _variable("Environment", design["NorthNode"]),
            "perspective": _variable("Perspective", personality["NorthNode"]),
        },
        "personality_fixations": planetary_fixations(personality, design, rules),
        "design_fixations": planetary_fixations(design, personality, rules),
        "active_gates": sorted(gates),
        "gate_provenance": _activation_provenance(
            personality_gates, design_gates, "Personality", "Design"
        ),
        "active_channels": [f"{first}-{second}" for first, second in channels],
        "channel_provenance": channel_states,
        "centers": _center_provenance(
            components,
            channel_states,
            rules,
            first_label="Personality",
            second_label="Design",
        ),
        "connected_components": components,
        "boundary_warnings": [
            f"{side} {planet}: {warning}"
            for side, values in (("Personality", personality), ("Design", design))
            for planet, activation in values.items()
            for warning in activation.get("boundary_warnings", [])
        ],
    }
    for field, expected in expected_values.items():
        if chart.get(field) != expected:
            errors.append(f"{field} is inconsistent with the activation sets")
    return errors
