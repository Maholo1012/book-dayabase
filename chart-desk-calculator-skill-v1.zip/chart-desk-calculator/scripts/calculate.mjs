#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { castAll } from './runtime/cast.mjs';
import { atlasMd, dashasMd, hdMd, matrixMd, vedicMd } from './runtime/md/format.mjs';
import { northIndianSVG, placements, southIndianSVG } from './runtime/svg/charts.mjs';
import { hdGraphSVG } from './runtime/svg/hdgraph.mjs';
import { matrixGraphSVG } from './runtime/svg/matrixgraph.mjs';
import { wheelSVG } from './runtime/svg/wheel.mjs';

const IMPLEMENTED_VARGAS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 16, 20, 24, 27, 30, 45, 60, 81, 108, 144];

function usage() {
  return `Local spiritual chart calculator (no API or network required)

Usage:
  node scripts/calculate.mjs --date YYYY-MM-DD --time HH:MM \\
    --lat NUMBER --lon NUMBER --tz Area/City [options]

Required birth fields:
  --date YYYY-MM-DD       Local civil birth date
  --time HH:MM            Local 24-hour birth time
  --lat NUMBER            Latitude, north positive
  --lon NUMBER            Longitude, east positive
  --tz Area/City          IANA time zone, e.g. America/New_York

Unknown time:
  --time-unknown          Use a flagged noon cast; time-sensitive layers are unreliable

Input/output:
  --input FILE|-          Read JSON from a file or stdin; CLI values override it
  --name TEXT             Person or chart label
  --place TEXT            Birthplace label
  --view VIEW             json | vedic | dashas | atlas | human-design | matrix |
                          varga-svg | human-design-svg | matrix-svg | tropical-svg
                          (default: vedic)
  --output FILE           Write output to a file instead of stdout
  --vargas LIST           Limit Vedic Markdown to a comma list, e.g. D1,D9,D10,D60
  --varga NUMBER          Varga for varga-svg (default: 1)
  --style north|south     Vedic SVG style (default: north)
  --outers                Include Uranus, Neptune, and Pluto in Vedic SVG
  --list-vargas           Print implemented divisional charts
  --help                  Print this help

JSON input example:
  {"name":"Example","birth":{"date":"1990-06-15","time":"14:30",
   "lat":40.7128,"lon":-74.006,"tz":"America/New_York","place":"New York"}}
`;
}

function parseArgs(argv) {
  const out = {};
  const bools = new Set(['help', 'time-unknown', 'outers', 'list-vargas']);
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    if (!token.startsWith('--')) throw new Error(`unexpected argument: ${token}`);
    const [rawKey, inline] = token.slice(2).split(/=(.*)/s);
    const key = rawKey;
    if (bools.has(key)) {
      out[key] = inline === undefined ? true : !['0', 'false', 'no'].includes(inline.toLowerCase());
      continue;
    }
    const value = inline === undefined ? argv[++i] : inline;
    if (value === undefined || value.startsWith('--')) throw new Error(`missing value for --${key}`);
    out[key] = value;
  }
  return out;
}

function readInput(path) {
  if (!path) return {};
  const text = path === '-' ? readFileSync(0, 'utf8') : readFileSync(resolve(path), 'utf8');
  const parsed = JSON.parse(text);
  if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') throw new Error('input JSON must be an object');
  return parsed;
}

function realDate(value) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value ?? '');
  if (!m) return false;
  const [year, month, day] = m.slice(1).map(Number);
  const d = new Date(Date.UTC(year, month - 1, day));
  return d.getUTCFullYear() === year && d.getUTCMonth() === month - 1 && d.getUTCDate() === day;
}

function validateBirth(birth) {
  if (!realDate(birth.date)) throw new Error('date must be a real calendar date in YYYY-MM-DD format');
  const year = Number(birth.date.slice(0, 4));
  if (year < 1700 || year > 2100) throw new Error('date is outside the validated 1700–2100 range');
  if (!birth.timeUnknown && !/^([01]\d|2[0-3]):[0-5]\d$/.test(birth.time ?? '')) {
    throw new Error('time must use 24-hour HH:MM, or pass --time-unknown');
  }
  if (!Number.isFinite(birth.lat) || birth.lat < -90 || birth.lat > 90) throw new Error('lat must be between -90 and 90');
  if (!Number.isFinite(birth.lon) || birth.lon < -180 || birth.lon > 180) throw new Error('lon must be between -180 and 180');
  if (!birth.tz) throw new Error('tz is required and must be an IANA time zone');
  try { new Intl.DateTimeFormat('en-US', { timeZone: birth.tz }).format(new Date()); }
  catch { throw new Error(`invalid IANA time zone: ${birth.tz}`); }
}

function vargaSelection(value) {
  if (!value) return null;
  const list = value.split(',').map((s) => s.trim().toUpperCase()).filter(Boolean);
  const invalid = list.filter((s) => !/^D\d+$/.test(s) || !IMPLEMENTED_VARGAS.includes(Number(s.slice(1))));
  if (invalid.length) throw new Error(`unsupported varga(s): ${invalid.join(', ')}. D40 is not implemented.`);
  return list;
}

function render(view, cast, profile, args) {
  if (view === 'json') return `${JSON.stringify(cast, null, 2)}\n`;
  if (view === 'vedic') return `${vedicMd(cast, profile, { vargas: vargaSelection(args.vargas) })}\n`;
  if (view === 'dashas') return `${dashasMd(cast, profile)}\n`;
  if (view === 'atlas') return `${atlasMd(cast, profile)}\n`;
  if (view === 'human-design') return `${hdMd(cast, profile)}\n`;
  if (view === 'matrix') return `${matrixMd(cast, profile)}\n`;
  if (view === 'varga-svg') {
    const n = Number(args.varga ?? 1);
    if (!IMPLEMENTED_VARGAS.includes(n)) throw new Error(`varga D${n} is not implemented`);
    const pl = placements(cast.vedic, n, { outers: !!args.outers, timeUnknown: cast.meta.timeUnknown });
    const options = { standalone: true, title: `${profile.name ?? 'Ad-hoc'} D${n}` };
    if ((args.style ?? 'north') === 'south') return southIndianSVG(pl, options);
    if ((args.style ?? 'north') !== 'north') throw new Error('style must be north or south');
    return northIndianSVG(pl, options);
  }
  if (view === 'human-design-svg') {
    if (!cast.hd) throw new Error('Human Design output is withheld when birth time is unknown');
    return hdGraphSVG(cast.hd, { standalone: true });
  }
  if (view === 'matrix-svg') return matrixGraphSVG(cast.matrix, { standalone: true });
  if (view === 'tropical-svg') {
    if (!cast.tropical.ascendant || !cast.tropical.mc) throw new Error('tropical wheel is withheld when birth time is unknown');
    return wheelSVG({
      ascLon: cast.tropical.ascendant.lon,
      mcLon: cast.tropical.mc.lon,
      bodies: cast.tropical.bodies,
      aspects: cast.vedic.aspects,
    }, { standalone: true });
  }
  throw new Error(`unsupported view: ${view}`);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { process.stdout.write(usage()); return; }
  if (args['list-vargas']) { process.stdout.write(`${IMPLEMENTED_VARGAS.map((n) => `D${n}`).join(', ')}\n`); return; }

  const input = readInput(args.input);
  const base = input.birth && typeof input.birth === 'object' ? input.birth : input;
  const birth = {
    date: args.date ?? base.date,
    time: args.time ?? base.time ?? null,
    timeUnknown: args['time-unknown'] ?? base.timeUnknown ?? !(args.time ?? base.time),
    lat: args.lat !== undefined ? Number(args.lat) : Number(base.lat),
    lon: args.lon !== undefined ? Number(args.lon) : Number(base.lon),
    tz: args.tz ?? base.tz,
    place: args.place ?? base.place,
  };
  if (args['time-unknown']) birth.time = null;
  validateBirth(birth);

  const profile = { name: args.name ?? input.name ?? base.name ?? 'ad-hoc cast' };
  const cast = castAll(birth);
  const output = render(args.view ?? 'vedic', cast, profile, args);
  if (args.output) writeFileSync(resolve(args.output), output, 'utf8');
  else process.stdout.write(output);
}

try { main(); }
catch (error) {
  process.stderr.write(`Error: ${error.message}\n`);
  process.exitCode = 1;
}
