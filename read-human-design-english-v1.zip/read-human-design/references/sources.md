# Sources, Calculation Conventions, and Trust Boundaries

Sources reviewed through August 8, 2026.

## System conventions

- [Jovian Archive chart and foundation overview](https://jovianarchive.com/pages/get-your-human-design-chart): the system uses birth date, time, and location; includes planetary positions at birth and approximately 88 degrees of solar arc before birth; and derives definition from complete channels.
- [Jovian Archive legacy chart page](https://www.jovianarchive.com/get_your_chart): birthplace is used to determine the correct timezone.
- [Type and Strategy](https://jovianarchive.com/pages/type-and-strategy-in-human-design?itemId=37): primary-source terminology for Type and Strategy.
- [What is Inner Authority?](https://jovianarchive.com/pages/what-is-inner-authority-in-human-design): introductory descriptions of Emotional, Sacral, Splenic, Ego, Self-Projected, and Lunar Authority.
- [Emotional Authority](https://jovianarchive.com/pages/emotional-authority-in-human-design-waiting-through-the-wave): emotional clarity develops through the user's wave rather than a universal waiting formula. Sleeping on a decision can be a practical exercise, but clarity may take hours, days, or longer.
- [Self-Projected Authority](https://jovianarchive.com/pages/self-projected-authority-in-human-design-the-projectors-voice): source convention linking Self-Projected Authority with G-to-Throat definition and hearing one's own voice.
- [Mental Authority](https://jovianarchive.com/pages/mental-authority-in-human-design-a-projector-process): source convention for Projectors without direct inner Authority, including environment and sounding-board process.

Jovian Archive is a primary source for how the Human Design system defines its own terminology. Primary-source status does not constitute scientific validation.

## Calculation engine

- [NatalEngine source and API](https://github.com/Unforced-Dev/natalengine): this skill pins `natalengine@1.6.0`, which produces Type, Strategy, Authority, Profile, centers, channels, gates, and Personality/Design planetary positions.
- [NatalEngine MIT License](https://github.com/Unforced-Dev/natalengine/blob/main/LICENSE).
- [Astronomy Engine source](https://github.com/cosinekitty/astronomy): NatalEngine 1.6.0 resolves to `astronomy-engine@2.1.19`. NatalEngine describes its calculations as VSOP87-level and approximately +/-1 arcminute; this is the dependency project's statement, not an independent measurement by this skill.
- The Design moment is found at exactly 88 degrees of solar arc before the Personality Sun.
- The skill requests true lunar nodes with `nodeType: 'true'`.
- NatalEngine maps longitudes to gates and lines, then derives channels, centers, Type, Strategy, and Authority locally.
- Node.js `Intl` and the runtime's IANA timezone database resolve historical local time.

### Trust chain

The calculator does not call an online Human Design chart database:

```text
Gregorian birth date + local time + IANA timezone
-> Node.js Intl/IANA historical UTC offset
-> astronomy-engine 2.1.19 ecliptic longitudes
-> natalengine 1.6.0 gate/line mapping and 88-degree Design moment
-> natalengine local channel/center/Type/Strategy/Authority rules
-> this skill's summary and interpretation workflow
```

NatalEngine is an MIT-licensed third-party project, not the official Jovian Archive calculation engine. Neither NatalEngine nor this skill has official accuracy certification from Jovian Archive. Pinned versions and regression tests help prevent silent changes; they do not replace comparison with an independent chart calculator.

For births close to gate or line boundaries, involving complex historical timezones, or used in professional deliverables, compare both Personality and Design activations, Type, Authority, and Profile against at least one independent calculator.

## Accuracy and disagreement

- Historical timezone, daylight-saving rules, and recorded birth-time precision can create more practical uncertainty than geographic longitude.
- Calculators may differ in true versus mean lunar nodes, ephemeris, boundary rounding, or advanced-substructure conventions. Near a gate or line boundary, report disagreement instead of selecting the interpretation that merely feels more accurate.
- Advanced Variable/PHS fields are more sensitive to positional differences. This skill does not use them by default.

## Scientific boundary

The astronomical positions and mapping rules can be calculated deterministically. The claim that birth-time planetary positions establish a person's energy type, decision process, or life themes has not been scientifically validated.

Do not use terms such as *quantum*, *neutrino*, or *genetic code* to imply that a personal interpretation has scientific proof. Treat each interpretation as a hypothesis and look for both support and counterexamples in lived experience.
