# Request schema

The wrapper accepts one UTF-8 JSON object. `schema_version` is optional and defaults to `"1.0"`.

## Shared chart object

```json
{
  "name": "Optional label",
  "place": "Optional place label",
  "date": "1996-10-12",
  "time": "16:56:00",
  "timezone": "America/New_York",
  "latitude": 34.8526,
  "longitude": -82.394,
  "fold": 0
}
```

`fold` is accepted only to disambiguate a repeated local clock hour: `0` selects the first occurrence and `1` the second. Longitude is east-positive; west longitudes are negative. Latitude is north-positive. Time must be local clock time without a UTC offset.

## Natal or event chart

```json
{
  "schema_version": "1.0",
  "operation": "natal",
  "chart": {
    "date": "1996-10-12",
    "time": "16:56:00",
    "timezone": "America/New_York",
    "latitude": 34.8526,
    "longitude": -82.394
  },
  "settings": {
    "zodiac": "sidereal",
    "ayanamsa": "lahiri",
    "house_system": "whole-sign",
    "node_mode": "true",
    "lilith_mode": "true",
    "include_objects": ["chiron", "lilith", "part-of-fortune", "vertex"]
  },
  "view": "positions",
  "output": {
    "format": "svg",
    "filename": "natal-wheel",
    "width": 900,
    "height": 900
  }
}
```

Natal responses always contain normalized `result.positions`, `result.houses`, and `result.angles`, even when a graphic is requested. Text views are `positions`, `aspects`, `aspect-grid`, `midpoints`, `wheel-text`, `horizon`, and `astrocartography`.

## Transits

```json
{
  "operation": "transits",
  "chart": { "date": "1996-10-12", "time": "16:56", "timezone": "America/New_York", "latitude": 34.8526, "longitude": -82.394 },
  "target": { "date": "2026-10-05", "time": "12:00", "timezone": "America/New_York" },
  "mode": "snapshot",
  "settings": {},
  "output": { "filename": "transits-2026-10-05" }
}
```

`mode` is `snapshot` or `month`. Month mode selects the month and year from the target's local calendar value and records it in `search_month_local`; report times are UTC. Transit output is text only in `result.raw_text`; supplying `--output-dir` also saves it as `.txt`.

## Progression or solar arc

```json
{
  "operation": "progression",
  "chart": { "date": "1996-10-12", "time": "16:56", "timezone": "America/New_York", "latitude": 34.8526, "longitude": -82.394 },
  "target": { "date": "2026-10-05", "time": "12:00", "timezone": "America/New_York" },
  "method": "secondary",
  "view": "positions",
  "output": { "format": "text", "filename": "progression" }
}
```

`method` is `secondary` or `solar-arc`. `operation: "solar-arc"` is an alias for progression with the solar-arc method. Text, SVG, and PNG output are supported.

## Return search

```json
{
  "operation": "returns",
  "chart": { "date": "1996-10-12", "time": "16:56", "timezone": "America/New_York", "latitude": 34.8526, "longitude": -82.394 },
  "target": { "date": "2026-10-01", "time": "00:00", "timezone": "America/New_York" },
  "output": { "filename": "returns-october-2026" }
}
```

The return search uses the target's local calendar month and year, records it in `search_month_local`, and produces a UTC-timescale text report. Confirm the type and exact event shown in the engine report instead of assuming that every listed event is the user's intended return.

## Relationship chart

```json
{
  "operation": "relationship",
  "chart": { "date": "1996-10-12", "time": "16:56", "timezone": "America/New_York", "latitude": 34.8526, "longitude": -82.394 },
  "chart2": { "date": "1990-01-15", "time": "08:30", "timezone": "America/Chicago", "latitude": 41.8781, "longitude": -87.6298 },
  "relationship_type": "synastry",
  "view": "aspects",
  "output": { "format": "svg", "filename": "synastry-wheel" }
}
```

`relationship_type` is `synastry`, `comparison`, `composite`, or `davison`. Text, SVG, and PNG output are supported.

## Astrocartography

```json
{
  "operation": "astrocartography",
  "chart": { "date": "1996-10-12", "time": "16:56", "timezone": "America/New_York", "latitude": 34.8526, "longitude": -82.394 },
  "output": { "format": "svg", "filename": "astrocartography", "width": 1200, "height": 700 }
}
```

Text, SVG, and PNG output are supported.

## Output object

- `format`: `text`, `svg`, or `png`; default `text`.
- `filename`: base name only, 1–80 characters, letters/digits/underscore/hyphen. The wrapper adds the extension.
- `width`, `height`: integers from 400 through 1600 that act as base-canvas hints for SVG or PNG. Astrolog may widen a chart to fit side panels. PNG artifacts report actual pixel dimensions; SVG artifacts report an internal vector `view_box` (Astrolog uses scaled vector units).

The command exits `0` on success, `2` for request errors, `3` for engine or failed self-test errors, and `4` for an unexpected internal error. Standard output is always JSON.
