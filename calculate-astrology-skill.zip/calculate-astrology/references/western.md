# Western interpretation guide

The engine uses the tropical zodiac and whole-sign houses. Interpret in layers
instead of turning every placement into a separate personality claim.

## Reading order

1. Sun, Moon, and Ascendant when the Ascendant is available.
2. Chart ruler and its sign/house.
3. Personal planets: Mercury, Venus, and Mars.
4. Angular or tightly aspected Jupiter and Saturn.
5. Repeating element, modality, house, or aspect themes.
6. Outer planets only when personally connected by a tight aspect or angle.

For unknown times, omit the Ascendant, chart ruler, angles, and every house
claim. Treat the Moon as potentially time-sensitive when it is near a boundary.

## Plain-English anchors

| Factor | Useful question |
|---|---|
| Sun | What identity or life direction is being developed? |
| Moon | What creates emotional safety and habitual response? |
| Ascendant | How does the person meet new situations? |
| Mercury | How are ideas noticed, organized, and expressed? |
| Venus | What feels attractive, harmonious, and worthwhile? |
| Mars | How are desire, effort, assertion, and frustration handled? |
| Jupiter | Where does confidence, meaning, or expansion grow? |
| Saturn | Where do limits, responsibility, patience, and mastery develop? |

Elements describe style: Fire initiates, Earth stabilizes, Air connects ideas,
and Water responds through feeling. Modalities describe pacing: Cardinal
starts, Fixed sustains, and Mutable adapts.

## Aspects

Treat aspects as relationships between functions, not as good/bad labels.

- Conjunction: the two functions operate together; intensity depends on the
  planets involved.
- Opposition: polarity, projection, and integration across two needs.
- Square: friction that asks for action, adjustment, or skill.
- Trine: easy flow that may be a talent or an unexamined habit.
- Sextile: an opportunity strengthened by participation.

Lead with tight aspects and patterns repeated elsewhere. The engine's aspect
`meaning` text is a generic keyword, not a complete interpretation.

## Transits and returns

Describe a transit as a temporary emphasis or question. Connect the transiting
planet, natal planet, aspect, and relevant dates without promising an event.

A solar or lunar return is a symbolic period chart. State the location used,
because angles and houses change by location. Never treat a return as proof
that a specific event must occur.

## Good synthesis

Prefer: “A tight Saturn–Mercury square can symbolize careful, sometimes
self-critical thinking. With strong Air elsewhere, the practical question may
be how to structure ideas without silencing them.”

Avoid: “You are doomed to depression because Saturn afflicts Mercury.”
