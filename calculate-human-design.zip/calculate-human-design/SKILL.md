---
name: calculate-human-design
description: "Calculate, validate, visualize, compare, and explain Human Design mechanics locally. Use for natal charts or BodyGraphs; gates, lines, colors, tones, bases, variables, centers, channels, definition, type, strategy, authority, profile, incarnation cross, planetary fixations, composite or connection charts, transits, birth-time uncertainty scans, or independent chart verification. Accept either a user-supplied Swiss Ephemeris archive or binary, or already-calculated tropical longitudes; no API or MCP service is required."
---

# Calculate Human Design

Use the bundled dependency-free Python engine for deterministic mechanics. Keep calculation, verification, and interpretation visibly separate.

## Workflow

1. Classify the request as natal, longitude import, composite, transit, uncertainty scan, validation, rendering, or interpretation.
2. Verify the inputs before calculating:
   - Prefer an exact UTC timestamp with offset, or a local timestamp plus an IANA timezone such as `America/New_York`.
   - If a local time repeats at the end of daylight saving time, require `fold: 0` or `fold: 1`. Reject nonexistent local times.
   - Treat birthplace coordinates as provenance only; geocoding is not part of this toolkit.
   - Default to tropical longitude and the true node. Record any deliberate use of the mean node.
3. Select one calculation route:
   - Use `natal`, `transit`, or `scan` with a trusted local Swiss Ephemeris ZIP, or with `swetest` plus an ephemeris directory.
   - Use `from-longitudes` when personality and design longitudes already exist.
   - If neither ephemeris files nor complete longitudes are available, ask for one of them. Never invent placements or silently use an online calculator.
4. Run the operation from this skill directory. Start with the examples in [references/operations.md](references/operations.md).
5. Run `validate` on every saved natal chart before reporting it. Surface all near-boundary warnings.
6. When the exact birth time is uncertain, use `scan`; describe its dyadic or duration weights as algorithmic estimates, not statistical confidence.
7. Generate the SVG and Markdown report when the user requests a visual or portable summary. The SVG is a mechanics diagram, not a licensed facsimile of another service's BodyGraph.
8. Explain results only after the mechanics pass validation. Follow [references/reporting-and-interpretation.md](references/reporting-and-interpretation.md).

## Trust Rules

- Treat the calculated fields as reproducible output from the conventions in [references/calculation-method.md](references/calculation-method.md), not as scientifically validated personality facts.
- Do not reinterpret a boundary warning as certainty. For an uncertain birth time, compare the candidate charts and report what remains stable versus what changes.
- Do not make medical, legal, financial, fertility, compatibility, or other consequential claims from Human Design.
- Preserve the calculation disclosure: UTC conversion, node choice, ephemeris route, design timestamp, rules source, and any source hash.
- Do not bundle, redistribute, or relicense Swiss Ephemeris binaries or data. Use the user's separately supplied files at runtime. Read [references/attribution-and-licensing.md](references/attribution-and-licensing.md) before redistributing any part of the toolkit.
- Keep birth data private. Avoid placing a person's name or exact birth details in public artifacts unless the user explicitly asks.

## Capabilities

| Task | Command | Primary output |
|---|---|---|
| Natal chart from birth data | `natal` | Validated chart JSON; optional SVG and Markdown |
| Chart from supplied longitudes | `from-longitudes` | Same natal chart structure without an ephemeris dependency |
| Two-person mechanics | `composite` | Four activation/fixation maps plus gate, center, and channel states |
| Natal plus a moment | `transit` | Natal/transit activation and fixation maps plus connection states |
| Uncertain birth time | `scan` | Distinct candidate charts and algorithmic weights |
| Check a saved chart | `validate` | Machine-readable validity result |
| Re-render a saved chart | `render` | SVG and/or Markdown |

## Runtime and Data

- Python 3 with its standard library and working IANA timezone data is required. No pip package, API, MCP service, account, network call, or geocoder is used.
- Copy and complete the matching JSON in `assets/`; do not overwrite the bundled template.
- Use `assets/chart-output.schema.json` for downstream validation of natal output only.
- Treat longitudes as ecliptic tropical degrees in `[0, 360)`. The core derives Earth from Sun and South Node from North Node when those antipodes are omitted.
- The natal engine emits 13 activations per side, active gates and channels, center definition and components, chart summary, variables, planetary fixation states, provenance, and precision warnings. Composite and transit output preserves every involved activation set and the source-equivalent asymmetric fixation maps.
- For full verification coverage and limitations, read [references/validation-protocol.md](references/validation-protocol.md).

## Resources

- `scripts/human_design.py`: command-line entry point.
- `scripts/hd_core.py`: dependency-free mechanics engine.
- `scripts/swiss_adapter.py`: strict Swiss Ephemeris file-mode adapter.
- `scripts/render_bodygraph.py`: original SVG and Markdown renderer.
- `scripts/test_toolkit.py`: exhaustive rule tests and optional Swiss integration tests.
- `assets/hd_rules.json`: mechanically ported rule tables with source and version metadata.
- `assets/*-input-template.json`: editable input examples.
- `assets/chart-output.schema.json`: natal output schema.
- `LICENSES/SharpAstrology.HumanDesign-MIT.txt`: retained upstream license notice.
