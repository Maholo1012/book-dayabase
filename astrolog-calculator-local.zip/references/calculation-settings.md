# Calculation settings and limits

## Defaults

| Field | Default | Allowed values |
|---|---|---|
| `zodiac` | `tropical` | `tropical`, `sidereal` |
| `ayanamsa` | `lahiri` when sidereal | See list below |
| `house_system` | `placidus` | See list below |
| `node_mode` | `mean` | `mean`, `true` |
| `lilith_mode` | same as Node | `mean`, `true`, `natural` |
| `ephemeris_mode` | `swiss` | `swiss`, `moshier` |
| `aspect_count` | `5` | integer 0–24 |
| `include_objects` | none | See list below |

Aspect orbs use the bundled Astrolog 8.00 defaults. The wrapper records this as `aspect_orb_profile`; it does not currently expose custom orb tables.

## Ayanamsas

`fagan-bradley`, `lahiri`, `deluce`, `raman`, `usha-shasi`, `krishnamurti`, `djwhal-khul`, `yukteshwar`, `jn-bhasin`, `galactic-center`.

The ayanamsa field is ignored for tropical calculations. If the user requests sidereal without an ayanamsa, use and disclose Lahiri.

## House systems

`placidus`, `koch`, `equal`, `campanus`, `meridian`, `regiomontanus`, `porphyry`, `morinus`, `topocentric`, `alcabitius`, `krusinski`, `equal-midheaven`, `pullen-sinusoidal-ratio`, `pullen-sinusoidal-delta`, `whole-sign`, `vedic`, `sripati`, `horizon`, `apc`, `carter-poli-equatorial`, `sunshine`, `savard-a`, `null`, `whole-sign-midheaven`, `vedic-midheaven`, `equal-balanced`, `whole-sign-balanced`, `vedic-balanced`, `equal-east-point`, `whole-sign-east-point`, `vedic-east-point`, `equal-vertex`, `whole-sign-vertex`, `vedic-vertex`, `porphyry-east-point`, `porphyry-vertex`, `pullen-ratio-east-point`, `pullen-ratio-vertex`, `pullen-delta-east-point`, `pullen-delta-vertex`.

An exact time and location are required for reliable cusps and angles. The normalized angles contain Ascendant and Midheaven from the engine, with Descendant and IC derived as exact opposites.

## Extra objects

`chiron`, `ceres`, `pallas`, `juno`, `vesta`, `south-node`, `lilith`, `part-of-fortune`, `vertex`, `east-point`.

The Sun through Pluto and North Node are part of the base calculation. Astrolog 8.00 couples mean/true Node and Lilith selection: use matching `node_mode` and `lilith_mode`, or select `lilith_mode: "natural"`.

## Time and coordinates

- Provide an IANA timezone rather than a fixed abbreviation such as EST, CST, or IST.
- The wrapper converts the stated local civil time to UTC and records both values.
- A repeated local time requires `fold: 0` or `fold: 1`; a nonexistent time is rejected.
- Longitude uses the common geographic convention: east positive, west negative.
- Latitude uses north positive, south negative. Exact geographic poles are rejected for house calculations.

## Ephemerides

The bundled Swiss Ephemeris files cover 1800–2399. Swiss mode fails closed outside that interval. `moshier` may be selected explicitly for another date and produces a warning because results can differ slightly.

Do not describe the engine as a hosted Swiss Ephemeris service. It is a local Astrolog build using the data and calculation modes included in the skill.

## Output and safety limits

- Request JSON: maximum 256 KiB.
- Text returned by the engine: maximum 5 MB.
- Graphic artifact: maximum 12 MB.
- SVG is parsed and rejected if it contains a doctype, script, or external HTTP link.
- PNG signature and dimensions are validated.
- Graphic width and height are base-canvas hints. Astrolog may widen output for side panels, and SVG uses scaled internal vector coordinates; artifact metadata records requested sizing and actual PNG dimensions or the SVG view box.
- Output filenames are restricted, output-directory escape is blocked, and existing artifacts are never overwritten.
- Environment configuration variables are removed before the engine runs so local user settings cannot silently alter a result.
