---
name: astrolog-calculator
description: Calculate, verify, compare, and render astrology charts with a bundled local Astrolog 8.00 engine. Use for natal or event charts, planetary positions, houses, aspects, SVG or PNG chart wheels, transits, secondary progressions, solar arcs, solar returns, synastry, comparison, composite or Davison charts, and astrocartography when date, local time, IANA timezone, latitude, and longitude are available.
---

# Astrolog Calculator

Use the bundled wrapper for reproducible astrology calculations without an API, account, or network request. The wrapper normalizes civil time to UTC, accepts only allowlisted operations, and reports the calculation settings with every result.

## Non-negotiable workflow

1. Collect the required chart inputs:
   - ISO date: `YYYY-MM-DD`
   - local clock time: `HH:MM` or `HH:MM:SS`
   - IANA timezone, such as `America/New_York`
   - decimal latitude, north positive
   - decimal longitude, east positive and west negative
2. Never guess a timezone, daylight-saving interpretation, coordinate, or birth time. Ask for missing data. If the user explicitly authorizes an approximate time, label it approximate and do not present houses or angles as reliable.
3. If a repeated DST hour is ambiguous, ask whether the first or second occurrence is intended and encode `fold: 0` or `fold: 1`. Reject nonexistent local times rather than shifting them silently.
4. Put the request in a UTF-8 JSON file and run only `scripts/astrolog_tool.py`. Never invoke `scripts/runtime/astrolog` directly and never pass user-supplied raw Astrolog switches.
5. Inspect `ok`, `warnings`, `settings`, UTC conversion metadata, and artifacts in the JSON response before presenting results.
6. Report the exact zodiac, ayanamsa if applicable, house system, node mode, ephemeris mode, and local-to-UTC conversion. Separate computed facts from interpretive commentary.

For exact fields and examples, read [references/request-schema.md](references/request-schema.md). For supported settings and limitations, read [references/calculation-settings.md](references/calculation-settings.md). For operation selection, read [references/command-map.md](references/command-map.md).

## Run the wrapper

From this skill directory:

```bash
python3 scripts/astrolog_tool.py --request /absolute/path/request.json --output-dir /absolute/path/output --pretty
```

Use `--output-dir` whenever a text, SVG, or PNG artifact is wanted. The wrapper refuses to overwrite an existing artifact, so choose a new filename or directory for reruns.

Useful diagnostics:

```bash
python3 scripts/astrolog_tool.py --capabilities --pretty
python3 scripts/astrolog_tool.py --self-test --pretty
```

Run the self-test after an executable compatibility error or before relying on the skill in a newly provisioned environment. The wrapper can rebuild its bundled headless runtime from the included corresponding source when `make` and `g++` are available.

## Choose settings explicitly

When the user specifies a tradition or calculation method, encode it exactly. Otherwise use and disclose these wrapper defaults:

- tropical zodiac
- Placidus houses
- mean Node and matching mean Lilith
- Swiss Ephemeris files bundled for years 1800 through 2399
- five major aspects with Astrolog 8.00's bundled orb profile

If the user asks for sidereal astrology without naming an ayanamsa, use Lahiri and say that this default was selected. Never mix results from different zodiacs, ayanamsas, house systems, node modes, or ephemerides without labeling each set.

## Present results responsibly

- Lead with the requested calculated result, then list settings and UTC conversion.
- For natal positions, prefer the normalized `positions`, `houses`, and `angles` arrays over parsing prose from `raw_text`.
- Treat `raw_text` as the engine's detailed report for views such as aspects, midpoints, transits, returns, relationship charts, or astrocartography.
- Preserve retrograde flags and enough precision to support verification. Round only in the human-readable summary.
- When interpreting, label interpretation separately from calculation. Use tentative language and avoid framing astrology as scientific prediction, medical advice, legal advice, or financial advice.
- If an artifact was requested, link the returned file path. SVG is preferable for a scalable chart wheel; PNG is preferable for broad image compatibility.
- Surface all warnings. Moshier mode must be explicitly requested for dates outside bundled Swiss coverage and must remain labeled as Moshier.

## Privacy and provenance

The calculation runs locally and does not require an API key. Do not send birth data to an external lookup or geocoding service unless the user separately asks for that. The bundled engine and licensing notes are documented in [references/third-party-notices.md](references/third-party-notices.md).
