# Vedic and divisional-chart guide

The engine uses Lahiri sidereal positions and whole-sign rashi houses. Schools
of Jyotisha differ; name the method and avoid claiming a single universal rule.

## D1 reading order

1. Lagna and Lagna lord, only with a reliable birth time.
2. Moon sign, nakshatra, and pada.
3. Sun and the seven classical grahas.
4. Rahu and Ketu.
5. Repeated house, lordship, dignity, or aspect themes.
6. Vimshottari periods as symbolic timing contexts.

The yoga detector is deliberately limited. Its list is non-exhaustive and does
not evaluate all cancellation, strength, combustion, house-lord, or aspect
conditions. Never declare a life outcome from the mere presence of a yoga.

## Supported Vargas

| Chart | Traditional topic in this skill |
|---|---|
| D2 Hora | Resources and wealth patterns |
| D3 Drekkana | Siblings, courage, self-effort |
| D4 Chaturthamsa | Property and fixed assets |
| D5 Panchamsha | Recognition and authority |
| D6 Shashtamsha | Challenges and resilience |
| D7 Saptamsha | Children and creativity |
| D8 Ashtamsha | Transformation and vulnerability |
| D9 Navamsha | Dharma, relationships, planetary strength |
| D10 Dashamsha | Career and public role |
| D11 Rudramsha | Gains and networks |
| D12 Dwadashamsha | Parents and ancestry |
| D16 Shodashamsha | Comforts and vehicles |
| D20 Vimshamsha | Spiritual practice |
| D24 Chaturvimshamsha | Learning and knowledge |
| D27 Bhamsa | Strengths and weaknesses |
| D30 Trimshamsha | Adversity and difficult patterns |
| D40 Khavedamsha | Maternal-line themes |
| D45 Akshavedamsha | Paternal-line themes |
| D60 Shashtiamsha | Fine-grained karmic themes |

These topics are traditional interpretive associations, not measured facts.
Use a Varga to refine a D1 theme, never to erase or overrule the D1 chart.

## Time and boundary rules

- With unknown time, omit every Varga Lagna. Planetary Varga placements may
  still be shown but the Moon can shift across a division during the day.
- Do not rely on a single noon-anchor nakshatra or Vimshottari timeline. Compare
  the beginning and end of the verified local date; withhold dasha timing if
  the Moon can cross a nakshatra boundary.
- D30, D40, D45, and D60 are highly birth-time and precision sensitive.
- If `boundary_warning` is true or `source_boundary_distance_deg` is small,
  name both possibilities or request a recorded time and higher-precision
  cross-check.
- Do not rectify a birth time from life anecdotes unless the user explicitly
  requests a separate rectification exercise and understands its uncertainty.

## Vimshottari dasha

The Moon's sidereal nakshatra determines the starting mahadasha and remaining
balance at birth. Read a period as a thematic context associated with its lord,
then connect it to the verified natal chart. Dates are calculated boundaries,
not guaranteed event dates. A Moon near a nakshatra boundary can materially
change the timeline.

## Panchanga

- Tithi: Sun–Moon angular separation in 12° units.
- Nakshatra: the Moon's sidereal lunar mansion and pada.
- Yoga: the combined sidereal longitude of Sun and Moon.
- Karana: half of a tithi.

The engine reports traditional nature labels. Present them as customary
electional symbolism, never as a safety, medical, legal, or financial rule.

## Sensitive labels

Mangal and Kaalsarpa outputs are mechanical checks with many school variants.
Explain the rule used, avoid fear language, and never prescribe gemstones,
ritual purchases, relationship rejection, or other consequential action from a
dosha label.
