# BaZi interpretation guide

The engine calculates year and month pillars from solar terms, the day pillar
from the local civil date, and the hour pillar from the local clock time. It is
a compact Four Pillars implementation, not a substitute for a complete
professional calendar and school-specific analysis.

## Read in this order

1. Confirm the local date, timezone, and whether the hour is known.
2. Identify the Day Master: the day stem's element and polarity.
3. Review season and month pillar before using the element tally.
4. Examine interactions among stems and branches.
5. Treat element balance and favorable-element fields as simplified prompts.
6. Treat luck-pillar start ages as approximate; the engine explicitly uses an
   approximation rather than a precise solar-term interval calculation.

If birth time is unknown, the hour pillar is `null` and excluded from the
element tally and Ten Gods. Do not fill it from noon or infer it from character.
When the conservative unknown-time window crosses a solar-term boundary, the
year and/or month pillar is also `null`; use `pillar_options` and do not choose
between them without a verified clock time. Derived strength, favorable-element,
and luck-pillar fields are withheld in that case.

## Five-element cycles

- Generating: Wood → Fire → Earth → Metal → Water → Wood.
- Controlling: Wood controls Earth, Earth controls Water, Water controls Fire,
  Fire controls Metal, and Metal controls Wood.

These cycles help describe support, expression, pressure, and regulation. They
do not diagnose health or prescribe foods, supplements, colors, careers, or
medical treatment.

## Simplification warnings

- `strength` is a weighted tally, not a complete seasonal strength analysis.
- `favourable_elements` and `useful_god_note` are heuristics, not a full Yong
  Shen determination.
- Luck-pillar direction depends on the gender field and a traditional rule; if
  the user does not identify with that binary convention, explain the limit and
  offer both directional sequences rather than forcing an identity.
- Zodiac compatibility and Tai Sui notes are folk-tradition prompts, not
  relationship, risk, or life-decision verdicts.

Use language such as “Within this simplified BaZi model…” and connect every
interpretation to a returned field.
