# Human Design Core Mechanics

## Reading method

Use this reference as interpretation grammar, not as a statement of fact about a person. Interpret only fields present in the calculated or supplied chart.

Priority: Type and Strategy > Authority > Profile > Definition/Centers/Channels > individual Gates. More gates do not mean more strength, and an open center is not a defect.

## Types and strategies

| Type | Chart mechanism | Plain-language strategy | Observable resistance signal |
|---|---|---|---|
| Generator | Defined Sacral center | Let life present something concrete to respond to, then notice whether sustainable energy is available | Frustration |
| Manifesting Generator | Defined Sacral plus a defined motor-to-Throat path | Begin with response; check Authority before accelerating, and inform people affected by the action | Frustration, sometimes anger |
| Manifestor | Undefined Sacral with a defined motor-to-Throat path | Inform people who will be affected before acting; the aim is reducing resistance, not asking permission | Anger |
| Projector | Undefined Sacral, no motor-to-Throat path, and at least one defined center | For major roles, relationships, and moves, look for genuine recognition and invitation, then consult Authority | Bitterness |
| Reflector | No defined centers | For major decisions, observe the choice through approximately one lunar cycle and across different settings | Disappointment |

Strategy addresses *when to enter an experience*. Authority addresses *how to reach a decision once one is available*. Do not describe strategy as passive waiting or as a substitute for information gathering, skill development, or risk assessment.

## Authority hierarchy

Authority follows chart mechanics; users do not select it by preference.

1. **Emotional / Solar Plexus:** Takes priority whenever the Solar Plexus is defined. Avoid treating a high or low emotional point as complete clarity. Revisit the same option across the user's emotional wave. The goal is sufficient clarity, not guaranteed certainty.
2. **Sacral:** Applies to non-emotional Generators and Manifesting Generators. Present specific, current, respondable options and observe approach, withdrawal, or lack of available energy.
3. **Splenic:** Appears when Emotional and Sacral centers are undefined and the Spleen is defined. The signal is often quiet, brief, and immediate, concerning safety, wellbeing, or timing. Do not reduce fear, trauma responses, or medical symptoms to intuition.
4. **Ego / Self-Projected:** Applies to less common Projector or Manifestor configurations. Use an unpressured listening space so the user can hear their own wants, commitments, direction, and sense of identity. If the engine supplies only a broad label, do not invent manifested/projected subtypes.
5. **Mental / Environmental:** Applies to Projectors without direct inner authority. Let the user speak through options in a suitable environment with a trusted listener who does not decide for them.
6. **Lunar:** Applies to Reflectors. Observe major choices across roughly 28 days and several environments; do not impose a full cycle on minor decisions.

### Timing audit

Strategy and Authority do not create a universal waiting period.

- Never give everyone a rule such as "sleep on it," "wait 24 hours," or "never decide immediately."
- **Emotional:** Move beyond the present high or low and observe whether relative clarity remains across the wave. "Sleep on a major decision and revisit it" may be used as a beginner safeguard, but one night is not the mechanism and clarity may take hours, days, or longer.
- **Sacral:** A response to a concrete present option may be immediate. Do not force delay merely to sound cautious.
- **Splenic:** The signal is commonly brief and present-time; mechanical delay may miss it. Still separate practical safety evidence from fear and trauma reactions.
- **Ego / Self-Projected:** Listen for expressed willingness, commitment, or direction. Do not prescribe a fixed delay.
- **Mental / Environmental:** Speak options aloud in an appropriate setting, potentially more than once, but without an overnight threshold.
- **Lunar:** Use approximately one lunar cycle for major Reflector decisions only.

Later journaling is a review method, not automatically a rule to delay the original decision.

## Profile

Profile combines the Personality Sun line and Design Sun line. Use only the combination returned by the engine. The standard twelve are 1/3, 1/4, 2/4, 2/5, 3/5, 3/6, 4/6, 4/1, 5/1, 5/2, 6/2, and 6/3.

| Line | Grounded language | Observation question |
|---|---|---|
| 1 | Foundation / investigation | What information and structure help you feel ready to proceed? |
| 2 | Natural ability / retreat | What abilities feel ordinary to you but are repeatedly recognized by others? |
| 3 | Experimentation / adaptation | Which conclusions became reliable only after testing and revising them? |
| 4 | Network / influence | Which opportunities arise through stable, trusted relationships? |
| 5 | Projection / practical problem-solving | What do others expect you to solve, and which expectations require clearer limits? |
| 6 | Life stages / role model | Do you learn best through experience, distance and observation, then embodied example? |

Avoid old labels such as "martyr" or "heretic" when they would stigmatize the user.

## Definition and the nine centers

A channel becomes defined when both of its gates are activated; the connected centers then become defined. Treat definition as a relatively consistent operating pattern. Treat undefined areas as more responsive to context and potentially capable of observational wisdom. Openness is not weakness.

| Center | Theme | Observation when undefined |
|---|---|---|
| Head | Inspiration and mental pressure | Am I trying to solve questions that are not mine? |
| Ajna | Concepts, opinions and certainty | Am I holding a position mainly to appear certain? |
| Throat | Expression, action and visibility | Am I speaking or acting mainly to attract attention? |
| G | Identity, direction and love | Am I forcing an answer to "Who am I?" while ignoring people and place? |
| Heart/Ego | Will, value, commitments and resources | Am I overcommitting to prove my worth? |
| Spleen | Present-time intuition, survival and wellbeing | Am I holding on because I am afraid to release what no longer fits? |
| Solar Plexus | Emotional waves and feeling | Am I agreeing immediately to avoid someone else's emotions? |
| Sacral | Sustainable life-force, work and sexual energy | Am I demanding another person's sustainable pace from myself? |
| Root | Pressure, initiation and momentum | Am I rushing only to escape pressure? |

## Channels, gates and activations

- **Defined channels:** Interpret these before individual gates. Translate the channel name and connected centers into an observable stable pattern; never turn a channel into a job list.
- **Hanging gates:** Treat them as themes or tendencies, not complete channels. A single gate does not define its center.
- **Personality and Design activations:** Personality/black activations are traditionally described as easier to recognize consciously; Design/red activations as less subjectively conscious and sometimes more visible to others. Treat this as an interview hypothesis, not an objective neurological claim.
- **Planets:** Give Sun/Earth themes more weight, but do not expand planetary symbolism beyond what the user's question requires.

## Definition types

Definition describes how many connected components the defined centers form through complete channels:

- **Single definition:** All defined centers form one connected component.
- **Split, triple-split, or quadruple-split:** Two, three, or four disconnected components.
- Never describe this as a split personality. Use it only as a possible observation about information-integration rhythm and environmental influence.
