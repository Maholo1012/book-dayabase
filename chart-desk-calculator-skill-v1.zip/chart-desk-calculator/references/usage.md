# Command guide

Run commands from the skill directory.

## Vedic Markdown

```bash
node scripts/calculate.mjs \
  --date 1990-06-15 --time 14:30 \
  --lat 40.7128 --lon -74.006 --tz America/New_York \
  --place "New York" --name "Example" \
  --view vedic --vargas D1,D9,D10,D60 \
  --output /tmp/example-vedic.md
```

## Full JSON

```bash
node scripts/calculate.mjs --input birth.json --view json --output /tmp/chart.json
```

Input shape:

```json
{
  "name": "Example",
  "birth": {
    "date": "1990-06-15",
    "time": "14:30",
    "lat": 40.7128,
    "lon": -74.006,
    "tz": "America/New_York",
    "place": "New York"
  }
}
```

## Focused reports

- `--view dashas`: Vimshottari timeline.
- `--view human-design`: Human Design mechanics.
- `--view matrix`: Matrix of Destiny calculations.
- `--view atlas`: all three systems in one Markdown file.

## SVG charts

```bash
node scripts/calculate.mjs --input birth.json --view varga-svg --varga 9 --style south --output /tmp/d9.svg
node scripts/calculate.mjs --input birth.json --view human-design-svg --output /tmp/bodygraph.svg
node scripts/calculate.mjs --input birth.json --view matrix-svg --output /tmp/matrix.svg
node scripts/calculate.mjs --input birth.json --view tropical-svg --output /tmp/wheel.svg
```

Use `--style north` or `--style south` for a Vedic SVG. Use `--outers` only when the user explicitly wants the outer planets displayed.

## Unknown time

```bash
node scripts/calculate.mjs \
  --date 1990-06-15 --time-unknown \
  --lat 40.7128 --lon -74.006 --tz America/New_York \
  --view json
```

Always surface the resulting caveats. Do not interpret the noon Ascendant, houses, divisional charts, or exact timing as verified natal facts.
