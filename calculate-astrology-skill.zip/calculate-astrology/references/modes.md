# Calculation modes

All inputs are JSON. Dates and clock times are local to the named place; the
engine converts them to UTC. Use decimal degrees with north/east positive and
south/west negative.

## Shared birth fields

```json
{
  "year": 1990,
  "month": 6,
  "day": 15,
  "hour": 14,
  "minute": 30,
  "lat": 40.7128,
  "lng": -74.0060,
  "tz": "America/New_York",
  "time_known": true
}
```

- `year`, `month`, and `day` are always required.
- A known time requires `hour`, `minute`, verified `lat`/`lng`, and either an
  IANA `tz` or explicit numeric `utc_offset`.
- During an ambiguous daylight-saving fall-back hour, add `"fold": 0` for the
  first occurrence or `"fold": 1` for the second.
- For an unknown time, omit `hour` and `minute` and set `"time_known": false`.
  Still collect birthplace or timezone when possible so the stated civil date
  has a defined UTC interval. Noon is used only as a neutral computational
  anchor; angles, houses, Varga Lagna, and the BaZi hour pillar are withheld.
  Compare near the beginning and end of that local date before treating a
  planet, sidereal sign, nakshatra, pada, or dasha boundary as stable. If the
  place is unavailable too, use a worldwide date window and report alternatives
  rather than one precise Moon-derived answer.
- `systems` may contain `western`, `vedic`, and/or `bazi`. The default is all
  three.

## Supported routes

| Goal | Mode and extra fields | Important constraint |
|---|---|---|
| Natal overview | `"mode":"natal"` or omit mode | Unknown time limits Moon precision and removes time-sensitive factors |
| Transits | `"mode":"transit","transit_date":"YYYY-MM-DD"` | Date-only uses local noon; add `transit_time` and `transit_tz` for an exact moment |
| Transit aspects only | `"mode":"transit_natal_aspects","transit_date":"YYYY-MM-DD"` | Same transit-time rules; uses aspect geometry only |
| Synastry | `"mode":"synastry","partner":{...}` | Two dates required; exact times improve Moon/angle work |
| Compatibility heuristic | `"mode":"compatibility","partner":{...}` | Score is not a probability or verdict |
| Composite | `"mode":"composite","partner":{...}` | Reliable times and locations required for both people |
| Event or moment chart | `"mode":"event","subject":"...","kind":"..."` | Use a verified event time and place for angles |
| Solar return | `"mode":"solar_return","target_year":2027` | Reliable natal time required; optional separate `return_location` |
| Lunar return | `"mode":"lunar_return","target_year":2027,"target_month":3` | Reliable natal time required; optional separate `return_location` |
| D9 | `"mode":"navamsa"` | D9 Lagna is withheld without a reliable time |
| Other supported Varga | `"mode":"varga","varga":"D10"` | Inspect boundary warnings, especially D30–D60 |
| Panchanga | `"mode":"panchang"` | Exact or deliberately selected local moment required |
| Moon phase | `"mode":"moon_phase"` | Gives phase at input and the next four quarter phases |
| Numerology | `"mode":"numerology","full_name":"Optional Name"` | Name-derived values require the intended full name |

## Relationship example

```json
{
  "mode": "synastry",
  "year": 1990,
  "month": 6,
  "day": 15,
  "time_known": false,
  "systems": ["western"],
  "partner": {
    "year": 1992,
    "month": 9,
    "day": 4,
    "time_known": false
  }
}
```

## Transit and return locations

`transit_date` is interpreted at 12:00 in `transit_tz` when `transit_time` is
omitted. If `transit_tz` is omitted, the verified natal `tz` is reused. For an
exact transit moment, pass values such as:

```json
{
  "mode": "transit",
  "transit_date": "2027-01-15",
  "transit_time": "09:30",
  "transit_tz": "Europe/London"
}
```

Return calculations always derive the natal longitude from the shared birth
fields. The return chart defaults to the birth coordinates. For a relocated
return, add a separate object; do not overwrite the natal coordinates or
timezone:

```json
{
  "mode": "solar_return",
  "target_year": 2027,
  "return_location": {
    "place": "London",
    "lat": 51.5074,
    "lng": -0.1278
  }
}
```

## Disabled routes

Do not use `astrocartography`, `horary`, `planetary_return`,
`planetary_hours`, or `progressions`. The inherited implementations did not
meet this adaptation's reliability threshold. Use `event` for a neutral chart
of a question moment, without a horary verdict.

## Output checks

Before interpreting, confirm `_meta.engine_backend`, `_meta.precision_note`,
`time_info`, `mode`, and all warnings. A missing or null value is not permission
to infer it.
