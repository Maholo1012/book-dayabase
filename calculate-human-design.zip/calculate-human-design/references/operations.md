# Operations

Run commands from the skill root. Replace paths with writable workspace destinations. The Python core has no third-party package dependency.

## Natal chart from a Swiss Ephemeris ZIP

Copy `assets/birth-input-template.json`, then enter either `birth_utc` with an offset or `birth_local` plus an IANA timezone.

```bash
python3 scripts/human_design.py natal \
  --input /path/to/birth.json \
  --swiss-archive /path/to/swisseph-master.zip \
  --output /path/to/chart.json \
  --svg /path/to/bodygraph.svg \
  --report /path/to/summary.md \
  --hash-source
```

Instead of a ZIP, pass both `--swetest /path/to/swetest` and `--ephe-dir /path/to/ephe`. File mode is strict: missing files, warnings, or a fallback to Moshier are treated as errors.

## Natal chart from supplied longitudes

Copy `assets/longitudes-input-template.json`. Supply at least Sun, North Node, Moon, Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, and Pluto for both personality and design. Earth and South Node may be omitted because they are derived as antipodes.

```bash
python3 scripts/human_design.py from-longitudes \
  --input /path/to/longitudes.json \
  --output /path/to/chart.json \
  --svg /path/to/bodygraph.svg \
  --report /path/to/summary.md
```

## Validate or re-render

```bash
python3 scripts/human_design.py validate --chart /path/to/chart.json

python3 scripts/human_design.py render \
  --chart /path/to/chart.json \
  --svg /path/to/bodygraph.svg \
  --report /path/to/summary.md
```

## Composite or connection mechanics

First calculate and validate each natal chart.

```bash
python3 scripts/human_design.py composite \
  --first /path/to/first-chart.json \
  --second /path/to/second-chart.json \
  --first-label "Person 1" \
  --second-label "Person 2" \
  --output /path/to/composite.json \
  --svg /path/to/composite.svg \
  --report /path/to/composite.md
```

`channel_activations` contains all 36 source states; `active_channel_activations` is the non-`None` subset. States are `First Dominating`, `Second Dominating`, `Companion`, `Compromise — First Dominating`, `Compromise — Second Dominating`, or the source enum label `Magnetic`. Composite output also includes all four personality/design activation and fixation maps.

## Transit comparison

Copy `assets/transit-input-template.json` and set the transit moment.

```bash
python3 scripts/human_design.py transit \
  --natal /path/to/chart.json \
  --input /path/to/transit.json \
  --swiss-archive /path/to/swisseph-master.zip \
  --output /path/to/transit-comparison.json \
  --svg /path/to/transit.svg \
  --report /path/to/transit.md
```

Transit output includes natal personality, natal design, and transit activation/fixation maps. Fixation comparison is asymmetric by design and follows the upstream overloads.

## Birth-time uncertainty scan

Copy `assets/time-range-input-template.json`. The default `adaptive` method mirrors the upstream endpoint-equality bisection: it subdivides toward roughly ten-minute leaves, stops a branch early when its endpoint charts match, caps depth at 12, and aggregates dyadic weights by chart fingerprint.

```bash
python3 scripts/human_design.py scan \
  --input /path/to/time-range.json \
  --swiss-archive /path/to/swisseph-master.zip \
  --output /path/to/range-results.json
```

Report the stable fields first, then list fields that vary and the selected method's weights. Do not describe them as measured probabilities.

To request a fixed grid instead, set `"method": "sampling"` and provide `step_minutes`. Fixed-grid weights are duration estimates. Neither method produces statistical confidence; `max_samples` is a workload guard.

## Self-test

Pure rule and graph tests:

```bash
python3 scripts/test_toolkit.py --json
```

Full test, including the repository reference chart and composite example:

```bash
python3 scripts/test_toolkit.py \
  --swiss-archive /path/to/swisseph-master.zip \
  --json
```
