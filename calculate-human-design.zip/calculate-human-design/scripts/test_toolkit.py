#!/usr/bin/env python3
"""Self-test the Human Design rules port and optional Swiss integration."""

from __future__ import annotations

import argparse
import json
import math
from datetime import datetime, timezone
from pathlib import Path

from hd_core import (
    DEGREE_PER_BASE,
    DEGREE_PER_COLOR,
    DEGREE_PER_GATE,
    DEGREE_PER_LINE,
    DEGREE_PER_TONE,
    HD_OFFSET,
    HumanDesignError,
    PLANETS,
    PROFILE_TO_ANGLE,
    activation_of,
    active_channels,
    build_comparison,
    build_natal_chart,
    comparison_channel_activations,
    connected_components,
    determine_authority,
    determine_type,
    load_rules,
    planetary_fixations,
    validate_chart,
)
from human_design import resolve_moment
from swiss_adapter import SwissRuntime, runtime_years


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def pure_tests() -> dict[str, int]:
    rules = load_rules()
    check(len(rules["gate_order"]) == 64, "gate wheel must contain 64 entries")
    check(set(rules["gate_order"]) == set(range(1, 65)), "gate wheel must be a permutation")
    check(len(rules["gate_centers"]) == 64, "every gate must map to a center")
    check(len(set(rules["gate_centers"].values())) == 9, "there must be nine centers")
    check(len(rules["channels"]) == 36, "there must be 36 channels")
    check(len({tuple(pair) for pair in rules["channels"]}) == 36, "channels must be unique")
    check(len(rules["incarnation_crosses"]) == 192, "cross table must contain 192 rows")
    check(sum(len(rows) for rows in rules["fixations"].values()) == 759, "fixation table must contain 759 explicit rows")

    cells = 0
    for gate_index in range(64):
        for line in range(6):
            for color in range(6):
                for tone in range(6):
                    for base in range(5):
                        longitude = (
                            HD_OFFSET
                            + gate_index * DEGREE_PER_GATE
                            + line * DEGREE_PER_LINE
                            + color * DEGREE_PER_COLOR
                            + tone * DEGREE_PER_TONE
                            + (base + 0.5) * DEGREE_PER_BASE
                        ) % 360.0
                        activation = activation_of(longitude, rules)
                        check(activation["gate"] == rules["gate_order"][gate_index], "gate cell mismatch")
                        check(activation["line"] == line + 1, "line cell mismatch")
                        check(activation["color"] == color + 1, "color cell mismatch")
                        check(activation["tone"] == tone + 1, "tone cell mismatch")
                        check(activation["base"] == base + 1, "base cell mismatch")
                        cells += 1

    for field, width, exact_is_representable in (
        ("gate", DEGREE_PER_GATE, True),
        ("line", DEGREE_PER_LINE, True),
        ("color", DEGREE_PER_COLOR, True),
        ("tone", DEGREE_PER_TONE, False),
        ("base", DEGREE_PER_BASE, False),
    ):
        boundary = HD_OFFSET + 17 * width
        below = activation_of(math.nextafter(boundary, -math.inf), rules)
        exact = activation_of(boundary, rules)
        above = activation_of(math.nextafter(boundary, math.inf), rules)
        check(below[field] != above[field], f"{field} boundary transition missing")
        if exact_is_representable:
            check(exact[field] == above[field], f"half-open {field} boundary failed")
        else:
            check(
                exact[field] in (below[field], above[field]),
                f"rounded {field} boundary is not adjacent",
            )

    source_boundary = activation_of(9.5, rules)
    check(
        tuple(source_boundary[field] for field in ("gate", "line", "color", "tone", "base"))
        == (21, 1, 1, 1, 5),
        "source-compatible exact-boundary fixture mismatch",
    )

    synthetic = {
        "Reflector": [],
        "Generator": [(5, 15)],
        "Manifesting Generator": [(20, 34)],
        "Manifestor": [(21, 45)],
        "Projector": [(23, 43)],
    }
    for expected, channels in synthetic.items():
        components, _ = connected_components(channels, rules)
        check(determine_type(components) == expected, f"type mismatch: {expected}")

    authority_cases = [
        ([(39, 55), (5, 15)], "Emotional (Solar Plexus)"),
        ([(5, 15)], "Sacral"),
        ([(18, 58)], "Splenic"),
        ([(21, 45)], "Ego Manifested"),
        ([(25, 51)], "Ego Projected"),
        ([(1, 8)], "Self-Projected"),
        ([(23, 43)], "Mental (Sounding Board)"),
        ([], "Lunar (28-Day Cycle)"),
    ]
    for channels, expected in authority_cases:
        components, _ = connected_components(channels, rules)
        chart_type = determine_type(components)
        check(determine_authority(components, chart_type) == expected, f"authority mismatch: {expected}")

    check(set(PROFILE_TO_ANGLE) == {"1/3", "1/4", "2/4", "2/5", "3/5", "3/6", "4/6", "4/1", "5/1", "5/2", "6/2", "6/3"}, "profile table mismatch")

    # Exhaust the 16 endpoint-ownership combinations for one channel.
    states = (set(), {1}, {8}, {1, 8})
    channel_truth_table = {
        (1, 1): "First Dominating",
        (2, 2): "Second Dominating",
        (3, 3): "Companion",
        (3, 1): "Compromise — First Dominating",
        (1, 3): "Compromise — First Dominating",
        (3, 2): "Compromise — Second Dominating",
        (2, 3): "Compromise — Second Dominating",
        (1, 2): "Magnetic",
        (2, 1): "Magnetic",
    }
    for first in states:
        for second in states:
            result = comparison_channel_activations(first, second, {"channels": [[1, 8]]})["1-8"]
            endpoint_1 = (1 if 1 in first else 0) | (2 if 1 in second else 0)
            endpoint_8 = (1 if 8 in first else 0) | (2 if 8 in second else 0)
            expected = channel_truth_table.get((endpoint_1, endpoint_8), "None")
            check(result == expected, "comparison truth-table mismatch")

    # Harmonics must evaluate the target gate first.  Mercury fixes Earth 8.1
    # through both gate 8 and gate 1; the comparer therefore adds no new flag.
    target_with_primary_fix = {
        "Earth": {"gate": 8, "line": 1},
        "Mercury": {"gate": 8, "line": 1},
    }
    gate_one_mercury = {"Mercury": {"gate": 1, "line": 1}}
    order_sensitive = planetary_fixations(target_with_primary_fix, gate_one_mercury, rules)
    check(order_sensitive["Earth"] == {"state": "Detriment", "changed_by_comparer": False},
          "harmonic source-order fixation mismatch")

    # Four-set composite semantics: the owner's other side establishes the
    # state before either comparator set is considered at the same harmonic.
    target = {"Earth": {"gate": 8, "line": 1}}
    composite_fix = planetary_fixations(
        target,
        gate_one_mercury,
        rules,
        baseline_activations=(gate_one_mercury,),
        additional_comparer_activations=({},),
    )
    transit_fix = planetary_fixations(
        target,
        gate_one_mercury,
        rules,
        additional_comparer_activations=({},),
    )
    check(composite_fix["Earth"]["changed_by_comparer"] is False,
          "same-owner baseline was incorrectly attributed to comparer")
    check(transit_fix["Earth"]["changed_by_comparer"] is True,
          "comparer-added fixation was not detected")

    first_chart = {
        "active_gates": [1, 8],
        "personality_activations": target,
        "design_activations": gate_one_mercury,
    }
    second_chart = {
        "active_gates": [1],
        "personality_activations": gate_one_mercury,
        "design_activations": {},
    }
    composite = build_comparison(
        first_chart,
        second_chart,
        comparison_type="composite",
        first_label="First",
        second_label="Second",
    )
    check(len(composite["channel_activations"]) == 36,
          "comparison must expose all 36 channel states")
    check(
        composite["active_channel_activations"]
        == {k: v for k, v in composite["channel_activations"].items() if v != "None"},
        "active channel-state map is not the non-None subset",
    )
    check(composite["active_channels"] == ["1-8"], "active_channels compatibility changed")
    check(composite["channel_activations"]["1-8"] == "Compromise — First Dominating",
          "composite channel state mismatch")
    check(composite["p1_personality_activations"] == target,
          "composite personality activations missing")
    check(composite["p1_personality_fixations"]["Earth"]["changed_by_comparer"] is False,
          "composite fixation-set semantics mismatch")

    transit = build_comparison(
        first_chart,
        {},
        comparison_type="transit",
        first_label="Natal",
        second_label="Transit",
        second_activations=gate_one_mercury,
    )
    check(transit["personality_activations"] == target, "transit natal activations missing")
    check(transit["transit_activations"] == gate_one_mercury, "transit activations missing")
    check(transit["personality_fixations"]["Earth"]["changed_by_comparer"] is False,
          "transit natal fixation-set semantics mismatch")
    check(set(transit["transit_fixations"]) == {"Mercury"}, "transit fixations missing")

    neptune_at_one = {"Neptune": {"gate": 1, "line": 1}}

    def comparison_chart(
        personality: dict[str, dict[str, int]], design: dict[str, dict[str, int]]
    ) -> dict[str, object]:
        gates = {
            int(activation["gate"])
            for activation_set in (personality, design)
            for activation in activation_set.values()
        }
        return {
            "active_gates": sorted(gates),
            "personality_activations": personality,
            "design_activations": design,
        }

    # Exercise all four composite overload projections, alternating which of
    # the partner's two sides supplies the sole new fixation flag.
    composite_cases = (
        ("p1_personality_fixations", target, {}, {}, neptune_at_one),
        ("p1_design_fixations", {}, target, neptune_at_one, {}),
        ("p2_personality_fixations", {}, neptune_at_one, target, {}),
        ("p2_design_fixations", neptune_at_one, {}, {}, target),
    )
    for fixation_key, p1p, p1d, p2p, p2d in composite_cases:
        result = build_comparison(
            comparison_chart(p1p, p1d),
            comparison_chart(p2p, p2d),
            comparison_type="composite",
            first_label="First",
            second_label="Second",
        )
        check(
            result[fixation_key]["Earth"]
            == {"state": "Exalted", "changed_by_comparer": True},
            f"{fixation_key} did not use both partner comparator sets",
        )

    # Transit itself treats both natal sides as comparers, unlike natal-side
    # transit fixations where the other natal side is part of the baseline.
    for natal_personality, natal_design in ((neptune_at_one, {}), ({}, neptune_at_one)):
        result = build_comparison(
            comparison_chart(natal_personality, natal_design),
            {},
            comparison_type=" Transit ",
            first_label="Natal",
            second_label="Transit",
            second_activations=target,
        )
        check(result["comparison_type"] == "transit", "comparison_type was not normalized")
        check(
            result["transit_fixations"]["Earth"]
            == {"state": "Exalted", "changed_by_comparer": True},
            "transit fixation did not treat both natal sides as comparers",
        )

    template_path = Path(__file__).resolve().parent.parent / "assets" / "longitudes-input-template.json"
    with template_path.open(encoding="utf-8") as handle:
        template = json.load(handle)
    reference_chart = build_natal_chart(
        template["personality"], template["design"], metadata=template["metadata"]
    )
    check(not validate_chart(reference_chart), "reference longitude template failed validation")
    tampered_chart = json.loads(json.dumps(reference_chart))
    tampered_chart["active_gates"] = tampered_chart["active_gates"][:-1]
    check(
        "active_gates is inconsistent with the activation sets" in validate_chart(tampered_chart),
        "chart validation did not detect inconsistent derived mechanics",
    )

    ambiguous = {"birth_local": "2024-11-03T01:30:00", "timezone": "America/New_York"}
    try:
        resolve_moment(ambiguous, "birth")
        raise AssertionError("ambiguous local time was accepted without a fold")
    except HumanDesignError:
        pass
    first_fold, _ = resolve_moment({**ambiguous, "fold": 0}, "birth")
    second_fold, _ = resolve_moment({**ambiguous, "fold": 1}, "birth")
    check((second_fold - first_fold).total_seconds() == 3600, "DST folds do not differ by one hour")
    try:
        resolve_moment(
            {"birth_local": "2024-03-10T02:30:00", "timezone": "America/New_York"},
            "birth",
        )
        raise AssertionError("daylight-saving gap was accepted")
    except HumanDesignError:
        pass

    return {
        "exhaustive_activation_cells": cells,
        "static_rules": 1,
        "graph_cases": len(synthetic) + len(authority_cases),
        "fixation_cases": 5,
        "comparison_cases": 8,
        "validation_cases": 2,
        "civil_time_cases": 4,
    }


def integration_tests(archive: Path) -> dict[str, int]:
    first_time = datetime(2024, 1, 1, tzinfo=timezone.utc)
    with SwissRuntime(archive=archive, years=runtime_years(first_time, first_time.replace(year=1988), first_time.replace(year=1990))) as runtime:
        design_time = runtime.design_time(first_time)
        personality, _ = runtime.positions(first_time, node="true")
        design, _ = runtime.positions(design_time, node="true")
        chart = build_natal_chart(personality, design, metadata={"node_choice": "true"})
        check(not validate_chart(chart), "2024 golden chart failed validation")
        summary = chart["summary"]
        check(summary["type"] == "Generator", "README golden type mismatch")
        check(summary["profile"] == "1/3", "README golden profile mismatch")
        check(summary["authority"] == "Emotional (Solar Plexus)", "README golden authority mismatch")
        check(summary["definition"] == "Split", "README golden definition mismatch")
        check(summary["incarnation_cross"] == "The Right Angle Cross of Tension 4", "README golden cross mismatch")
        check(chart["active_channels"] == ["29-46", "39-55"], "README golden channels mismatch")
        target = (personality["Sun"] - 88.0) % 360.0
        residual = ((design["Sun"] - target + 180.0) % 360.0) - 180.0
        check(abs(residual) <= 1e-5, "design solar-arc residual is too large")

        times = [
            datetime(1988, 9, 4, 1, 15, tzinfo=timezone.utc),
            datetime(1990, 2, 6, 22, 55, tzinfo=timezone.utc),
        ]
        charts = []
        for moment in times:
            design_moment = runtime.design_time(moment)
            p, _ = runtime.positions(moment, node="true")
            d, _ = runtime.positions(design_moment, node="true")
            charts.append(build_natal_chart(p, d, metadata={"node_choice": "true"}))
        composite = build_comparison(
            charts[0], charts[1], comparison_type="composite", first_label="First", second_label="Second"
        )
        expected = {
            "11-56": "First Dominating",
            "12-22": "First Dominating",
            "21-45": "First Dominating",
            "47-64": "First Dominating",
            "28-38": "Second Dominating",
            "10-20": "Compromise — First Dominating",
            "18-58": "Compromise — First Dominating",
            "23-43": "Compromise — Second Dominating",
            "4-63": "Magnetic",
            "5-15": "Magnetic",
        }
        check(composite["active_channel_activations"] == expected, "README composite golden mismatch")
    return {"swiss_golden_charts": 3, "composite_goldens": 1}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--swiss-archive", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result: dict[str, object] = {"pure": pure_tests(), "integration": "skipped"}
    if args.swiss_archive:
        result["integration"] = integration_tests(args.swiss_archive.resolve())
    if args.json:
        print(json.dumps({"status": "passed", **result}, indent=2, sort_keys=True))
    else:
        print("Human Design toolkit tests passed")
        print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
