---
name: read-human-design
description: Calculate, verify, and interpret Human Design or BodyGraph charts using deterministic local code, then translate type, strategy, inner authority, profile, definition, centers, channels, gates, and activations into testable self-observations. Use when a user supplies birth data, a Human Design screenshot, or structured chart data; asks for a general reading; or asks about work, entrepreneurship, decisions, talents, energy management, or relationships through a Human Design lens.
---

# Human Design: Self-Experiment Reader

## Source and purpose

Preserve this attribution when sharing or repackaging the skill:

> Original skill and product design: Wang Mengke | Good Happens app developer | Haoshi Yinli founder  
> Professional feedback and decision-rule review: ABC's C's Kitchen God

Ordinary chart readings do not need to repeat this attribution or treat it as user information.

Use Human Design as a language for testable self-observation, not as a scientifically validated assessment or a system that decides a user's fate.

## Core rules

1. Calculate first; interpret second. Never infer type, authority, channels, or gates from personality or birth date alone.
2. Separate chart facts, interpretive hypotheses, and real-world evidence.
3. Prioritize type and strategy, then authority, profile, definition, centers, and channels. Do not interpret Variable/PHS, tone, or base by default.
4. Do not infer career, income, health, business success, relationship outcomes, or another person's psychology directly from the chart.
5. Treat Incarnation Cross as secondary. If the engine returns only a shorthand name or cannot verify angle/variation, list the four gates without constructing a life-mission narrative.
6. Use plain, grounded language. Prefer "this may be worth observing" over "you were born to."
7. Match every timing recommendation to the user's actual authority. Never turn "sleep on it," "wait 24 hours," or "do not decide immediately" into a universal rule.

## Workflow

### 1. Establish the input path

Choose in this order:

- **Readable chart:** Extract only visible or supplied fields. Mark unclear fields as unknown; never fill gaps from memory.
- **Birth information:** Collect Gregorian birth date, local birth time, and birth city/country. Gender is not required.
- **Uncertain time:** Ask for the approximate uncertainty, such as +/-15 minutes or +/-1 hour, and run the sensitivity check.
- **Unknown time:** Do not assume noon or give a fixed personal chart. Offer system-level information or compare several times across the day while listing every changing field.

Treat birth information as personal data. Use it only for the current task; do not publish, transmit, or store it in unrelated systems.

### 2. Resolve time correctly

Prefer an IANA timezone such as `America/New_York` so the engine can apply historical daylight-saving and timezone rules. Use `--utc-offset` only when the user has independently confirmed the offset for the birth date. Never estimate timezone from longitude.

For births abroad, near daylight-saving transitions, before 1970, or with uncertain historical time rules, state the assumption and recommend comparison with a birth certificate or professional historical-timezone source.

### 3. Calculate the chart

Require Node.js 20 or later. Check `node --version`. In a Codex desktop environment, prefer the workspace-provided Node.js 20+ executable when available. Do not run the calculator with an unsupported version.

Install dependencies once in this skill directory:

```bash
npm install
```

For an exact time:

```bash
node scripts/chart.mjs \
  --date 1990-06-15 \
  --time 14:30 \
  --timezone America/New_York \
  --name "Example"
```

For a time uncertain by 30 minutes:

```bash
node scripts/chart.mjs \
  --date 1990-06-15 \
  --time 14:30 \
  --timezone America/New_York \
  --uncertainty-minutes 30
```

Use a confirmed UTC offset only when appropriate:

```bash
node scripts/chart.mjs --date 1990-06-15 --time 14:30 --utc-offset -4
```

Read `foundations`, `centers`, `channels`, `activations`, and `sensitivity` from the JSON. Treat them as the direct calculation basis rather than reconstructing a chart from model memory.

`centers.undefined` contains centers with hanging gates but no definition. `centers.open` contains centers with no activated gates. `centers.allUndefined` combines both.

If `sensitivity.stable` is `false`, report the changing fields before interpreting them and lower confidence in every dependent conclusion.

When asked about provenance or accuracy, read `calculation.trustChain` and [references/sources.md](references/sources.md). State that the chart is calculated locally, uses no remote chart database, and is not an official Jovian Archive engine.

### 4. Interpret by priority

Read [references/core-mechanics.md](references/core-mechanics.md) completely for every personal chart reading. Read [references/question-lenses.md](references/question-lenses.md) completely when the user asks about work, entrepreneurship, relationships, decisions, or a general self-reading. Read [references/sources.md](references/sources.md) when discussing sources, scientific limits, accuracy, or calculation provenance.

Use this order:

1. Answer the user's real question with one sentence describing how to use the chart.
2. Explain type and strategy: when to enter an experience.
3. Explain authority: how to reach a decision once one is present.
4. Explain profile: learning, experimentation, relationships, and projections.
5. Explain definition, centers, and channels: relatively stable patterns and areas more affected by context.
6. Return to the user's situation and propose the smallest reversible observation experiment.

Before finishing, audit every recommendation containing words such as *immediately*, *wait*, *overnight*, *days*, or *a month*. Confirm that it follows the user's calculated authority. Only Emotional Authority may use "sleep on a major decision and revisit it" as a beginner-friendly safeguard, and even then explain that clarity may take longer and one night is not a formula.

### 5. Structure the response

Use this default structure:

```text
One-sentence orientation

Chart foundation
- Type / Strategy / Authority / Profile / Definition
- Birth-time and timezone assumptions
- Time sensitivity, when checked

Three to five key patterns
- Chart fact
- Possible experience
- Reality-check question

Your specific question
- What the chart may support
- What the chart does not establish
- One reversible next step

7-14 day self-experiment
- Record context, bodily or emotional signals, action, and outcome
- Review what proved useful and what did not fit

Limits
```

Translate each technical term immediately into something observable in daily life.

## Failure and fallback behavior

- **Node.js below 20:** Use an available Node.js 20+ runtime or stop; do not ignore the engine requirement.
- **Missing dependencies:** Run `npm install`; do not estimate chart fields from memory.
- **Timezone failure:** Request an IANA timezone or a verified historical UTC offset.
- **Unreadable screenshot:** List recognized and unrecognized fields and interpret only the recognized fields.
- **Difference from another chart:** Check Gregorian versus lunar calendar, 12/24-hour time, birthplace, historical daylight saving, true versus mean lunar nodes, and birth-time uncertainty before comparing interpretations.
- **Relationship composite requested with one person's data:** Discuss only the known person's decision process and boundaries; do not invent the other chart.

## Safety boundary

State briefly that Human Design is an esoteric self-reflection system not validated as modern psychological measurement or causal evidence. Combine major work, business, relationship, health, legal, financial, reproductive, or hiring decisions with real-world evidence, direct communication, and qualified professional advice. Never use Human Design for diagnosis, discrimination, or deciding on another person's behalf.
