# Calculation conventions and limits

## Vedic astrology

- Zodiac: Lahiri/Chitrapaksha sidereal.
- Houses: whole-sign.
- Nodes: mean Rahu and Ketu for Vedic calculations.
- Ephemeris: Astronomy Engine 2.1.19.
- Validated date range: 1700–2100.
- Divisional charts: D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, D16, D20, D24, D27, D30, D45, D60, D81, D108, and D144.
- D40 is deliberately not implemented because the source project did not ship an unverified rule.
- Included layers: planets, houses, nakshatras and padas, panchanga, Vimshottari mahadashas and antardashas, Jaimini chara karakas, K.N. Rao Chara Dasha, karakamsa, arudhas, upapada, ashtakavarga, yogi/avayogi, dignity, combustion, vargottama, Jaimini sign aspects, and general angular aspects.

## Other systems

- Human Design uses the true lunar node and requires a known birth time. The engine calculates chart mechanics but provides no proprietary interpretive text.
- Matrix of Destiny uses birth-date arithmetic and does not require a birth time.
- Tropical output uses whole-sign houses from the tropical ascendant.

## Unknown birth time

Omitting the time creates a noon cast and sets `meta.timeUnknown` and `meta.noonCast` to `true`. Treat the following as unreliable or unavailable: Ascendant, houses, varga lagnas and houses, arudhas, upapada, Chara Dasha, exact Vimshottari dates, panchanga at birth, and Human Design. Do not silently present noon-derived values as natal facts.

Planetary signs can sometimes remain stable across the day, but verify the full date range before calling them stable. The Moon, nakshatra, pada, and dasha balance can change materially during a day.

## Interpretation boundary

The runtime calculates structured chart data; it does not prove spiritual claims or supply authoritative interpretations. Label calculated placements separately from interpretive conclusions. Do not use these systems as medical, legal, financial, or psychological diagnosis.
