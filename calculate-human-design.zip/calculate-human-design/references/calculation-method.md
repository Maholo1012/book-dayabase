# Calculation Method

## Conventions

- Zodiac: tropical only.
- Coordinate: geocentric ecliptic longitude, normalized to `[0, 360)`.
- Default lunar node: true or osculating node; the mean node is an explicit option.
- Personality moment: verified birth UTC.
- Design moment: the prior instant when the tropical Sun is exactly 88 degrees behind its birth longitude. The Swiss adapter brackets this event 70–110 days before birth and solves it by bisection to within 0.25 seconds. It is not a fixed “88 days before birth” shortcut.
- Earth: Sun longitude + 180 degrees.
- South Node: North Node longitude + 180 degrees.

The 13 emitted bodies, in source order, are Sun, Earth, North Node, South Node, Moon, Mercury, Uranus, Venus, Mars, Neptune, Saturn, Jupiter, and Pluto.

## Rave-wheel subdivision

The mapping uses a 3.875-degree wheel offset and the 64-gate sequence stored in `assets/hd_rules.json`.

| Level | Count | Angular width |
|---|---:|---:|
| Gate | 64 | 5.625 degrees |
| Line per gate | 6 | 0.9375 degrees |
| Color per line | 6 | 0.15625 degrees |
| Tone per color | 6 | 0.0260416666667 degrees |
| Base per tone | 5 | 0.00520833333333 degrees (18.75 arcseconds) |

Intervals are zero-based internally and mathematically half-open. Public gate, line, color, tone, and base values are one-based. To reproduce the upstream implementation at machine precision, every subdivision uses an independent floating-point remainder. An exactly stated decimal boundary can therefore resolve to an adjacent tone or base because most of those widths are not exactly representable as binary doubles; the warning fields make that edge visible.

The upstream README states 15.625 arcseconds for a base, but the executable source divides each tone into five bases, yielding 18.75 arcseconds. This toolkit follows the executable source and its five-value `Base` enumeration.

## Mechanics derived from activations

- A channel is active when both endpoint gates appear anywhere across personality and design.
- Defined centers and definition or split count come from connected components of active channels.
- Type and authority follow the graph-based precedence rules in `scripts/hd_core.py`.
- Profile is Personality Sun line / Design Sun line.
- Incarnation cross uses the profile angle plus the Personality Sun gate, with all 192 mappings stored in the rules asset. The four displayed gates are Personality Sun/Earth and Design Sun/Earth.
- Variables use the upstream source implementation: Digestion from Design Sun, Awareness from Personality Sun, Environment from Design North Node, and Perspective from Personality North Node. Tones 1–3 orient left and tones 4–6 orient right.
- Fixations use the upstream planetary gate and line rules, including target-first harmonic ordering. Natal sides compare against each other; composite sides use the same person's other side as baseline and both partner sides as comparers; transit treats both natal sides as baseline when evaluating natal activations, and as comparers when evaluating transit activations. Nodes have no explicit fixation cases and therefore remain `None` unless harmonic comparison logic changes the evaluated state.
- Strategy is a clearly disclosed convenience label mapped from the calculated type. It is not a field in the upstream 1.2.0 chart API.

## Precision warnings

Every activation records its angular distance from the nearest gate, line, color, tone, and base boundary. Warnings are emitted within 30, 15, 5, 2, and 1 arcseconds respectively. These are caution thresholds, not error bars. When a relevant result is close to a boundary, state what birth-time or ephemeris change could alter it and use the range scan when possible.

In Swiss mode, planets use apparent geocentric positions with extra-precision output. The node is queried separately with true-position, no-aberration, and no-gravitational-deflection flags to match the recommended upstream provider behavior at fine-grid precision.

## Source of truth

The mechanics and tables were ported from `CReizner/SharpAstrology.HumanDesign` version 1.2.0 at commit `5d95ece57098fd776df7f2362722c1392a6f06b6`. Where prose and executable source disagree, this toolkit follows the executable source and documents the discrepancy.
