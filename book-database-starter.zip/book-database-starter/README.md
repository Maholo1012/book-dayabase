# Book Database

A public bookshelf: browse the catalog, open a book, and download a copy.

## Book catalog

| ID | Title | Author | Subject | Format | Access |
| --- | --- | --- | --- | --- | --- |
| BOOK-001 | Starter Sample: A Tiny Bookshelf | Starter repository example | Reference | TXT | [Open sample](books/reference/starter_sample_v1.txt) |

The sample is original demonstration text, not an uploaded commercial book.
Add one row here whenever you add a book. This table is edited manually.

**Browse all files:** [books](books/).  
**Full inventory:** [books.csv](catalog/books.csv).

## Read or download

1. Click a title's **Access** link.
2. On a GitHub file page, use the download icon (**Download raw file**) to save it. Text files also have a **Raw** view.
3. For an external link, use that site's download controls.

Use your browser's Find command to search this catalog: **Ctrl+F** on Windows or **Command+F** on Mac. This searches the displayed page, not the text inside every book.

## Set up or add books

- [Workflow and folder map](README_01_Book_Database_Workflow.md)
- [Click-by-click setup, uploads, and troubleshooting](README_02_Book_Database_Instructions_Scripts.md)

Keep original books in `books/`, organized by subject. Keep metadata in `catalog/books.csv` and clickable links in the table above. Updating the CSV does not automatically update this page.

## Sharing

Upload books you have permission to redistribute, such as your own work or suitable public-domain/openly licensed editions. Record the sharing basis and source in the inventory. For other books, catalog a publisher or authorized access link instead of uploading the book.

Each book retains its own permissions. There is no blanket license for this collection.
