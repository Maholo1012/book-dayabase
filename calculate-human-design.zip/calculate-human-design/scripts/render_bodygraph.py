#!/usr/bin/env python3
"""Render a clean, original SVG mechanics summary and a Markdown report."""

from __future__ import annotations

import html
from typing import Any, Mapping


CENTER_POSITIONS = {
    "Crown": (450, 135),
    "Mind": (450, 245),
    "Throat": (450, 365),
    "Self": (450, 520),
    "Heart": (570, 520),
    "Spleen": (270, 690),
    "Emotions": (630, 690),
    "Sacral": (450, 735),
    "Root": (450, 910),
}


def _escape(value: object) -> str:
    return html.escape(str(value), quote=True)


def render_bodygraph_svg(chart: Mapping[str, Any]) -> str:
    summary = chart.get("summary", {})
    centers = chart.get("centers", {})
    active_channels = chart.get("active_channels", [])
    active_gates = {int(gate) for gate in chart.get("active_gates", [])}
    gate_centers: dict[int, str] = {}
    from hd_core import load_rules

    rules = load_rules()
    gate_centers = {int(k): v for k, v in rules["gate_centers"].items()}
    channel_pairs = [tuple(map(int, item.split("-"))) for item in active_channels]
    lines: list[str] = []
    pair_counts: dict[tuple[str, str], int] = {}
    for first, second in channel_pairs:
        a, b = gate_centers[first], gate_centers[second]
        key = tuple(sorted((a, b)))
        index = pair_counts.get(key, 0)
        pair_counts[key] = index + 1
        x1, y1 = CENTER_POSITIONS[a]
        x2, y2 = CENTER_POSITIONS[b]
        offset = (index - 1) * 7
        lines.append(
            f'<path d="M {x1 + offset} {y1} Q {(x1+x2)/2 + offset*2:.1f} {(y1+y2)/2:.1f} {x2 + offset} {y2}" '
            'fill="none" stroke="#6D28D9" stroke-width="5" stroke-linecap="round" opacity="0.78"/>'
        )
        mx, my = (x1 + x2) / 2 + offset, (y1 + y2) / 2
        lines.append(
            f'<text x="{mx:.1f}" y="{my - 5:.1f}" text-anchor="middle" class="channel">{first}–{second}</text>'
        )

    nodes: list[str] = []
    shapes = {
        "Crown": "triangle",
        "Mind": "triangle-down",
        "Throat": "square",
        "Self": "diamond",
        "Heart": "triangle",
        "Spleen": "triangle-right",
        "Emotions": "triangle-left",
        "Sacral": "square",
        "Root": "square",
    }
    center_colors = {
        "Crown": "#FDE68A",
        "Mind": "#A7F3D0",
        "Throat": "#D1D5DB",
        "Self": "#FDE047",
        "Heart": "#F59E0B",
        "Spleen": "#A3E635",
        "Emotions": "#FCA5A5",
        "Sacral": "#FB923C",
        "Root": "#F87171",
    }
    gates_by_center = {
        center: sorted(gate for gate in active_gates if gate_centers.get(gate) == center)
        for center in CENTER_POSITIONS
    }
    for center, (x, y) in CENTER_POSITIONS.items():
        defined = bool(centers.get(center, {}).get("defined"))
        fill = center_colors[center] if defined else "#FFFFFF"
        stroke = "#312E81" if defined else "#9CA3AF"
        shape = shapes[center]
        if shape == "square":
            element = f'<rect x="{x-55}" y="{y-40}" width="110" height="80" rx="12"/>'
        elif shape == "diamond":
            element = f'<polygon points="{x},{y-58} {x+70},{y} {x},{y+58} {x-70},{y}"/>'
        elif shape == "triangle-down":
            element = f'<polygon points="{x-70},{y-48} {x+70},{y-48} {x},{y+58}"/>'
        elif shape == "triangle-right":
            element = f'<polygon points="{x-58},{y-62} {x-58},{y+62} {x+70},{y}"/>'
        elif shape == "triangle-left":
            element = f'<polygon points="{x+58},{y-62} {x+58},{y+62} {x-70},{y}"/>'
        else:
            element = f'<polygon points="{x},{y-62} {x+70},{y+52} {x-70},{y+52}"/>'
        element = element.replace("/>", f' fill="{fill}" stroke="{stroke}" stroke-width="4"/>')
        nodes.append(element)
        nodes.append(f'<text x="{x}" y="{y-3}" text-anchor="middle" class="center">{_escape(center)}</text>')
        gate_text = ", ".join(map(str, gates_by_center[center])) or "—"
        nodes.append(f'<text x="{x}" y="{y+20}" text-anchor="middle" class="gates">{gate_text}</text>')

    calculation = chart.get("calculation", {})
    comparison_type = chart.get("comparison_type")
    labels = chart.get("labels", {})
    if summary:
        chart_label = calculation.get("chart_label")
        title = f"{chart_label} · {summary.get('type')}" if chart_label else summary.get("type", "Human Design")
        subtitle_parts = [
            summary.get("authority"),
            f"Profile {summary['profile']}" if summary.get("profile") else None,
            summary.get("definition"),
        ]
    else:
        kind = str(comparison_type or "comparison").title()
        title = f"{kind}: {labels.get('first', 'First')} + {labels.get('second', 'Second')}"
        subtitle_parts = [chart.get("definition"), f"{len(active_channels)} active channels"]
    subtitle = " · ".join(str(item) for item in subtitle_parts if item)
    return "\n".join(
        [
            '<svg xmlns="http://www.w3.org/2000/svg" width="900" height="1080" viewBox="0 0 900 1080" role="img" aria-labelledby="title desc">',
            f'<title id="title">Human Design mechanics summary: {_escape(title)}</title>',
            '<desc id="desc">Defined centers and active channels calculated from planetary longitudes.</desc>',
            '<rect width="900" height="1080" fill="#FAFAFF"/>',
            '<style>.title{font:700 30px system-ui,sans-serif;fill:#1F2937}.subtitle{font:16px system-ui,sans-serif;fill:#4B5563}.center{font:700 15px system-ui,sans-serif;fill:#111827}.gates{font:12px system-ui,sans-serif;fill:#374151}.channel{font:700 11px system-ui,sans-serif;fill:#4C1D95;paint-order:stroke;stroke:#FAFAFF;stroke-width:4px}</style>',
            f'<text x="450" y="35" text-anchor="middle" class="title">{_escape(title)}</text>',
            f'<text x="450" y="60" text-anchor="middle" class="subtitle">{_escape(subtitle)}</text>',
            *lines,
            *nodes,
            '<text x="450" y="1035" text-anchor="middle" class="subtitle">Original mechanics diagram · filled centers are defined · numbers label active gates/channels</text>',
            '<text x="450" y="1060" text-anchor="middle" class="gates">For reflective use; not scientific, medical, legal, or financial guidance.</text>',
            '</svg>',
            '',
        ]
    )


def render_summary_markdown(chart: Mapping[str, Any]) -> str:
    summary = chart.get("summary", {})
    calculation = chart.get("calculation", {})
    comparison_type = chart.get("comparison_type")
    title = (
        "# Human Design Calculation Summary"
        if summary
        else f"# Human Design {str(comparison_type or 'Comparison').title()} Summary"
    )
    lines = [title, ""]
    if summary:
        lines.extend(
            [
                "## Core mechanics",
                "",
                f"- Type: {summary.get('type', '—')}",
                f"- Strategy: {summary.get('strategy', '—')}",
                f"- Authority: {summary.get('authority', '—')}",
                f"- Profile: {summary.get('profile', '—')}",
                f"- Definition: {summary.get('definition', '—')}",
                f"- Incarnation cross: {summary.get('incarnation_cross', '—')}",
                f"- Cross gates: {', '.join(map(str, summary.get('incarnation_cross_gates', [])))}",
                "",
            ]
        )
    else:
        labels = chart.get("labels", {})
        lines.extend(
            [
                "## Comparison mechanics",
                "",
                f"- Mode: {comparison_type or '—'}",
                f"- First: {labels.get('first', '—')}",
                f"- Second: {labels.get('second', '—')}",
                f"- Definition: {chart.get('definition', '—')}",
                f"- Connected components: {chart.get('splits', '—')}",
                "",
            ]
        )
    lines.extend(["## Centers", ""])
    for center, details in sorted(chart.get("centers", {}).items()):
        status = "Defined" if details.get("defined") else "Undefined"
        provenance = details.get("provenance")
        suffix = f" · {provenance}" if provenance and provenance != "Undefined" else ""
        lines.append(f"- {center}: {status}{suffix}")
    lines.extend(["", "## Active channels", ""])
    channels = chart.get("active_channels", [])
    channel_states = chart.get("active_channel_activations", {})
    lines.extend(
        f"- {channel}: {channel_states[channel]}" if channel in channel_states else f"- {channel}"
        for channel in channels
    )
    if not channels:
        lines.append("- None")
    if chart.get("variables"):
        lines.extend(["", "## Variables", ""])
        for key, variable in chart["variables"].items():
            lines.append(
                f"- {key.title()}: {variable['orientation']}, color {variable['color']}, "
                f"tone {variable['tone']}, base {variable['base']}"
            )
    fixation_sets = {
        key: value
        for key, value in chart.items()
        if key.endswith("_fixations") and isinstance(value, Mapping)
    }
    if fixation_sets and not summary:
        lines.extend(["", "## Fixations affected by comparison", ""])
        changed_lines: list[str] = []
        for set_name, values in fixation_sets.items():
            changed = [
                f"{planet} ({details.get('state', 'None')})"
                for planet, details in values.items()
                if details.get("changed_by_comparer")
            ]
            if changed:
                display_name = set_name.replace("_", " ").title()
                changed_lines.append(f"- {display_name}: {', '.join(changed)}")
        lines.extend(changed_lines or ["- None"])

    disclosure = calculation or chart.get("metadata", {})
    lines.extend(["", "## Calculation disclosure", ""])
    lines.append(f"- Zodiac: {disclosure.get('zodiac', 'tropical')}")
    lines.append(f"- Node choice: {disclosure.get('node_choice', 'not recorded')}")
    lines.append(f"- Ephemeris: {disclosure.get('ephemeris', 'not recorded')}")
    if disclosure.get("swetest_version"):
        lines.append(f"- swetest version: {disclosure['swetest_version']}")
    source = disclosure.get("rules_source", {})
    if source:
        lines.append(
            f"- Rules: {source.get('project', 'unknown')} {source.get('version', '')} "
            f"(commit {source.get('commit', 'unknown')})"
        )
    if disclosure.get("birth_time"):
        lines.append(f"- Birth UTC: {disclosure['birth_time'].get('utc', 'not recorded')}")
    if disclosure.get("design_utc"):
        lines.append(f"- Design UTC: {disclosure['design_utc']}")
    if disclosure.get("transit_time"):
        lines.append(f"- Transit UTC: {disclosure['transit_time'].get('utc', 'not recorded')}")
    if disclosure.get("swiss_archive_sha256"):
        lines.append(f"- Swiss archive SHA-256: `{disclosure['swiss_archive_sha256']}`")
    warnings = chart.get("boundary_warnings", [])
    lines.extend(["", "## Precision warnings", ""])
    if warnings:
        lines.extend(f"- {warning}" for warning in warnings)
    else:
        lines.append("- No configured near-boundary warnings were triggered.")
    lines.extend(
        [
            "",
            "## Interpretation boundary",
            "",
            "This file reports calculated Human Design mechanics. Treat interpretations as a reflective framework, not scientifically validated fact or professional advice. Use approved references for narrative meanings.",
            "",
        ]
    )
    return "\n".join(lines)
