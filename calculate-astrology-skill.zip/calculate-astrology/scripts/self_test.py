#!/usr/bin/env python3
"""Regression checks for the adapted local astrology skill."""

from __future__ import annotations

from datetime import datetime
import json
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import astro_engine as astro  # noqa: E402


FIXTURE = {
    "year": 1990,
    "month": 6,
    "day": 15,
    "hour": 14,
    "minute": 30,
    "lat": 40.7128,
    "lng": -74.0060,
    "tz": "America/New_York",
    "time_known": True,
    "systems": ["western", "vedic", "bazi"],
}


def expect_value_error(fn, contains: str) -> None:
    try:
        fn()
    except ValueError as exc:
        assert contains.lower() in str(exc).lower(), (contains, str(exc))
    else:
        raise AssertionError(f"Expected ValueError containing {contains!r}")


def angular_error(a: float, b: float) -> float:
    return abs(astro.norm180(a - b))


def main() -> None:
    profile = astro.calculate_full_profile(dict(FIXTURE))
    assert profile["charts"]["western"]["big_three"] == {
        "sun": "Gemini", "moon": "Pisces", "rising": "Libra"
    }
    assert profile["charts"]["vedic"]["lagna"]["sign"] == "Virgo"
    assert profile["navamsa"]["navamsa_lagna"]["sign"] == "Gemini"
    assert profile["navamsa"]["navamsa_lagna"]["boundary_warning"] is True
    assert profile["navamsa"]["warnings"]

    utc, _ = astro.to_utc(dict(FIXTURE))
    jd = astro.julian_day(utc)
    assert astro.varga_chart(jd, "D60", FIXTURE["lat"], FIXTURE["lng"], True)["planets"]["Moon"]["sign"] == "Gemini"
    for sign_index in range(12):
        assert astro._varga_position(sign_index * 30 + 0.1, 60)["sign"] == "Aries"

    for division in (2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 16, 20, 24, 27, 30, 40, 45, 60):
        varga = astro.varga_chart(jd, f"D{division}", FIXTURE["lat"], FIXTURE["lng"], True)
        assert varga["divisions"] == division
        assert varga["planets"]["Sun"]["sign"] in astro.SIGNS

    unknown = astro.calculate_full_profile({
        "year": 1990, "month": 6, "day": 15, "time_known": False,
        "systems": ["western", "vedic", "bazi"],
    })
    western = unknown["charts"]["western"]
    assert western["big_three"]["rising"] is None
    assert western["ascendant"] is None and western["houses"] == {}
    assert all(p["house"] is None for p in western["planets"].values())
    assert unknown["charts"]["vedic"]["lagna"] is None
    assert unknown["charts"]["vedic"]["vimshottari_dasha"] is None
    assert unknown["navamsa"]["navamsa_lagna"] is None
    assert unknown["charts"]["bazi"]["four_pillars"]["hour"] is None
    assert "hour" not in unknown["charts"]["bazi"]["ten_gods"]
    assert unknown["panchang"]["status"] == "withheld"

    # Regression for the final fixed karanas, which previously indexed past
    # the lookup table near the end of the lunar month.
    panchang_jd = astro.julian_day(datetime(2026, 1, 17, 12, 0))
    assert astro.panchang_elements(panchang_jd)["karana"]["name"] in astro.KARANAS
    expected_karanas = {
        0: "Kinstughna", 1: "Bava", 7: "Vishti", 8: "Bava",
        56: "Vishti", 57: "Shakuni", 58: "Chatushpada", 59: "Naga",
    }
    for half_tithi, expected in expected_karanas.items():
        assert astro._karana_name(half_tithi * 6 + 0.1) == expected

    bazi_boundary = astro.calculate_full_profile({
        "year": 2024, "month": 2, "day": 4, "tz": "Asia/Shanghai",
        "time_known": False, "systems": ["bazi"],
    })["charts"]["bazi"]
    assert bazi_boundary["solar_term_boundary_warning"]
    assert bazi_boundary["four_pillars"]["year"] is None
    assert bazi_boundary["four_pillars"]["month"] is None
    assert len(bazi_boundary["pillar_options"]["year"]) == 2
    assert len(bazi_boundary["pillar_options"]["month"]) == 2

    phases = astro.upcoming_moon_phases(jd, 4)
    assert len(phases) == 4
    assert all(a["julian_day"] < b["julian_day"] for a, b in zip(phases, phases[1:]))
    assert [p["phase"] for p in phases] == [
        "Last Quarter", "New Moon", "First Quarter", "Full Moon"
    ]
    assert astro._moon_phase_name(0) == "New Moon"
    assert astro._moon_phase_name(30) == "Waxing Crescent"
    assert astro._moon_phase_name(100) == "First Quarter"
    assert astro._moon_phase_name(130) == "Waxing Gibbous"
    assert astro._moon_phase_name(190) == "Full Moon"
    assert astro._moon_phase_name(350) == "New Moon"

    solar = astro.solar_return(jd, 2027, FIXTURE["lat"], FIXTURE["lng"])
    assert angular_error(solar["return_sun_lon"], solar["natal_sun_lon"]) < 0.001
    lunar = astro.lunar_return(jd, 2027, 3, FIXTURE["lat"], FIXTURE["lng"])
    assert angular_error(lunar["return_moon_lon"], lunar["natal_moon_lon"]) < 0.001

    # A relocated return changes angles but never the natal longitude or return
    # instant, because natal and return locations are separate inputs.
    solar_home = astro.calculate_full_profile({**FIXTURE, "mode": "solar_return", "target_year": 2027})["solar_return"]
    solar_london = astro.calculate_full_profile({
        **FIXTURE, "mode": "solar_return", "target_year": 2027,
        "return_location": {"place": "London", "lat": 51.5074, "lng": -0.1278},
    })["solar_return"]
    assert solar_home["return_moment_utc"] == solar_london["return_moment_utc"]
    assert solar_home["natal_sun_lon"] == solar_london["natal_sun_lon"]
    assert solar_home["chart"]["ascendant"] != solar_london["chart"]["ascendant"]

    if astro._HAS_TZDB:
        expect_value_error(lambda: astro.to_utc({
            "year": 2024, "month": 3, "day": 10, "hour": 2, "minute": 30,
            "tz": "America/New_York", "time_known": True,
        }), "does not exist")
        ambiguous = {
            "year": 2024, "month": 11, "day": 3, "hour": 1, "minute": 30,
            "tz": "America/New_York", "time_known": True,
        }
        expect_value_error(lambda: astro.to_utc(dict(ambiguous)), "ambiguous")
        first, _ = astro.to_utc({**ambiguous, "fold": 0})
        second, _ = astro.to_utc({**ambiguous, "fold": 1})
        assert (second - first).total_seconds() == 3600
        expect_value_error(lambda: astro.to_utc({
            "year": 2024, "month": 1, "day": 1, "hour": 12,
            "tz": "Not/A_Zone", "time_known": True,
        }), "invalid")

    expect_value_error(lambda: astro.calculate_full_profile({
        **FIXTURE, "mode": "astrocartography"
    }), "disabled")
    expect_value_error(lambda: astro.calculate_full_profile({
        **FIXTURE, "mode": "made_up"
    }), "unsupported")
    expect_value_error(lambda: astro.calculate_full_profile({
        "year": 1990, "month": 6, "day": 15, "hour": 14,
        "tz": "America/New_York", "time_known": True,
    }), "latitude")
    expect_value_error(lambda: astro.calculate_full_profile({
        "year": 1990, "month": 6, "day": 15,
        "lat": 40.7128, "lng": -74.0060, "tz": "America/New_York",
        "time_known": True,
    }), "clock hour")
    expect_value_error(lambda: astro.calculate_full_profile({
        "year": 1990, "month": 6, "day": 15, "time_known": False,
        "mode": "panchang",
    }), "exact")
    expect_value_error(lambda: astro.calculate_full_profile({
        "year": 1990, "month": 6, "day": 15, "time_known": False,
        "mode": "solar_return", "target_year": 2027,
    }), "reliable natal time")
    expect_value_error(lambda: astro.calculate_full_profile({
        "year": 1990, "month": 6, "day": 15, "time": "not-a-time",
        "lat": 40.7128, "lng": -74.0060, "tz": "America/New_York",
        "time_known": True,
    }), "clock hour")

    transit_local = astro.calculate_full_profile({
        **FIXTURE, "mode": "transit", "transit_date": "2024-01-01",
        "transit_tz": "Pacific/Kiritimati",
    })["transits"]
    assert transit_local["transit_moment_utc"] == "2023-12-31 22:00"
    assert transit_local["time_info"]["source"] == "local noon for date-only transit"

    partner = {
        "year": 1992, "month": 9, "day": 4, "hour": 9, "minute": 15,
        "lat": 34.0522, "lng": -118.2437, "tz": "America/Los_Angeles",
        "time_known": True,
    }
    smoke_cases = [
        ({**FIXTURE, "mode": "transit", "transit_date": "2027-01-15"}, "transits"),
        ({**FIXTURE, "mode": "transit_natal_aspects", "transit_date": "2027-01-15"}, "transit_natal_aspects"),
        ({**FIXTURE, "mode": "synastry", "partner": dict(partner)}, "synastry"),
        ({**FIXTURE, "mode": "compatibility", "partner": dict(partner)}, "compatibility"),
        ({**FIXTURE, "mode": "composite", "partner": dict(partner)}, "composite"),
        ({**FIXTURE, "mode": "event", "subject": "Test launch"}, "event_chart"),
        ({**FIXTURE, "mode": "navamsa"}, "navamsa"),
        ({**FIXTURE, "mode": "panchang"}, "panchang"),
        ({**FIXTURE, "mode": "moon_phase"}, "moon_phase"),
        ({**FIXTURE, "mode": "numerology", "full_name": "Test Person"}, "numerology"),
    ]
    for case, expected_key in smoke_cases:
        assert expected_key in astro.calculate_full_profile(case), expected_key

    # Exercise the public JSON command path as well as direct imports.
    command = [sys.executable, str(SCRIPT_DIR / "astro_engine.py"), "--json", json.dumps({
        **FIXTURE, "mode": "varga", "varga": "D10"
    })]
    parsed = json.loads(subprocess.check_output(command, text=True))
    assert parsed["varga"]["divisions"] == 10

    print("All calculate-astrology regression checks passed.")


if __name__ == "__main__":
    main()
