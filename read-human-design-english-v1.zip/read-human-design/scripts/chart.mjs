#!/usr/bin/env node

import { pathToFileURL } from 'node:url';
import {
  calculateHumanDesign,
  formatUtcOffset,
  resolveUtcOffset,
} from 'natalengine';

const ENGINE_VERSION = 'natalengine 1.6.0';
const EPHEMERIS_VERSION = 'astronomy-engine 2.1.19';

const HELP = `
Human Design chart calculator (JSON output)

Usage:
  node scripts/chart.mjs --date YYYY-MM-DD --time HH:MM \\
    (--timezone IANA_NAME | --utc-offset HOURS) [options]

Required:
  --date YYYY-MM-DD           Local Gregorian birth date
  --time HH:MM                Local birth time in 24-hour format
  --timezone America/New_York IANA timezone (preferred; handles historical DST)
  --utc-offset -04:00         Independently verified UTC offset for that date

Options:
  --name TEXT                 Person name or chart label
  --place TEXT                Birthplace note (not used in calculation)
  --uncertainty-minutes N     Check core-field stability N minutes before and after
  --compact                   Output JSON without indentation
  --help                      Show this help

Example:
  node scripts/chart.mjs --date 1990-06-15 --time 14:30 \\
    --timezone America/New_York --uncertainty-minutes 30
`;

class UsageError extends Error {}

export function parseArgs(argv) {
  const result = {};
  const flags = new Set(['help', 'compact']);
  const accepted = new Set([
    'date',
    'time',
    'timezone',
    'utc-offset',
    'name',
    'place',
    'uncertainty-minutes',
    ...flags,
  ]);

  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith('--')) {
      throw new UsageError(`Unrecognized positional argument: ${token}`);
    }
    const key = token.slice(2);
    if (!accepted.has(key)) {
      throw new UsageError(`Unrecognized option: --${key}`);
    }
    if (flags.has(key)) {
      result[key] = true;
      continue;
    }
    const value = argv[index + 1];
    if (value === undefined || value.startsWith('--')) {
      throw new UsageError(`--${key} requires a value`);
    }
    result[key] = value;
    index += 1;
  }

  return result;
}

export function parseDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value || '');
  if (!match) throw new UsageError('--date must use YYYY-MM-DD');
  const [, yearText, monthText, dayText] = match;
  const year = Number(yearText);
  const month = Number(monthText);
  const day = Number(dayText);
  const check = new Date(Date.UTC(year, month - 1, day));
  if (
    check.getUTCFullYear() !== year
    || check.getUTCMonth() + 1 !== month
    || check.getUTCDate() !== day
  ) {
    throw new UsageError(`Invalid date: ${value}`);
  }
  return { year, month, day, text: value };
}

export function parseTime(value) {
  const match = /^(\d{2}):(\d{2})$/.exec(value || '');
  if (!match) throw new UsageError('--time must use 24-hour HH:MM');
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (hour > 23 || minute > 59) throw new UsageError(`Invalid time: ${value}`);
  return { hour, minute, text: value };
}

export function parseUtcOffset(value) {
  const match = /^([+-])?(\d{1,2})(?::?(\d{2}))?(?:\.(\d+))?$/.exec(value || '');
  if (!match) {
    throw new UsageError('--utc-offset must be hours or +/-HH:MM, such as 8, -4, or +05:30');
  }
  const sign = match[1] === '-' ? -1 : 1;
  const hours = Number(match[2]);
  const minutePart = match[3] ? Number(match[3]) / 60 : 0;
  const decimalPart = match[4] ? Number(`0.${match[4]}`) : 0;
  if (match[3] && match[4]) {
    throw new UsageError('--utc-offset cannot use both minutes and a decimal fraction');
  }
  if (match[3] && Number(match[3]) > 59) throw new UsageError('UTC offset minutes must be below 60');
  const offset = sign * (hours + minutePart + decimalPart);
  if (Math.abs(offset) > 14) throw new UsageError('UTC offset must be between -14 and +14 hours');
  return offset;
}

function pad(value) {
  return String(value).padStart(2, '0');
}

export function shiftWallTime(date, time, deltaMinutes) {
  const dateParts = parseDate(date);
  const timeParts = parseTime(time);
  const shifted = new Date(Date.UTC(
    dateParts.year,
    dateParts.month - 1,
    dateParts.day,
    timeParts.hour,
    timeParts.minute + deltaMinutes,
  ));
  return {
    date: `${shifted.getUTCFullYear()}-${pad(shifted.getUTCMonth() + 1)}-${pad(shifted.getUTCDate())}`,
    time: `${pad(shifted.getUTCHours())}:${pad(shifted.getUTCMinutes())}`,
  };
}

function resolveOffset(date, time, options) {
  if (options.timezone && options['utc-offset'] !== undefined) {
    throw new UsageError('Use either --timezone or --utc-offset, not both');
  }
  if (!options.timezone && options['utc-offset'] === undefined) {
    throw new UsageError('Provide --timezone or --utc-offset');
  }
  if (options.timezone) {
    try {
      return {
        hours: resolveUtcOffset(date, time, options.timezone),
        source: 'IANA historical timezone',
        timezone: options.timezone,
      };
    } catch (error) {
      throw new UsageError(`Timezone resolution failed (${options.timezone}): ${error.message}`);
    }
  }
  return {
    hours: parseUtcOffset(options['utc-offset']),
    source: 'user-confirmed UTC offset',
    timezone: null,
  };
}

function rounded(value, digits = 6) {
  if (typeof value !== 'number') return value ?? null;
  return Number(value.toFixed(digits));
}

function activationList(group = {}) {
  return Object.entries(group).map(([key, value]) => ({
    planet: value?.planet || key,
    gate: value?.gate ?? null,
    line: value?.line ?? null,
    gateLine: value?.gate && value?.line ? `${value.gate}.${value.line}` : null,
    name: value?.name || null,
    longitude: rounded(value?.longitude),
  }));
}

function centerNames(centers, key) {
  const namesKey = `${key}Names`;
  if (Array.isArray(centers?.[namesKey])) return [...centers[namesKey]].sort();
  if (Array.isArray(centers?.[key])) {
    return centers[key]
      .map((item) => (typeof item === 'string' ? item : item?.name))
      .filter(Boolean)
      .sort();
  }
  return [];
}

function channelList(channels = []) {
  return channels.map((channel) => ({
    gates: Array.isArray(channel.gates) ? channel.gates : [],
    key: Array.isArray(channel.gates) ? [...channel.gates].sort((a, b) => a - b).join('-') : null,
    name: channel.name || null,
    centers: Array.isArray(channel.centers) ? channel.centers : [],
    circuit: channel.circuit || null,
    subcircuit: channel.subcircuit || null,
    description: channel.description || null,
  })).sort((left, right) => (left.key || '').localeCompare(right.key || '', 'en', { numeric: true }));
}

function crossSummary(cross) {
  if (!cross) return null;
  return {
    name: cross.name || null,
    gates: Array.isArray(cross.gates) ? cross.gates : null,
    theme: cross.theme || null,
  };
}

export function summarizeChart(chart) {
  const channels = channelList(chart.channels);
  return {
    foundations: {
      type: chart.type?.name || null,
      strategy: chart.type?.strategy || null,
      authority: chart.authority?.name || chart.type?.authority || null,
      authorityDescription: chart.authority?.description || null,
      profile: chart.profile?.numbers || null,
      profileName: chart.profile?.name || null,
      definition: typeof chart.definition === 'string'
        ? chart.definition
        : chart.definition?.name || null,
      signature: chart.type?.signature || null,
      notSelfTheme: chart.type?.notSelf || null,
      incarnationCross: crossSummary(chart.incarnationCross),
    },
    centers: {
      defined: centerNames(chart.centers, 'defined'),
      undefined: centerNames(chart.centers, 'undefined'),
      open: centerNames(chart.centers, 'open'),
      allUndefined: Array.isArray(chart.centers?.allUndefinedNames)
        ? [...chart.centers.allUndefinedNames].sort()
        : [...new Set([
          ...centerNames(chart.centers, 'undefined'),
          ...centerNames(chart.centers, 'open'),
        ])].sort(),
    },
    channels,
    activations: {
      personality: activationList(chart.gates?.personality),
      design: activationList(chart.gates?.design),
      allActiveGates: Array.isArray(chart.gates?.all) ? [...chart.gates.all].sort((a, b) => a - b) : [],
    },
  };
}

function coreSnapshot(summary) {
  return {
    type: summary.foundations.type,
    authority: summary.foundations.authority,
    profile: summary.foundations.profile,
    definition: summary.foundations.definition,
    incarnationCross: summary.foundations.incarnationCross?.name || null,
    definedCenters: summary.centers.defined,
    allUndefinedCenters: summary.centers.allUndefined,
    channels: summary.channels.map((channel) => channel.key),
  };
}

function diffSnapshots(left, middle, right) {
  const changes = [];
  for (const field of Object.keys(middle)) {
    const values = [left[field], middle[field], right[field]];
    if (!values.every((value) => JSON.stringify(value) === JSON.stringify(values[0]))) {
      changes.push({
        field,
        earlier: left[field],
        provided: middle[field],
        later: right[field],
      });
    }
  }
  return changes;
}

function calculateAt(date, time, options) {
  const parsedTime = parseTime(time);
  const offset = resolveOffset(date, time, options);
  const raw = calculateHumanDesign(
    date,
    parsedTime.hour + parsedTime.minute / 60,
    offset.hours,
    { nodeType: 'true' },
  );
  return {
    date,
    time,
    offset,
    summary: summarizeChart(raw),
    engineMeta: raw.meta || null,
  };
}

export function buildResult(options) {
  parseDate(options.date);
  parseTime(options.time);

  const uncertainty = options['uncertainty-minutes'] === undefined
    ? 0
    : Number(options['uncertainty-minutes']);
  if (!Number.isInteger(uncertainty) || uncertainty < 0 || uncertainty > 720) {
    throw new UsageError('--uncertainty-minutes must be an integer from 0 through 720');
  }

  const provided = calculateAt(options.date, options.time, options);
  let sensitivity = {
    checked: false,
    stable: null,
    windowMinutes: 0,
    changes: [],
    note: 'Only the provided time was calculated; this does not establish that the birth record itself is exact.',
  };

  if (uncertainty > 0) {
    const earlierWall = shiftWallTime(options.date, options.time, -uncertainty);
    const laterWall = shiftWallTime(options.date, options.time, uncertainty);
    const earlier = calculateAt(earlierWall.date, earlierWall.time, options);
    const later = calculateAt(laterWall.date, laterWall.time, options);
    const earlierCore = coreSnapshot(earlier.summary);
    const providedCore = coreSnapshot(provided.summary);
    const laterCore = coreSnapshot(later.summary);
    const changes = diffSnapshots(earlierCore, providedCore, laterCore);
    sensitivity = {
      checked: true,
      stable: changes.length === 0,
      windowMinutes: uncertainty,
      range: {
        earlier: { ...earlierWall, utcOffset: earlier.offset.hours },
        provided: { date: options.date, time: options.time, utcOffset: provided.offset.hours },
        later: { ...laterWall, utcOffset: later.offset.hours },
      },
      changes,
      note: changes.length === 0
        ? 'Core fields remained consistent throughout the checked time window.'
        : 'Core fields changed inside the time window; lower confidence in dependent interpretations.',
    };
  }

  return {
    subject: {
      name: options.name || null,
      birthDateLocal: options.date,
      birthTimeLocal: options.time,
      place: options.place || null,
      timezone: provided.offset.timezone,
      utcOffsetHours: provided.offset.hours,
      utcOffsetLabel: formatUtcOffset(provided.offset.hours),
      timezoneSource: provided.offset.source,
    },
    calculation: {
      engine: ENGINE_VERSION,
      trustChain: {
        mode: 'local deterministic calculation; no remote chart database',
        ephemeris: `${EPHEMERIS_VERSION} via natalengine (VSOP87-level positions)`,
        mapping: `${ENGINE_VERSION} local gate/line/channel/center/type/authority rules`,
        timezone: 'Node.js Intl with IANA historical timezone data',
        officialJovianArchiveEngine: false,
      },
      nodeType: 'true',
      designMoment: 'exactly 88 degrees of solar arc before the personality Sun',
      engineMeta: provided.engineMeta,
      advancedSubstructureIncluded: false,
      caveat: 'Chart generation uses deterministic astronomy and mapping rules; personal Human Design interpretations are not scientifically validated.',
    },
    ...provided.summary,
    sensitivity,
  };
}

function main() {
  try {
    const options = parseArgs(process.argv.slice(2));
    if (options.help) {
      process.stdout.write(HELP.trimStart());
      return;
    }
    if (!options.date || !options.time) {
      throw new UsageError('Missing --date or --time');
    }
    const result = buildResult(options);
    process.stdout.write(`${JSON.stringify(result, null, options.compact ? 0 : 2)}\n`);
  } catch (error) {
    const prefix = error instanceof UsageError ? 'Usage error' : 'Chart calculation failed';
    process.stderr.write(`${prefix}: ${error.message}\n\n${HELP.trimStart()}`);
    process.exitCode = 1;
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main();
}

export { HELP, UsageError };
