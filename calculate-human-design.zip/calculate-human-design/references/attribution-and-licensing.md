# Attribution and Licensing

## Human Design mechanics port

The rule tables and algorithmic structure in this toolkit are derived from:

- Project: `CReizner/SharpAstrology.HumanDesign`
- Repository: <https://github.com/CReizner/SharpAstrology.HumanDesign>
- Package version: 1.2.0
- Audited commit: `5d95ece57098fd776df7f2362722c1392a6f06b6`
- License: MIT

Retain this notice when copying or redistributing substantial portions:

> Copyright 2023 Christian Reizner
>
> Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## Swiss Ephemeris boundary

Swiss Ephemeris is not bundled in this skill. The adapter consumes a separately supplied `swetest` binary and ephemeris data files, or extracts only the required runtime files from a user-supplied Swiss Ephemeris ZIP into a temporary directory.

Swiss Ephemeris is offered under its own dual-license model, including AGPL and a professional license. Users are responsible for choosing and complying with the applicable license, especially for redistribution, network services, or proprietary or commercial use. Do not imply that the MIT license above covers Swiss Ephemeris.

Consult the [official Swiss Ephemeris licensing terms](https://www.astro.com/swisseph/swisseph.htm) before distributing a combined product.
