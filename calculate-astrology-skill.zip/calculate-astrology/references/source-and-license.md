# Source and adaptation notes

This skill adapts the MIT-licensed
[`aryaminus/astro`](https://github.com/aryaminus/astro) repository at commit
`82df4c1c285cb470625373a716bab86c343e4b6e`. The original copyright and MIT
license are preserved in `LICENSE`.

The adaptation keeps the local Python calculation engine and removes reliance
on the repository's MCP, REST, billing, cloud, and profile-memory layers.

Material reliability changes include:

- unknown-time withholding for angles, houses, Varga Lagna, and BaZi hour;
- DST ambiguity and nonexistent-time detection;
- corrected D9 Lagna and classical mappings for supported Parashari Vargas;
- source-boundary distances and warnings for sensitive divisions;
- corrected Panchanga karana sequencing;
- corrected upcoming lunar-phase and solar/lunar-return root finding;
- separate natal and relocated-return coordinates, plus local-time conversion
  for transit dates;
- Lahiri sidereal handling for the Sade Sati transit check;
- explicit disabling of unvalidated astrocartography, horary verdict,
  planetary-return, planetary-hour, and progressed-angle routes;
- English compute-first instructions, uncertainty rules, and safety limits.

The dependency-free planetary backend is compact and approximate. When
`pyswisseph` is already available, the engine uses it automatically and reports
that backend in `_meta.engine_backend`. Interpretive rules remain traditional
symbolic frameworks rather than scientifically validated measurements.
