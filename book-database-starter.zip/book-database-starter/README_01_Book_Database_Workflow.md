# Book Database — Workflow

Version: 1.0

## Quick reference

| Need | File or action |
| --- | --- |
| Find a book and open it | `README.md` catalog |
| Store a book | `books/<subject>/<filename>` |
| Record searchable metadata | `catalog/books.csv` |
| Set up GitHub or fix a problem | `README_02_Book_Database_Instructions_Scripts.md` |

## Purpose and practical goal

Create a public GitHub repository that someone on another device can open to find and download books. Share its URL, then verify it works in a signed-out browser.

## MVP and beginner format

Version 1 uses ordinary folders, Markdown, and a CSV inventory. A CSV is a plain-text table you can edit in Excel, Google Sheets, or a text editor. No Python, terminal, database server, or website setup is required.

The downloaded starter is a folder of repository files. Uploading those files to a new GitHub repository publishes it; downloading this starter alone does not create a repository in your account.

## Inputs and outputs

**Inputs:** shareable PDF, EPUB, TXT, or Markdown books; title, author, subject, and sharing information; optional authorized external URLs.

**Outputs:** a public repository link, clickable book catalog, downloadable source files, and a structured inventory.

## Folder map

| Path | Purpose |
| --- | --- |
| `README.md` | Landing page and clickable book catalog |
| `README_01_Book_Database_Workflow.md` | Project map and maintenance checklist |
| `README_02_Book_Database_Instructions_Scripts.md` | Setup and exact usage steps |
| `catalog/books.csv` | One row per book |
| `books/reference/starter_sample_v1.txt` | Tiny original sample to test access |

Add subject folders as needed: `books/astrology/`, `books/psychology/`, `books/tarot/`, or `books/beauty/`. Start with a few broad subjects rather than dozens of empty folders.

## Build order

1. Extract the starter ZIP on a computer.
2. Create a public repository named `book-database`.
3. Upload the starter contents with their folder structure preserved.
4. Test the sample download while signed out.
5. Upload one shareable book and add its catalog entries.
6. Repeat only after that book's link works.

The second README explains every step.

## Add-book workflow

1. Choose a subject and a clear filename: `author_short_title_v1.pdf`.
2. Upload the original file to `books/<subject>/`.
3. Add a row in `catalog/books.csv`; assign the next ID, such as `BOOK-002`.
4. Add a clickable row in the `README.md` table.
5. Open the link and download the file from another device or signed-out window.

For an externally hosted book, skip the file upload. Put its authorized HTTPS link in `external_url` and use that same URL in the README's Access column. Verify that the destination allows access for your intended readers.

## Inventory rules

- Use one row per edition/file. If you keep both EPUB and PDF copies, give them separate IDs and note the relationship.
- Keep ID values unique and leave unknown years blank.
- Use lowercase folder names and forward slashes in paths.
- Match filenames exactly, including capitalization and extension.
- Separate tags with semicolons: `astrology;nakshatras;reference`.
- Use either `file_path` or `external_url` for each row, not both.
- Record a sharing basis and a permission/source reference. Do not treat a downloaded or purchased copy as evidence of redistribution permission.
- Keep both the CSV inventory and README table current; Version 1 does not synchronize them.

## What others can find

Readers can browse the landing-page catalog and search its displayed titles, authors, and subjects with the browser's Find command. They can download the CSV and filter it in a spreadsheet.

This starter does not search the contents of PDFs or EPUBs. Hosting a book also does not guarantee it will appear in search-engine results or become available to an AI tool; those are separate retrieval tasks.

## Upgrade path

| Version | Upgrade | Add it when |
| --- | --- | --- |
| V1 — included | Folders, CSV, manual clickable catalog | You need a working shared collection |
| V2 | Generate the README catalog from CSV | Keeping two catalogs aligned becomes tedious |
| V3 | A searchable website with subject filters | The catalog becomes hard to browse |
| Future | OCR, extracted text, and content search | You need to search inside books |

Preserve original books if you later create summaries or extracted text. Store those derivatives separately and label them clearly.

## Maintenance checklist

- [ ] File or authorized external link opens.
- [ ] README link and CSV location match.
- [ ] Book ID is unique.
- [ ] Title, author, subject, and sharing basis are recorded.
- [ ] Signed-out access works for intended readers.
- [ ] Sample remains labeled as a sample, or is removed from both catalogs.

## Rules

Organize for retrieval. Give every book a clear name and an entry before adding the next batch. A shelf full of `final_FINAL_2.pdf` is a scavenger hunt with bad lighting.
