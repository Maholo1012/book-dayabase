# Third-party notices

This skill bundles a headless build of **Astrolog 8.00** from the official CruiserOne/Astrolog repository at source commit `5bf172ea231c4b6ea3d7e09ca307571354a41e8a`.

Local modifications disable the X11 build option and the optional JPL Horizons web-query feature so the command-line engine runs headlessly and locally. The bundled executable's SHA-256 is:

`c78ac6f0bcfbcdd313a65675eeb7d3c3667dbd4c2ec694d5698ba5a1a74d7a25`

The Astrolog GPL v2 license page is preserved at [astrolog-gpl-v2.html](astrolog-gpl-v2.html). Corresponding modified source is included at `../scripts/source/astrolog-8.00-modified-source.tar.gz`. The original source headers, documentation, and notices for bundled astronomical components and ephemeris data are retained in that archive and runtime data.

This package is intended as a personal local skill. Anyone redistributing it, offering it as a service, or using it commercially should independently review all upstream license terms and data notices first.
