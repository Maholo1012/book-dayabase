# Credits and licenses

This portable skill adapts calculation and export code from Chart Desk by Claudia Vaduvescu under the MIT License. The complete upstream copyright notice and license are in `../LICENSE`.

The bundled ephemeris is Astronomy Engine 2.1.19 by Don Cross, also under the MIT License. Its complete license is in `../ASTRONOMY-ENGINE-LICENSE`.

> Copyright (c) 2019-2025 Don Cross <cosinekitty@gmail.com>

Permission is granted, free of charge, to use, copy, modify, merge, publish, distribute, sublicense, and sell the software, subject to including the copyright and permission notice. The software is provided without warranty.

Human Design and Matrix of Destiny are third-party systems. This package implements calculations only and is not affiliated with or endorsed by their originators. It includes no proprietary interpretive text.
