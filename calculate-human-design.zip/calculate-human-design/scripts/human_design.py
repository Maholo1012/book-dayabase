#!/usr/bin/env python3
"""Command-line interface for the local Human Design toolkit."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from collections import OrderedDict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from hd_core import (
    HumanDesignError,
    activations_from_longitudes,
    build_comparison,
    build_natal_chart,
    chart_fingerprint,
    validate_chart,
)
from render_bodygraph import render_bodygraph_svg, render_summary_markdown
from swiss_adapter import SwissEphemerisError, SwissRuntime, runtime_years


def read_json(path: str | Path) -> dict[str, Any]:
    source = Path(path).expanduser().resolve()
    try:
        with source.open(encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        raise HumanDesignError(f"Could not read JSON input {source}: {exc}") from exc
    if not isinstance(value, dict):
        raise HumanDesignError("JSON input must be an object")
    return value


def write_json(path: str | Path, value: Mapping[str, Any]) -> None:
    destination = Path(path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False)
        handle.write("\n")


def write_text(path: str | Path, value: str) -> None:
    destination = Path(path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(value, encoding="utf-8", newline="\n")


def _parse_iso(value: str) -> datetime:
    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise HumanDesignError(f"Invalid ISO date/time: {value}") from exc


def resolve_moment(payload: Mapping[str, Any], stem: str) -> tuple[datetime, dict[str, Any]]:
    utc_key, local_key = f"{stem}_utc", f"{stem}_local"
    if utc_key in payload:
        moment = _parse_iso(str(payload[utc_key]))
        if moment.tzinfo is None:
            raise HumanDesignError(f"{utc_key} must include Z or an explicit UTC offset")
        utc = moment.astimezone(timezone.utc)
        return utc, {"source": utc_key, "utc": utc.isoformat().replace("+00:00", "Z")}
    if local_key not in payload:
        raise HumanDesignError(f"Provide {utc_key} or {local_key} plus an IANA timezone")
    local = _parse_iso(str(payload[local_key]))
    if local.tzinfo is not None:
        utc = local.astimezone(timezone.utc)
        return utc, {
            "source": local_key,
            "supplied_offset": True,
            "local": local.isoformat(),
            "utc": utc.isoformat().replace("+00:00", "Z"),
        }
    zone_name = payload.get(f"{stem}_timezone", payload.get("timezone"))
    if not zone_name:
        raise HumanDesignError(f"timezone is required when {local_key} has no offset")
    try:
        zone = ZoneInfo(str(zone_name))
    except ZoneInfoNotFoundError as exc:
        raise HumanDesignError(f"Unknown IANA timezone: {zone_name}") from exc
    valid: list[tuple[int, datetime]] = []
    for fold in (0, 1):
        aware = local.replace(tzinfo=zone, fold=fold)
        round_trip = aware.astimezone(timezone.utc).astimezone(zone).replace(tzinfo=None)
        if round_trip == local:
            valid.append((fold, aware))
    unique_offsets = {aware.utcoffset() for _, aware in valid}
    if not valid:
        raise HumanDesignError(f"{local_key} falls in a daylight-saving time gap")
    if len(unique_offsets) > 1:
        fold_key = f"{stem}_fold" if f"{stem}_fold" in payload else "fold"
        if fold_key not in payload:
            options = ", ".join(
                f"fold={fold} ({aware.utcoffset()})" for fold, aware in valid
            )
            raise HumanDesignError(f"{local_key} is ambiguous; specify {options}")
        requested_fold = int(payload[fold_key])
        matches = [aware for fold, aware in valid if fold == requested_fold]
        if not matches:
            raise HumanDesignError("fold must be 0 or 1 for the ambiguous local time")
        aware = matches[0]
    else:
        aware = valid[0][1]
    utc = aware.astimezone(timezone.utc)
    return utc, {
        "source": local_key,
        "local": aware.isoformat(),
        "timezone": str(zone_name),
        "fold": aware.fold,
        "utc": utc.isoformat().replace("+00:00", "Z"),
    }


def archive_sha256(path: str | Path | None) -> str | None:
    if not path:
        return None
    digest = hashlib.sha256()
    with Path(path).expanduser().resolve().open("rb") as handle:
        while chunk := handle.read(4 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def runtime_from_args(args: argparse.Namespace, *moments: datetime) -> SwissRuntime:
    return SwissRuntime(
        archive=args.swiss_archive,
        swetest=args.swetest,
        ephe_dir=args.ephe_dir,
        years=runtime_years(*moments),
    )


def emit_outputs(chart: Mapping[str, Any], args: argparse.Namespace) -> None:
    write_json(args.output, chart)
    if getattr(args, "svg", None):
        write_text(args.svg, render_bodygraph_svg(chart))
    if getattr(args, "report", None):
        write_text(args.report, render_summary_markdown(chart))


def natal_command(args: argparse.Namespace) -> None:
    payload = read_json(args.input)
    birth_utc, time_audit = resolve_moment(payload, "birth")
    node_choice = str(payload.get("node_choice", "true")).lower()
    if str(payload.get("zodiac", "tropical")).lower() != "tropical":
        raise HumanDesignError("Standard Human Design requires the tropical zodiac")
    with runtime_from_args(args, birth_utc, birth_utc - timedelta(days=110)) as runtime:
        design_utc = runtime.design_time(birth_utc)
        personality, personality_speeds = runtime.positions(birth_utc, node=node_choice)
        design, design_speeds = runtime.positions(design_utc, node=node_choice)
        swetest_version = runtime.version
    source_hash = archive_sha256(args.swiss_archive) if args.hash_source else None
    metadata = {
        "chart_label": payload.get("name"),
        "node_choice": node_choice,
        "ephemeris": "Swiss Ephemeris file mode via swetest",
        "swetest_version": swetest_version,
        "birth_time": time_audit,
        "design_utc": design_utc.isoformat().replace("+00:00", "Z"),
        "birthplace": payload.get("birthplace"),
        "coordinates": payload.get("coordinates"),
        "personality_speeds_degrees_per_day": personality_speeds,
        "design_speeds_degrees_per_day": design_speeds,
    }
    if source_hash:
        metadata["swiss_archive_sha256"] = source_hash
    chart = build_natal_chart(personality, design, metadata=metadata)
    errors = validate_chart(chart)
    if errors:
        raise HumanDesignError("Internal chart validation failed: " + "; ".join(errors))
    emit_outputs(chart, args)


def longitudes_command(args: argparse.Namespace) -> None:
    payload = read_json(args.input)
    if "personality" not in payload or "design" not in payload:
        raise HumanDesignError("Input must contain personality and design longitude objects")
    if str(payload.get("zodiac", "")).lower() != "tropical":
        raise HumanDesignError("Longitude input must explicitly declare zodiac as tropical")
    metadata = dict(payload.get("metadata", {}))
    metadata.setdefault("ephemeris", "User-supplied longitudes")
    chart = build_natal_chart(payload["personality"], payload["design"], metadata=metadata)
    errors = validate_chart(chart)
    if errors:
        raise HumanDesignError("Chart validation failed: " + "; ".join(errors))
    emit_outputs(chart, args)


def composite_command(args: argparse.Namespace) -> None:
    first, second = read_json(args.first), read_json(args.second)
    for label, chart in (("first", first), ("second", second)):
        errors = validate_chart(chart)
        if errors:
            raise HumanDesignError(f"Invalid {label} chart: " + "; ".join(errors))
    output = build_comparison(
        first,
        second,
        comparison_type="composite",
        first_label=args.first_label,
        second_label=args.second_label,
    )
    emit_outputs(output, args)


def transit_command(args: argparse.Namespace) -> None:
    natal = read_json(args.natal)
    errors = validate_chart(natal)
    if errors:
        raise HumanDesignError("Invalid natal chart: " + "; ".join(errors))
    payload = read_json(args.input)
    if str(payload.get("zodiac", "tropical")).lower() != "tropical":
        raise HumanDesignError("Standard Human Design requires the tropical zodiac")
    transit_utc, time_audit = resolve_moment(payload, "transit")
    node_choice = str(payload.get("node_choice", natal.get("calculation", {}).get("node_choice", "true"))).lower()
    with runtime_from_args(args, transit_utc) as runtime:
        longitudes, speeds = runtime.positions(transit_utc, node=node_choice)
        swetest_version = runtime.version
    activations = activations_from_longitudes(longitudes)
    output = build_comparison(
        natal,
        {},
        comparison_type="transit",
        first_label="Natal",
        second_label="Transit",
        second_activations=activations,
        metadata={
            "transit_time": time_audit,
            "node_choice": node_choice,
            "speeds_degrees_per_day": speeds,
            "ephemeris": "Swiss Ephemeris file mode via swetest",
            "swetest_version": swetest_version,
        },
    )
    emit_outputs(output, args)


def scan_command(args: argparse.Namespace) -> None:
    payload = read_json(args.input)
    if str(payload.get("zodiac", "tropical")).lower() != "tropical":
        raise HumanDesignError("Standard Human Design requires the tropical zodiac")
    start_utc, start_audit = resolve_moment(payload, "start")
    end_utc, end_audit = resolve_moment(payload, "end")
    if end_utc <= start_utc:
        raise HumanDesignError("end must be later than start")
    method = str(payload.get("method", "adaptive")).lower()
    if method not in {"adaptive", "sampling"}:
        raise HumanDesignError("method must be 'adaptive' or 'sampling'")
    node_choice = str(payload.get("node_choice", "true")).lower()
    groups: OrderedDict[tuple[Any, ...], dict[str, Any]] = OrderedDict()
    total_seconds = (end_utc - start_utc).total_seconds()
    evaluated: dict[datetime, dict[str, Any]] = {}
    runtime_moments = (
        start_utc,
        end_utc,
        start_utc - timedelta(days=110),
        end_utc - timedelta(days=110),
    )
    with runtime_from_args(args, *runtime_moments) as runtime:
        def chart_at(moment: datetime) -> dict[str, Any]:
            if moment in evaluated:
                return evaluated[moment]
            design_utc = runtime.design_time(moment)
            personality, personality_speeds = runtime.positions(moment, node=node_choice)
            design, design_speeds = runtime.positions(design_utc, node=node_choice)
            chart = build_natal_chart(
                personality,
                design,
                metadata={
                    "node_choice": node_choice,
                    "ephemeris": "Swiss Ephemeris file mode via swetest",
                    "swetest_version": runtime.version,
                    "birth_utc": moment.isoformat().replace("+00:00", "Z"),
                    "design_utc": design_utc.isoformat().replace("+00:00", "Z"),
                    "personality_speeds_degrees_per_day": personality_speeds,
                    "design_speeds_degrees_per_day": design_speeds,
                },
            )
            evaluated[moment] = chart
            return chart

        if method == "adaptive":
            target_minutes = float(payload.get("target_minutes", 10.0))
            if target_minutes <= 0:
                raise HumanDesignError("target_minutes must be greater than zero")
            depth_limit = int(payload.get("max_depth", 12))
            if not 0 <= depth_limit <= 12:
                raise HumanDesignError("max_depth must be between 0 and 12")
            ratio = (total_seconds / 60.0) / target_minutes
            max_depth = min(depth_limit, max(0, math.ceil(math.log2(ratio)))) if ratio > 0 else 0
            maximum_evaluations = 2**max_depth + 1
            max_samples = int(payload.get("max_samples", 513))
            if maximum_evaluations > max_samples:
                raise HumanDesignError(
                    f"Adaptive scan may evaluate {maximum_evaluations} moments; increase max_samples or target_minutes"
                )
            leaves: list[tuple[dict[str, Any], datetime, float]] = []

            def visit(
                left_time: datetime,
                right_time: datetime,
                depth: int,
                left_chart: dict[str, Any] | None = None,
                right_chart: dict[str, Any] | None = None,
            ) -> None:
                left_chart = left_chart or chart_at(left_time)
                right_chart = right_chart or chart_at(right_time)
                if depth >= max_depth or chart_fingerprint(left_chart) == chart_fingerprint(right_chart):
                    leaves.append((left_chart, left_time, 1.0 / (2**depth)))
                    return
                midpoint = left_time + (right_time - left_time) / 2
                visit(left_time, midpoint, depth + 1, left_chart, None)
                visit(midpoint, right_time, depth + 1, None, right_chart)

            visit(start_utc, end_utc, 0)
            for chart, moment, probability in leaves:
                fingerprint = chart_fingerprint(chart)
                if fingerprint not in groups:
                    groups[fingerprint] = {
                        "probability": 0.0,
                        "representative_times_utc": [],
                        "chart": chart,
                    }
                groups[fingerprint]["probability"] += probability
                groups[fingerprint]["representative_times_utc"].append(
                    moment.isoformat().replace("+00:00", "Z")
                )
            results = [
                {
                    "probability_estimate": round(value["probability"], 12),
                    "representative_times_utc": value["representative_times_utc"],
                    "chart": value["chart"],
                }
                for value in groups.values()
            ]
            method_details = {
                "name": "adaptive_endpoint_bisection",
                "target_minutes": target_minutes,
                "max_depth": max_depth,
                "evaluated_moments": len(evaluated),
                "note": "Source-compatible dyadic estimates; equal endpoints may stop a branch early.",
            }
        else:
            step_minutes = int(payload.get("step_minutes", 10))
            if step_minutes < 1:
                raise HumanDesignError("step_minutes must be at least 1")
            estimated = math.ceil(total_seconds / (step_minutes * 60))
            max_samples = int(payload.get("max_samples", 500))
            if estimated > max_samples:
                raise HumanDesignError(
                    f"Range requires about {estimated} samples; increase step_minutes or max_samples"
                )
            current = start_utc
            while current < end_utc:
                interval_end = min(current + timedelta(minutes=step_minutes), end_utc)
                chart = chart_at(current)
                fingerprint = chart_fingerprint(chart)
                seconds = (interval_end - current).total_seconds()
                if fingerprint not in groups:
                    groups[fingerprint] = {
                        "seconds": 0.0,
                        "representative_times_utc": [],
                        "chart": chart,
                    }
                groups[fingerprint]["seconds"] += seconds
                groups[fingerprint]["representative_times_utc"].append(
                    current.isoformat().replace("+00:00", "Z")
                )
                current = interval_end
            results = [
                {
                    "probability_estimate": round(value["seconds"] / total_seconds, 12),
                    "representative_times_utc": value["representative_times_utc"],
                    "chart": value["chart"],
                }
                for value in groups.values()
            ]
            method_details = {
                "name": "equal_duration_sampling",
                "step_minutes": step_minutes,
                "evaluated_moments": len(evaluated),
                "note": "Fixed-grid duration estimates; these are not statistical probabilities.",
            }
    output = {
        "schema_version": "1.0",
        "comparison_type": "birth_time_range",
        "method": method_details,
        "start": start_audit,
        "end": end_audit,
        "distinct_charts": len(results),
        "probability_sum": round(sum(item["probability_estimate"] for item in results), 12),
        "results": results,
    }
    write_json(args.output, output)


def validate_command(args: argparse.Namespace) -> None:
    chart = read_json(args.chart)
    errors = validate_chart(chart)
    result = {"valid": not errors, "errors": errors}
    if args.output:
        write_json(args.output, result)
    else:
        print(json.dumps(result, indent=2, sort_keys=True))
    if errors:
        raise SystemExit(2)


def render_command(args: argparse.Namespace) -> None:
    chart = read_json(args.chart)
    if args.svg:
        write_text(args.svg, render_bodygraph_svg(chart))
    if args.report:
        write_text(args.report, render_summary_markdown(chart))


def add_runtime_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--swiss-archive", help="Path to the official Swiss Ephemeris ZIP")
    parser.add_argument("--swetest", help="Path to a swetest executable")
    parser.add_argument("--ephe-dir", help="Path to Swiss ephemeris data files")


def add_output_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--output", required=True, help="Destination JSON path")
    parser.add_argument("--svg", help="Optional SVG BodyGraph-summary path")
    parser.add_argument("--report", help="Optional Markdown calculation-summary path")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Local Human Design calculation toolkit")
    subparsers = parser.add_subparsers(dest="command", required=True)

    natal = subparsers.add_parser("natal", help="Calculate a natal chart from birth data")
    natal.add_argument("--input", required=True)
    natal.add_argument("--hash-source", action="store_true", help="Record the Swiss ZIP SHA-256")
    add_runtime_arguments(natal)
    add_output_arguments(natal)
    natal.set_defaults(handler=natal_command)

    supplied = subparsers.add_parser("from-longitudes", help="Calculate from personality/design longitudes")
    supplied.add_argument("--input", required=True)
    add_output_arguments(supplied)
    supplied.set_defaults(handler=longitudes_command)

    composite = subparsers.add_parser("composite", help="Compare two saved natal charts")
    composite.add_argument("--first", required=True)
    composite.add_argument("--second", required=True)
    composite.add_argument("--first-label", default="Person 1")
    composite.add_argument("--second-label", default="Person 2")
    add_output_arguments(composite)
    composite.set_defaults(handler=composite_command)

    transit = subparsers.add_parser("transit", help="Compare a transit moment with a natal chart")
    transit.add_argument("--natal", required=True)
    transit.add_argument("--input", required=True)
    add_runtime_arguments(transit)
    add_output_arguments(transit)
    transit.set_defaults(handler=transit_command)

    scan = subparsers.add_parser("scan", help="Compare possible charts across a birth-time range")
    scan.add_argument("--input", required=True)
    add_runtime_arguments(scan)
    scan.add_argument("--output", required=True)
    scan.set_defaults(handler=scan_command)

    validate = subparsers.add_parser("validate", help="Validate a saved natal chart")
    validate.add_argument("--chart", required=True)
    validate.add_argument("--output")
    validate.set_defaults(handler=validate_command)

    render = subparsers.add_parser("render", help="Render a saved chart")
    render.add_argument("--chart", required=True)
    render.add_argument("--svg")
    render.add_argument("--report")
    render.set_defaults(handler=render_command)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        args.handler(args)
    except (HumanDesignError, SwissEphemerisError, OSError, ValueError) as exc:
        print(f"human-design error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
