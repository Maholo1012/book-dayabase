#!/usr/bin/env python3
"""Regression tests for the local Astrolog skill wrapper."""

from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import astrolog_tool as tool


def chart_one() -> dict[str, object]:
    return {
        "date": "1996-10-12",
        "time": "16:56:00",
        "timezone": "America/New_York",
        "latitude": 34.8526,
        "longitude": -82.3940,
    }


def chart_two() -> dict[str, object]:
    return {
        "date": "1990-01-15",
        "time": "08:30:00",
        "timezone": "America/Chicago",
        "latitude": 41.8781,
        "longitude": -87.6298,
    }


class AstrologToolTests(unittest.TestCase):
    def test_builtin_self_test(self) -> None:
        result = tool.execute({"operation": "self-test"})
        self.assertTrue(result["ok"])
        self.assertTrue(result["passed"])

    def test_coordinate_conversion_uses_explicit_hemispheres(self) -> None:
        self.assertEqual(tool._decimal_to_dms(-82.3940, "longitude"), "82:23:38W")
        self.assertEqual(tool._decimal_to_dms(151.2167, "longitude"), "151:13:00E")
        self.assertEqual(tool._decimal_to_dms(-33.8667, "latitude"), "33:52:00S")
        self.assertEqual(tool._decimal_to_dms(12.9999999, "latitude"), "13:00:00N")

    def test_nonexistent_dst_time_is_rejected(self) -> None:
        with self.assertRaisesRegex(tool.RequestError, "nonexistent"):
            tool._resolve_local_moment(
                {"date": "2026-03-08", "time": "02:30:00", "timezone": "America/New_York"},
                "target",
            )

    def test_ambiguous_dst_time_requires_fold(self) -> None:
        ambiguous = {"date": "2026-11-01", "time": "01:30:00", "timezone": "America/New_York"}
        with self.assertRaisesRegex(tool.RequestError, "ambiguous"):
            tool._resolve_local_moment(ambiguous, "target")
        first = tool._resolve_local_moment({**ambiguous, "fold": 0}, "target")
        second = tool._resolve_local_moment({**ambiguous, "fold": 1}, "target")
        self.assertNotEqual(first["metadata"]["utc_datetime"], second["metadata"]["utc_datetime"])
        with self.assertRaisesRegex(tool.RequestError, "must be 0 or 1"):
            tool._resolve_local_moment({**ambiguous, "fold": True}, "target")

    def test_sidereal_natal_positions_houses_and_angles(self) -> None:
        result = tool.execute(
            {
                "operation": "natal",
                "chart": chart_one(),
                "settings": {
                    "zodiac": "sidereal",
                    "ayanamsa": "lahiri",
                    "house_system": "whole-sign",
                    "node_mode": "true",
                    "include_objects": ["chiron", "lilith", "part-of-fortune", "vertex"],
                },
            }
        )
        positions = {item["name"]: item for item in result["result"]["positions"]}
        self.assertAlmostEqual(positions["Sun"]["longitude"], 175.9932, places=3)
        self.assertIn("Chiron", positions)
        self.assertIn("Part of Fortune", positions)
        self.assertEqual(result["result"]["houses"][0]["longitude"], 300.0)
        asc = result["result"]["angles"]["Ascendant"]["longitude"]
        desc = result["result"]["angles"]["Descendant"]["longitude"]
        self.assertAlmostEqual((asc + 180) % 360, desc, places=8)

    def test_svg_render_is_safe_and_bounded(self) -> None:
        with tempfile.TemporaryDirectory(prefix="astrolog-test-output-") as output:
            result = tool.execute(
                {
                    "operation": "natal",
                    "chart": chart_one(),
                    "output": {"format": "svg", "filename": "wheel", "width": 800, "height": 800},
                },
                output,
            )
            artifact = result["artifacts"][0]
            path = Path(artifact["path"])
            self.assertTrue(path.is_file())
            content = path.read_text(encoding="utf-8")
            self.assertIn("<svg", content)
            self.assertNotIn("<script", content.lower())
            self.assertEqual(artifact["requested_width"], 800)
            self.assertEqual(artifact["requested_height"], 800)
            self.assertEqual(len(artifact["view_box"]), 4)

    def test_png_and_astrocartography_outputs(self) -> None:
        with tempfile.TemporaryDirectory(prefix="astrolog-test-output-") as output:
            png = tool.execute(
                {
                    "operation": "natal",
                    "chart": chart_one(),
                    "output": {"format": "png", "filename": "wheel", "width": 700, "height": 700},
                },
                output,
            )
            artifact = png["artifacts"][0]
            self.assertEqual(artifact["type"], "png")
            self.assertGreater(artifact["width"], 0)
            self.assertGreater(artifact["height"], 0)
        map_result = tool.execute({"operation": "astrocartography", "chart": chart_one()})
        self.assertIn("Object : Sun", map_result["result"]["raw_text"])
        self.assertIn("Midheav:", map_result["result"]["raw_text"])

    def test_transit_snapshot_is_normalized_to_utc(self) -> None:
        result = tool.execute(
            {
                "operation": "transits",
                "chart": chart_one(),
                "target": {"date": "2026-10-05", "time": "12:00:00", "timezone": "America/New_York"},
                "mode": "snapshot",
            }
        )
        self.assertEqual(result["target"]["utc_datetime"], "2026-10-05T16:00:00Z")
        self.assertIn("4:00:00pm (ST Zone 0:00W)", result["result"]["raw_text"])

    def test_month_search_uses_target_local_calendar_month(self) -> None:
        target = {"date": "2026-01-01", "time": "00:00:00", "timezone": "Asia/Tokyo"}
        transits = tool.execute(
            {"operation": "transits", "chart": chart_one(), "target": target, "mode": "month"}
        )
        self.assertEqual(transits["target"]["utc_datetime"], "2025-12-31T15:00:00Z")
        self.assertEqual(transits["search_month_local"], "2026-01")
        self.assertIn("Jan 2026", transits["result"]["raw_text"])
        returns = tool.execute({"operation": "returns", "chart": chart_one(), "target": target})
        self.assertEqual(returns["search_month_local"], "2026-01")
        self.assertIn("Jan 2026", returns["result"]["raw_text"])

    def test_text_only_operations_reject_graphics(self) -> None:
        target = {"date": "2026-10-05", "time": "12:00:00", "timezone": "America/New_York"}
        with self.assertRaisesRegex(tool.RequestError, "text output only"):
            tool.execute(
                {
                    "operation": "transits",
                    "chart": chart_one(),
                    "target": target,
                    "output": {"format": "svg"},
                }
            )
        with self.assertRaisesRegex(tool.RequestError, "text output only"):
            tool.execute(
                {
                    "operation": "returns",
                    "chart": chart_one(),
                    "target": target,
                    "output": {"format": "png"},
                }
            )

    def test_progression_return_and_relationship_operations(self) -> None:
        target = {"date": "2026-10-05", "time": "12:00:00", "timezone": "America/New_York"}
        progressed = tool.execute(
            {"operation": "progression", "chart": chart_one(), "target": target, "method": "secondary"}
        )
        self.assertIn("Progressed To", progressed["result"]["raw_text"])
        returns = tool.execute({"operation": "returns", "chart": chart_one(), "target": target})
        self.assertIn("Solar Return", returns["result"]["raw_text"])
        relationship = tool.execute(
            {
                "operation": "relationship",
                "chart": chart_one(),
                "chart2": chart_two(),
                "relationship_type": "comparison",
                "view": "aspects",
            }
        )
        self.assertTrue(relationship["result"]["raw_text"])

    def test_astrolog_config_and_environment_are_isolated(self) -> None:
        request = {"operation": "natal", "chart": chart_one()}
        baseline = tool.execute(request)["result"]["positions"][0]["longitude"]
        with tempfile.TemporaryDirectory(prefix="astrolog-poison-") as poison:
            Path(poison, "astrolog.as").write_text("=s Lahiri\n", encoding="utf-8")
            previous = Path.cwd()
            try:
                os.chdir(poison)
                with mock.patch.dict(os.environ, {"ASTR800": poison, "ASTROLOG": poison}, clear=False):
                    repeated = tool.execute(request)["result"]["positions"][0]["longitude"]
            finally:
                os.chdir(previous)
        self.assertAlmostEqual(baseline, repeated, places=10)

    def test_compiled_fallback_runtime_is_cached(self) -> None:
        fallback = Path("/tmp/astrolog-test-fallback")
        previous = tool._FALLBACK_RUNTIME
        tool._FALLBACK_RUNTIME = None
        try:
            with mock.patch.object(tool, "_probe_runtime", side_effect=lambda path: path == fallback), mock.patch.object(
                tool, "_build_fallback_runtime", return_value=fallback
            ) as build:
                self.assertEqual(tool._runtime(), fallback)
                self.assertEqual(tool._runtime(), fallback)
                build.assert_called_once_with()
        finally:
            tool._FALLBACK_RUNTIME = previous

    def test_swiss_range_and_output_name_fail_closed(self) -> None:
        settings = tool._normalize_settings({"ephemeris_mode": "swiss"})
        with self.assertRaisesRegex(tool.RequestError, "1800-2399"):
            tool._validate_ephemeris(settings, [1700])
        with self.assertRaises(tool.RequestError):
            tool._artifact_name({"output": {"filename": "../escape"}}, "chart", ".svg")


if __name__ == "__main__":
    unittest.main(verbosity=2)
