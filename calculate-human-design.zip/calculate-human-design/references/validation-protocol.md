# Validation Protocol

## Evidence layers

1. **Input audit** — confirm timezone or offset, DST fold when necessary, chosen node, tropical zodiac, and provenance of any supplied longitudes.
2. **Ephemeris integrity** — require Swiss Ephemeris file mode and stop on missing files, warnings, or fallback. Optionally record the archive SHA-256 with `--hash-source`.
3. **Structural validation** — confirm all 13 activations on both sides, legal gate and substructure ranges, and Sun and Earth antipodes.
4. **Rule-table verification** — test 64 unique wheel gates, 64 center mappings, nine centers, 36 channels, 192 incarnation-cross entries, and 759 explicit fixation rules.
5. **Cell coverage** — test a midpoint in every gate × line × color × tone × base cell: 64 × 6 × 6 × 6 × 5 = 69,120 cases.
6. **Graph and comparison cases** — test representative type and authority topologies, all 16 endpoint-ownership combinations for a channel, target-first fixation ordering, and every composite/transit fixation-map path.
7. **Swiss integration goldens** — reproduce the upstream 2024 natal example and its two-person composite example, including exact type, profile, authority, definition, cross, and channel assertions.

Run `scripts/test_toolkit.py --json` for layers 3–6 and add `--swiss-archive` for layer 7.

## Expected 2024 integration result

For 2024-01-01 00:00:00 UTC with the true node and Swiss files, the structural golden is:

- Type: Generator
- Authority: Emotional (Solar Plexus)
- Profile: 1/3
- Definition: Split
- Incarnation cross: The Right Angle Cross of Tension 4
- Active channels: 29-46 and 39-55

Variable lines shown in prose examples upstream are not used as goldens because they disagree with the current executable-source mapping. The toolkit follows source code as described in `calculation-method.md`.

## Known limits

- This is an independent Python port, not the upstream .NET package.
- The renderer is a compact mechanics diagram. It does not encode every conventional BodyGraph gate position, color convention, circuitry label, or mandala layer.
- Place-name lookup, historical timezone research, rectification, and narrative gate or channel meanings are outside the calculation engine.
- Birth-time scans either use source-compatible endpoint bisection or a requested fixed grid; neither method analytically solves every boundary crossing.
- Adaptive scanning can stop when two branch endpoints match even if an interior change reverses before the second endpoint. Use a fine fixed grid as a cross-check when every short-lived transition matters.
- The JSON Schema validates the natal interchange structure. Composite, transit, and scan outputs use related but distinct structures.
- Human Design interpretations are a reflective or esoteric framework, not established science.

## Failure policy

Stop rather than guess when:

- timezone identity or DST fold is unresolved;
- the Swiss binary or required 600-year planetary or lunar file segment is absent;
- Swiss reports fallback or warnings;
- provided longitude sets are incomplete or their zodiac is unknown;
- validation reports structural errors; or
- a requested interpretation would turn the framework into consequential professional advice.
