#!/usr/bin/env python3
"""Safe, local wrapper around the bundled Astrolog 8.00 executable.

The wrapper accepts a versioned JSON request, resolves IANA time zones with
Python's standard library, converts all moments to UTC, and invokes only
allowlisted Astrolog operations. It never accepts raw Astrolog switches.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
import tarfile
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


SCHEMA_VERSION = "1.0"
ENGINE_VERSION = "8.00"
SOURCE_COMMIT = "5bf172ea231c4b6ea3d7e09ca307571354a41e8a"
MAX_REQUEST_BYTES = 262_144
MAX_OUTPUT_BYTES = 5_000_000
MAX_GRAPHIC_BYTES = 12_000_000
SWISS_MIN_YEAR = 1800
SWISS_MAX_YEAR = 2399

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
BUNDLED_RUNTIME = SCRIPT_DIR / "runtime"
SOURCE_ARCHIVE = SCRIPT_DIR / "source" / "astrolog-8.00-modified-source.tar.gz"
_TEMP_RUNTIMES: list[tempfile.TemporaryDirectory[str]] = []
_FALLBACK_RUNTIME: Path | None = None

HOUSE_SYSTEMS = {
    "placidus": 0,
    "koch": 1,
    "equal": 2,
    "campanus": 3,
    "meridian": 4,
    "regiomontanus": 5,
    "porphyry": 6,
    "morinus": 7,
    "topocentric": 8,
    "alcabitius": 9,
    "krusinski": 10,
    "equal-midheaven": 11,
    "pullen-sinusoidal-ratio": 12,
    "pullen-sinusoidal-delta": 13,
    "whole-sign": 14,
    "vedic": 15,
    "sripati": 16,
    "horizon": 17,
    "apc": 18,
    "carter-poli-equatorial": 19,
    "sunshine": 20,
    "savard-a": 21,
    "null": 22,
    "whole-sign-midheaven": 23,
    "vedic-midheaven": 24,
    "equal-balanced": 25,
    "whole-sign-balanced": 26,
    "vedic-balanced": 27,
    "equal-east-point": 28,
    "whole-sign-east-point": 29,
    "vedic-east-point": 30,
    "equal-vertex": 31,
    "whole-sign-vertex": 32,
    "vedic-vertex": 33,
    "porphyry-east-point": 34,
    "porphyry-vertex": 35,
    "pullen-ratio-east-point": 36,
    "pullen-ratio-vertex": 37,
    "pullen-delta-east-point": 38,
    "pullen-delta-vertex": 39,
}

AYANAMSAS = {
    "fagan-bradley": "Fagan-Bradley",
    "lahiri": "Lahiri",
    "deluce": "Deluce",
    "raman": "Raman",
    "usha-shasi": "Usha-Shasi",
    "krishnamurti": "Krishnamurti",
    "djwhal-khul": "Djwhal Khul",
    "yukteshwar": "Yukteshwar",
    "jn-bhasin": "J.N. Bhasin",
    "galactic-center": "Galactic Center",
}

EXTRA_OBJECTS = {
    "chiron": 11,
    "ceres": 12,
    "pallas": 13,
    "juno": 14,
    "vesta": 15,
    "south-node": 17,
    "lilith": 18,
    "part-of-fortune": 19,
    "vertex": 20,
    "east-point": 21,
}

VIEW_SWITCHES = {
    "positions": ["=v"],
    "aspects": ["=a0"],
    "aspect-grid": ["=g0"],
    "midpoints": ["=m0"],
    "wheel-text": ["-w"],
    "horizon": ["-Z"],
    "astrocartography": ["-L"],
}

RELATIONSHIP_SWITCHES = {
    "synastry": "-r",
    "comparison": "-r0",
    "composite": "-rc",
    "davison": "-rm",
}

SIGN_INDEX = {
    "Ari": 0,
    "Tau": 1,
    "Gem": 2,
    "Can": 3,
    "Leo": 4,
    "Vir": 5,
    "Lib": 6,
    "Sco": 7,
    "Sag": 8,
    "Cap": 9,
    "Aqu": 10,
    "Pis": 11,
}

SIGN_NAMES = [
    "Aries",
    "Taurus",
    "Gemini",
    "Cancer",
    "Leo",
    "Virgo",
    "Libra",
    "Scorpio",
    "Sagittarius",
    "Capricorn",
    "Aquarius",
    "Pisces",
]

CUSP_NAMES = {
    "Asce": 1,
    "2nd": 2,
    "3rd": 3,
    "Nadi": 4,
    "5th": 5,
    "6th": 6,
    "Desc": 7,
    "8th": 8,
    "9th": 9,
    "Midh": 10,
    "11th": 11,
    "12th": 12,
}

BODY_NAMES = {
    "Sun": "Sun",
    "Moon": "Moon",
    "Merc": "Mercury",
    "Venu": "Venus",
    "Mars": "Mars",
    "Jupi": "Jupiter",
    "Satu": "Saturn",
    "Uran": "Uranus",
    "Nept": "Neptune",
    "Plut": "Pluto",
    "Chir": "Chiron",
    "Cere": "Ceres",
    "Pall": "Pallas",
    "Juno": "Juno",
    "Vest": "Vesta",
    "Nort": "North Node",
    "Sout": "South Node",
    "Lili": "Lilith",
    "Fort": "Part of Fortune",
    "Vert": "Vertex",
    "EP": "East Point",
}

POSITION_RE = re.compile(
    r"^-YF\s+(\S+)\s+(\d+)\s+([A-Za-z]{3})\s+"
    r"([+-]?\d+(?:\.\d+)?),\s+([+-]?\d+)\s+"
    r"([+-]?\d+(?:\.\d+)?),\s+([+-]?\d+(?:\.\d+)?)\s+"
    r"([+-]?\d+(?:\.\d+)?)\s*$"
)


class RequestError(ValueError):
    """The request is invalid or asks for an unsupported operation."""


class EngineError(RuntimeError):
    """The local Astrolog engine could not complete the calculation."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _clean_env() -> dict[str, str]:
    env = {
        "PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"),
        "TZ": "UTC",
        "LANG": "C",
        "LC_ALL": "C",
    }
    for key in ("LD_LIBRARY_PATH", "SYSTEMROOT", "WINDIR"):
        if key in os.environ:
            env[key] = os.environ[key]
    return env


def _probe_runtime(runtime: Path) -> bool:
    binary = runtime / "astrolog"
    config = runtime / "astrolog.as"
    if not binary.is_file() or not config.is_file() or not os.access(binary, os.X_OK):
        return False
    try:
        result = subprocess.run(
            ["./astrolog", "-H"],
            cwd=runtime,
            env=_clean_env(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0 and "version 8.00" in result.stdout


def _safe_extract(archive: Path, destination: Path) -> None:
    root = destination.resolve()
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle.getmembers():
            target = (destination / member.name).resolve()
            if root != target and root not in target.parents:
                raise EngineError("Bundled source archive contains an unsafe path.")
        bundle.extractall(destination)


def _build_fallback_runtime() -> Path:
    if not SOURCE_ARCHIVE.is_file():
        raise EngineError("The bundled Astrolog source archive is missing.")
    if shutil.which("make") is None or shutil.which("g++") is None:
        raise EngineError(
            "The bundled executable is incompatible and this environment lacks make/g++ "
            "for the included source fallback."
        )

    holder = tempfile.TemporaryDirectory(prefix="astrolog-calculator-build-")
    _TEMP_RUNTIMES.append(holder)
    root = Path(holder.name)
    source_root = root / "source"
    source_root.mkdir()
    _safe_extract(SOURCE_ARCHIVE, source_root)
    project = source_root / "astrolog-src"
    if not (project / "Makefile").is_file():
        raise EngineError("Bundled Astrolog source archive is incomplete.")

    build = subprocess.run(
        ["make", "-j2"],
        cwd=project,
        env=_clean_env(),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=180,
        check=False,
    )
    if build.returncode != 0 or not (project / "astrolog").is_file():
        raise EngineError("Astrolog source fallback did not compile successfully.\n" + build.stdout[-4000:])

    runtime = root / "runtime"
    runtime.mkdir()
    shutil.copy2(project / "astrolog", runtime / "astrolog")
    os.chmod(runtime / "astrolog", 0o755)
    for name in ("astrolog.as", "atlas.as", "timezone.as", "earth.bmp", "sefstars.txt", "seorbel.txt"):
        shutil.copy2(BUNDLED_RUNTIME / name, runtime / name)
    shutil.copytree(BUNDLED_RUNTIME / "ephem", runtime / "ephem")
    shutil.copytree(BUNDLED_RUNTIME / "font", runtime / "font")
    if not _probe_runtime(runtime):
        raise EngineError("The locally rebuilt Astrolog executable failed its version probe.")
    return runtime


def _runtime() -> Path:
    global _FALLBACK_RUNTIME
    if _probe_runtime(BUNDLED_RUNTIME):
        return BUNDLED_RUNTIME
    if _FALLBACK_RUNTIME is None or not _probe_runtime(_FALLBACK_RUNTIME):
        _FALLBACK_RUNTIME = _build_fallback_runtime()
    return _FALLBACK_RUNTIME


def _run_astrolog(args: list[str], timeout: int = 45) -> str:
    runtime = _runtime()
    if any("\x00" in arg for arg in args):
        raise RequestError("Input contains a null byte.")
    try:
        result = subprocess.run(
            ["./astrolog", *args],
            cwd=runtime,
            env=_clean_env(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="replace",
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise EngineError(f"Astrolog exceeded the {timeout}-second limit.") from exc
    except OSError as exc:
        raise EngineError(f"Astrolog could not start: {exc}") from exc

    combined = result.stdout
    if result.stderr:
        combined += ("\n" if combined else "") + result.stderr
    if len(combined.encode("utf-8", errors="replace")) > MAX_OUTPUT_BYTES:
        raise EngineError("Astrolog output exceeded the safety limit.")
    if result.returncode != 0:
        raise EngineError(
            f"Astrolog exited with status {result.returncode}.\n{combined[-3000:]}"
        )
    if re.search(r"(?:^|\n)(?:Astrolog:\s*)?(?:Error|Fatal):", combined, re.IGNORECASE):
        raise EngineError("Astrolog reported an error.\n" + combined[-3000:])
    return combined.rstrip()


def _require_mapping(value: Any, field: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise RequestError(f"'{field}' must be a JSON object.")
    return value


def _parse_date(value: Any, field: str) -> dt.date:
    if not isinstance(value, str):
        raise RequestError(f"'{field}' must be an ISO date (YYYY-MM-DD).")
    try:
        return dt.date.fromisoformat(value)
    except ValueError as exc:
        raise RequestError(f"'{field}' is not a valid ISO date: {value!r}.") from exc


def _parse_time(value: Any, field: str) -> dt.time:
    if not isinstance(value, str):
        raise RequestError(f"'{field}' must be a local time (HH:MM or HH:MM:SS).")
    try:
        parsed = dt.time.fromisoformat(value)
    except ValueError as exc:
        raise RequestError(f"'{field}' is not a valid local time: {value!r}.") from exc
    if parsed.tzinfo is not None:
        raise RequestError(f"'{field}' must not contain an offset; supply an IANA timezone separately.")
    if parsed.microsecond:
        raise RequestError(f"'{field}' must not contain fractional seconds.")
    return parsed


def _resolve_local_moment(data: dict[str, Any], field: str) -> dict[str, Any]:
    date = _parse_date(data.get("date"), f"{field}.date")
    time = _parse_time(data.get("time"), f"{field}.time")
    zone_name = data.get("timezone")
    if not isinstance(zone_name, str) or not zone_name or len(zone_name) > 100:
        raise RequestError(f"'{field}.timezone' must be an IANA timezone such as America/New_York.")
    try:
        zone = ZoneInfo(zone_name)
    except ZoneInfoNotFoundError as exc:
        raise RequestError(f"Unknown IANA timezone: {zone_name!r}.") from exc

    naive = dt.datetime.combine(date, time)
    candidates: dict[int, dt.datetime] = {}
    for fold in (0, 1):
        aware = naive.replace(tzinfo=zone, fold=fold)
        round_trip = aware.astimezone(dt.timezone.utc).astimezone(zone)
        if round_trip.replace(tzinfo=None) == naive and round_trip.fold == fold:
            offset = aware.utcoffset()
            if offset is not None:
                candidates[fold] = aware

    if not candidates:
        raise RequestError(
            f"'{field}' falls in a nonexistent local-time interval caused by a clock change."
        )

    distinct_offsets = {candidate.utcoffset() for candidate in candidates.values()}
    requested_fold = data.get("fold")
    if len(distinct_offsets) > 1 and requested_fold is None:
        raise RequestError(
            f"'{field}' is ambiguous because the clock repeats this time. Supply fold: 0 or fold: 1."
        )
    if requested_fold is not None:
        if isinstance(requested_fold, bool) or requested_fold not in (0, 1):
            raise RequestError(f"'{field}.fold' must be 0 or 1.")
        if requested_fold not in candidates:
            raise RequestError(f"'{field}.fold' does not select a valid occurrence of this local time.")
        aware = candidates[requested_fold]
    else:
        aware = next(iter(candidates.values()))

    utc = aware.astimezone(dt.timezone.utc)
    offset = aware.utcoffset() or dt.timedelta(0)
    return {
        "local": aware,
        "utc": utc,
        "metadata": {
            "local_datetime": aware.isoformat(),
            "timezone": zone_name,
            "fold": aware.fold,
            "utc_offset_seconds": int(offset.total_seconds()),
            "utc_datetime": utc.isoformat().replace("+00:00", "Z"),
        },
    }


def _number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise RequestError(f"'{field}' must be numeric.")
    result = float(value)
    if not math.isfinite(result):
        raise RequestError(f"'{field}' must be finite.")
    return result


def _decimal_to_dms(value: float, kind: str) -> str:
    if kind == "longitude":
        if value < -180 or value > 180:
            raise RequestError("Longitude must be between -180 and 180 degrees.")
        positive, negative = "E", "W"
        maximum = 180
    elif kind == "latitude":
        if value < -90 or value > 90:
            raise RequestError("Latitude must be between -90 and 90 degrees.")
        positive, negative = "N", "S"
        maximum = 90
    else:
        raise AssertionError(kind)

    total_seconds = int(round(abs(value) * 3600))
    max_seconds = maximum * 3600
    if total_seconds > max_seconds:
        total_seconds = max_seconds
    degrees, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    hemisphere = positive if value >= 0 else negative
    return f"{degrees}:{minutes:02d}:{seconds:02d}{hemisphere}"


def _normalize_chart(data: Any, field: str) -> dict[str, Any]:
    chart = _require_mapping(data, field)
    moment = _resolve_local_moment(chart, field)
    latitude = _number(chart.get("latitude"), f"{field}.latitude")
    longitude = _number(chart.get("longitude"), f"{field}.longitude")
    if abs(latitude) == 90:
        raise RequestError("A latitude exactly at a geographic pole is not supported for house calculations.")
    name = chart.get("name", "")
    place = chart.get("place", "")
    if not isinstance(name, str) or len(name) > 120:
        raise RequestError(f"'{field}.name' must be a string no longer than 120 characters.")
    if not isinstance(place, str) or len(place) > 160:
        raise RequestError(f"'{field}.place' must be a string no longer than 160 characters.")
    metadata = dict(moment["metadata"])
    metadata.update(
        {
            "latitude": latitude,
            "longitude": longitude,
            "coordinate_convention": "east-positive longitude, north-positive latitude",
            "name": name,
            "place": place,
        }
    )
    return {
        "utc": moment["utc"],
        "latitude": latitude,
        "longitude": longitude,
        "metadata": metadata,
    }


def _chart_switches(chart: dict[str, Any]) -> list[str]:
    utc: dt.datetime = chart["utc"]
    return [
        "-qb",
        str(utc.month),
        str(utc.day),
        str(utc.year),
        utc.strftime("%H:%M:%S"),
        "0",
        "0",
        _decimal_to_dms(chart["longitude"], "longitude"),
        _decimal_to_dms(chart["latitude"], "latitude"),
    ]


def _normalize_settings(data: Any) -> dict[str, Any]:
    settings = {} if data is None else _require_mapping(data, "settings")
    zodiac = str(settings.get("zodiac", "tropical")).strip().lower().replace("_", "-")
    if zodiac not in ("tropical", "sidereal"):
        raise RequestError("'settings.zodiac' must be 'tropical' or 'sidereal'.")

    ayanamsa_key = str(settings.get("ayanamsa", "lahiri")).strip().lower().replace("_", "-")
    if zodiac == "sidereal" and ayanamsa_key not in AYANAMSAS:
        raise RequestError(
            "Unsupported ayanamsa. Choose one of: " + ", ".join(sorted(AYANAMSAS))
        )

    house = str(settings.get("house_system", "placidus")).strip().lower().replace("_", "-")
    if house not in HOUSE_SYSTEMS:
        raise RequestError(
            "Unsupported house system. Choose one of: " + ", ".join(sorted(HOUSE_SYSTEMS))
        )

    node_mode = str(settings.get("node_mode", "mean")).strip().lower()
    if node_mode not in ("mean", "true"):
        raise RequestError("'settings.node_mode' must be 'mean' or 'true'.")
    lilith_mode = str(settings.get("lilith_mode", node_mode)).strip().lower()
    if lilith_mode not in ("mean", "true", "natural"):
        raise RequestError("'settings.lilith_mode' must be 'mean', 'true', or 'natural'.")
    if lilith_mode in ("mean", "true") and lilith_mode != node_mode:
        raise RequestError(
            "Astrolog 8.00 couples mean/true Node and Lilith selection. "
            "Use matching node_mode and lilith_mode, or lilith_mode 'natural'."
        )

    ephemeris = str(settings.get("ephemeris_mode", "swiss")).strip().lower()
    if ephemeris not in ("swiss", "moshier"):
        raise RequestError("'settings.ephemeris_mode' must be 'swiss' or 'moshier'.")

    aspect_count = settings.get("aspect_count", 5)
    if isinstance(aspect_count, bool) or not isinstance(aspect_count, int) or not 0 <= aspect_count <= 24:
        raise RequestError("'settings.aspect_count' must be an integer from 0 through 24.")

    requested_objects = settings.get("include_objects", [])
    if not isinstance(requested_objects, list) or not all(isinstance(item, str) for item in requested_objects):
        raise RequestError("'settings.include_objects' must be an array of object names.")
    include_objects: list[str] = []
    for item in requested_objects:
        key = item.strip().lower().replace("_", "-").replace(" ", "-")
        if key == "north-node":
            continue
        if key not in EXTRA_OBJECTS:
            raise RequestError(
                f"Unsupported extra object {item!r}. Choose from: "
                + ", ".join(sorted(EXTRA_OBJECTS))
            )
        if key not in include_objects:
            include_objects.append(key)

    return {
        "zodiac": zodiac,
        "ayanamsa": AYANAMSAS.get(ayanamsa_key) if zodiac == "sidereal" else None,
        "house_system": house,
        "house_system_code": HOUSE_SYSTEMS[house],
        "node_mode": node_mode,
        "lilith_mode": lilith_mode,
        "ephemeris_mode": ephemeris,
        "aspect_count": aspect_count,
        "aspect_orb_profile": "Astrolog 8.00 bundled defaults",
        "include_objects": include_objects,
    }


def _settings_switches(settings: dict[str, Any]) -> list[str]:
    args = ["-c", str(settings["house_system_code"]), "-A", str(settings["aspect_count"])]
    if settings["zodiac"] == "sidereal":
        args.extend(["=s", settings["ayanamsa"]])
    else:
        args.append("_s")
    args.append("=Yn" if settings["node_mode"] == "true" else "_Yn")
    if settings["lilith_mode"] == "natural":
        args.append("=Ynn")
    if settings["ephemeris_mode"] == "moshier":
        args.append("=bs")
    else:
        args.append("=b")
    for name in settings["include_objects"]:
        args.extend(["_R", str(EXTRA_OBJECTS[name])])
    args.append("=b0")
    return args


def _validate_ephemeris(settings: dict[str, Any], years: list[int]) -> list[str]:
    warnings: list[str] = []
    if settings["ephemeris_mode"] == "swiss":
        missing = [year for year in years if year < SWISS_MIN_YEAR or year > SWISS_MAX_YEAR]
        required = ["sepl_18.se1", "semo_18.se1", "seas_18.se1"]
        absent = [name for name in required if not (BUNDLED_RUNTIME / "ephem" / name).is_file()]
        if absent:
            raise EngineError("Required bundled Swiss Ephemeris files are missing: " + ", ".join(absent))
        if missing:
            raise RequestError(
                "The bundled Swiss Ephemeris coverage is limited to years 1800-2399. "
                "Choose settings.ephemeris_mode='moshier' explicitly for this date."
            )
    else:
        warnings.append(
            "Moshier formulas were explicitly selected. Results may differ slightly from Swiss Ephemeris output."
        )
    return warnings


def _view_switches(request: dict[str, Any], default: str = "positions") -> tuple[str, list[str]]:
    view = str(request.get("view", default)).strip().lower().replace("_", "-")
    if view not in VIEW_SWITCHES:
        raise RequestError("Unsupported view. Choose one of: " + ", ".join(sorted(VIEW_SWITCHES)))
    return view, list(VIEW_SWITCHES[view])


def _artifact_name(request: dict[str, Any], default: str, extension: str) -> str:
    output = request.get("output", {})
    if output is None:
        output = {}
    output = _require_mapping(output, "output")
    name = output.get("filename", default)
    if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,79}", name):
        raise RequestError(
            "'output.filename' must contain only letters, digits, underscores, or hyphens (maximum 80 characters)."
        )
    return name + extension


def _prepare_output(output_dir: str | None, filename: str) -> Path:
    if not output_dir:
        raise RequestError("This output format requires the --output-dir option.")
    directory = Path(output_dir).expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)
    target = (directory / filename).resolve()
    if target.parent != directory:
        raise RequestError("Output filename escapes the requested output directory.")
    if target.exists():
        raise RequestError(f"Refusing to overwrite existing output: {target}")
    return target


def _parse_position_file(path: Path) -> dict[str, Any]:
    content = path.read_text(encoding="utf-8", errors="strict")
    if "@AP800" not in content:
        raise EngineError("Astrolog position export is missing its expected @AP800 header.")
    positions: list[dict[str, Any]] = []
    houses: list[dict[str, Any]] = []
    angles: dict[str, dict[str, Any]] = {}
    for line in content.splitlines():
        match = POSITION_RE.match(line.strip())
        if not match:
            continue
        key, degree_text, sign, minute_text, lat_degree_text, lat_minute_text, velocity_text, distance_text = match.groups()
        if sign not in SIGN_INDEX:
            raise EngineError(f"Unknown zodiac sign abbreviation in Astrolog output: {sign}")
        degree = int(degree_text)
        minutes = float(minute_text)
        longitude = SIGN_INDEX[sign] * 30 + degree + minutes / 60.0
        lat_degrees = int(lat_degree_text)
        lat_minutes = float(lat_minute_text)
        if lat_degrees < 0 or (lat_degrees == 0 and lat_minutes < 0):
            latitude = -abs(lat_degrees) - abs(lat_minutes) / 60.0
        else:
            latitude = abs(lat_degrees) + abs(lat_minutes) / 60.0
        record = {
            "source_name": key,
            "sign": SIGN_NAMES[SIGN_INDEX[sign]],
            "sign_abbreviation": sign,
            "degree_in_sign": degree + minutes / 60.0,
            "longitude": longitude,
            "latitude": latitude,
            "velocity": float(velocity_text),
            "retrograde": float(velocity_text) < 0,
            "distance_au": float(distance_text),
        }
        if key in CUSP_NAMES:
            house_number = CUSP_NAMES[key]
            cusp = dict(record)
            cusp["house"] = house_number
            houses.append(cusp)
            if key in ("Asce", "Midh"):
                angle_name = {"Asce": "Ascendant", "Midh": "Midheaven"}[key]
                angles[angle_name] = record
        else:
            record["name"] = BODY_NAMES.get(key, key)
            positions.append(record)
    if not positions or len(houses) != 12:
        raise EngineError("Astrolog position export could not be normalized completely.")
    houses.sort(key=lambda item: item["house"])
    if "Ascendant" in angles:
        descendant = dict(angles["Ascendant"])
        descendant_longitude = (descendant["longitude"] + 180.0) % 360.0
        descendant_sign = int(descendant_longitude // 30)
        descendant.update(
            {
                "source_name": "Derived from Ascendant",
                "sign": SIGN_NAMES[descendant_sign],
                "sign_abbreviation": list(SIGN_INDEX)[descendant_sign],
                "degree_in_sign": descendant_longitude % 30,
                "longitude": descendant_longitude,
            }
        )
        angles["Descendant"] = descendant
    if "Midheaven" in angles:
        ic = dict(angles["Midheaven"])
        ic_longitude = (ic["longitude"] + 180.0) % 360.0
        ic_sign = int(ic_longitude // 30)
        ic.update(
            {
                "source_name": "Derived from Midheaven",
                "sign": SIGN_NAMES[ic_sign],
                "sign_abbreviation": list(SIGN_INDEX)[ic_sign],
                "degree_in_sign": ic_longitude % 30,
                "longitude": ic_longitude,
            }
        )
        angles["IC"] = ic
    return {"positions": positions, "houses": houses, "angles": angles}


def _export_positions(chart: dict[str, Any], settings: dict[str, Any], temporary: Path) -> tuple[dict[str, Any], str]:
    position_path = temporary / "positions.as"
    args = _chart_switches(chart) + _settings_switches(settings) + ["=v", "-o0", str(position_path)]
    raw = _run_astrolog(args)
    if not position_path.is_file():
        raise EngineError("Astrolog did not create the expected normalized-position export.")
    normalized = _parse_position_file(position_path)

    cusp_path = temporary / "cusps.as"
    cusp_args = _chart_switches(chart) + _settings_switches(settings) + ["=Yc", "=v", "-o0", str(cusp_path)]
    _run_astrolog(cusp_args)
    if not cusp_path.is_file():
        raise EngineError("Astrolog did not create the expected house-cusp export.")
    cusp_normalized = _parse_position_file(cusp_path)
    normalized["houses"] = cusp_normalized["houses"]
    return normalized, raw


def _write_chart_file(chart: dict[str, Any], settings: dict[str, Any], path: Path) -> None:
    args = _chart_switches(chart) + _settings_switches(settings) + ["-o", str(path)]
    _run_astrolog(args)
    if not path.is_file() or "@AI" not in path.read_text(encoding="utf-8", errors="replace"):
        raise EngineError("Astrolog did not create the expected chart data file.")


def _validate_svg(path: Path) -> dict[str, list[float]]:
    if not path.is_file() or path.stat().st_size > MAX_GRAPHIC_BYTES:
        raise EngineError("SVG output is missing or exceeds the size limit.")
    text = path.read_text(encoding="utf-8", errors="strict")
    lowered = text.lower()
    if "<!doctype" in lowered or "<script" in lowered or "href=\"http" in lowered or "href='http" in lowered:
        raise EngineError("SVG output contains disallowed active or external content.")
    root = ET.fromstring(text)
    if not root.tag.endswith("svg"):
        raise EngineError("Astrolog output is not a valid SVG document.")
    view_box_text = root.attrib.get("viewBox", "")
    try:
        view_box = [float(item) for item in view_box_text.split()]
    except ValueError as exc:
        raise EngineError("SVG output has an invalid viewBox.") from exc
    if len(view_box) != 4 or not all(math.isfinite(item) for item in view_box) or view_box[2] <= 0 or view_box[3] <= 0:
        raise EngineError("SVG output has an invalid viewBox.")
    return {"view_box": view_box}


def _validate_png(path: Path) -> dict[str, int]:
    if not path.is_file() or path.stat().st_size > MAX_GRAPHIC_BYTES:
        raise EngineError("PNG output is missing or exceeds the size limit.")
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise EngineError("Astrolog output is not a valid PNG file.")
    width, height = struct.unpack(">II", header[16:24])
    if width > 2200 or height > 2200:
        raise EngineError("PNG output exceeds the dimension limit.")
    return {"width": width, "height": height}


def _graphic_switches(request: dict[str, Any], temporary: Path) -> tuple[list[str], Path, str]:
    output = request.get("output", {}) or {}
    output = _require_mapping(output, "output")
    output_format = str(output.get("format", "text")).strip().lower()
    if output_format not in ("text", "svg", "png"):
        raise RequestError("'output.format' must be 'text', 'svg', or 'png'.")
    if output_format == "text":
        return [], temporary / "unused.txt", output_format
    width = output.get("width", 900)
    height = output.get("height", 900)
    if isinstance(width, bool) or not isinstance(width, int) or not 400 <= width <= 1600:
        raise RequestError("'output.width' must be an integer from 400 through 1600.")
    if isinstance(height, bool) or not isinstance(height, int) or not 400 <= height <= 1600:
        raise RequestError("'output.height' must be an integer from 400 through 1600.")
    extension = ".svg" if output_format == "svg" else ".png"
    path = temporary / ("chart" + extension)
    args = ["=X", "=Xr", "-Xw", str(width), str(height)]
    args.append("-XV" if output_format == "svg" else "-Xbp")
    args.extend(["-Xo", str(path)])
    return args, path, output_format


def _copy_graphic(
    request: dict[str, Any],
    temp_path: Path,
    output_format: str,
    output_dir: str | None,
    default_name: str,
) -> dict[str, Any]:
    if output_format == "svg":
        extra: dict[str, Any] = _validate_svg(temp_path)
        extension = ".svg"
    elif output_format == "png":
        extra = _validate_png(temp_path)
        extension = ".png"
    else:
        raise AssertionError(output_format)
    target = _prepare_output(output_dir, _artifact_name(request, default_name, extension))
    shutil.copy2(temp_path, target)
    artifact = {
        "type": output_format,
        "path": str(target),
        "bytes": target.stat().st_size,
        "sha256": _sha256(target),
        "requested_width": request.get("output", {}).get("width", 900),
        "requested_height": request.get("output", {}).get("height", 900),
    }
    artifact.update(extra)
    return artifact


def _base_response(operation: str, settings: dict[str, Any] | None = None) -> dict[str, Any]:
    runtime = _runtime()
    response: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "ok": True,
        "operation": operation,
        "engine": {
            "name": "Astrolog",
            "version": ENGINE_VERSION,
            "source_commit": SOURCE_COMMIT,
            "execution": "local-offline",
            "binary_sha256": _sha256(runtime / "astrolog"),
            "platform": platform.platform(),
        },
        "warnings": [],
        "artifacts": [],
    }
    if settings is not None:
        response["settings"] = settings
    return response


def _operation_natal(request: dict[str, Any], output_dir: str | None) -> dict[str, Any]:
    chart = _normalize_chart(request.get("chart"), "chart")
    settings = _normalize_settings(request.get("settings"))
    warnings = _validate_ephemeris(settings, [chart["utc"].year])
    view, view_args = _view_switches(request)
    response = _base_response("natal", settings)
    response["chart"] = chart["metadata"]
    response["view"] = view
    response["warnings"].extend(warnings)

    with tempfile.TemporaryDirectory(prefix="astrolog-calc-") as temp_name:
        temporary = Path(temp_name)
        normalized, position_raw = _export_positions(chart, settings, temporary)
        graphic_args, graphic_path, output_format = _graphic_switches(request, temporary)
        if output_format == "text":
            raw = position_raw if view == "positions" else _run_astrolog(
                _chart_switches(chart) + _settings_switches(settings) + view_args
            )
            if output_dir:
                text_path = _prepare_output(output_dir, _artifact_name(request, "natal-chart", ".txt"))
                text_path.write_text(raw + "\n", encoding="utf-8")
                response["artifacts"].append(
                    {"type": "text", "path": str(text_path), "bytes": text_path.stat().st_size, "sha256": _sha256(text_path)}
                )
        else:
            raw = _run_astrolog(_chart_switches(chart) + _settings_switches(settings) + graphic_args)
            response["artifacts"].append(
                _copy_graphic(request, graphic_path, output_format, output_dir, "natal-chart")
            )
        response["result"] = {**normalized, "raw_text": raw}
    return response


def _target_moment(request: dict[str, Any]) -> dict[str, Any]:
    return _resolve_local_moment(_require_mapping(request.get("target"), "target"), "target")


def _validate_text_only_output(request: dict[str, Any], operation: str) -> None:
    output = request.get("output", {}) or {}
    output = _require_mapping(output, "output")
    output_format = str(output.get("format", "text")).strip().lower()
    if output_format != "text":
        raise RequestError(f"'{operation}' supports text output only.")


def _operation_transits(request: dict[str, Any], output_dir: str | None) -> dict[str, Any]:
    chart = _normalize_chart(request.get("chart"), "chart")
    target = _target_moment(request)
    settings = _normalize_settings(request.get("settings"))
    mode = str(request.get("mode", "snapshot")).strip().lower()
    if mode not in ("snapshot", "month"):
        raise RequestError("Transit mode must be 'snapshot' or 'month'.")
    _validate_text_only_output(request, "transits")
    target_year = target["utc"].year if mode == "snapshot" else target["local"].year
    warnings = _validate_ephemeris(settings, [chart["utc"].year, target_year])
    response = _base_response("transits", settings)
    response["chart"] = chart["metadata"]
    response["target"] = target["metadata"]
    response["mode"] = mode
    response["warnings"].extend(warnings)
    with tempfile.TemporaryDirectory(prefix="astrolog-calc-") as temp_name:
        temporary = Path(temp_name)
        chart_file = temporary / "natal.as"
        _write_chart_file(chart, settings, chart_file)
        utc: dt.datetime = target["utc"]
        args = ["-z", "0", "-z0", "0", "-i", str(chart_file)] + _settings_switches(settings)
        if mode == "snapshot":
            args += ["-Tt", str(utc.month), str(utc.day), str(utc.year), utc.strftime("%H:%M:%S")]
        else:
            local: dt.datetime = target["local"]
            response["search_month_local"] = f"{local.year:04d}-{local.month:02d}"
            args += ["-t", str(local.month), str(local.year)]
        raw = _run_astrolog(args, timeout=60)
        response["result"] = {"raw_text": raw, "timescale": "UTC"}
        if output_dir:
            target_path = _prepare_output(output_dir, _artifact_name(request, "transits", ".txt"))
            target_path.write_text(raw + "\n", encoding="utf-8")
            response["artifacts"].append(
                {"type": "text", "path": str(target_path), "bytes": target_path.stat().st_size, "sha256": _sha256(target_path)}
            )
    return response


def _operation_progression(request: dict[str, Any], output_dir: str | None) -> dict[str, Any]:
    chart = _normalize_chart(request.get("chart"), "chart")
    target = _target_moment(request)
    settings = _normalize_settings(request.get("settings"))
    warnings = _validate_ephemeris(settings, [chart["utc"].year, target["utc"].year])
    method = str(request.get("method", "secondary")).strip().lower().replace("_", "-")
    if method not in ("secondary", "solar-arc"):
        raise RequestError("Progression method must be 'secondary' or 'solar-arc'.")
    view, view_args = _view_switches(request)
    response = _base_response("progression", settings)
    response["chart"] = chart["metadata"]
    response["target"] = target["metadata"]
    response["method"] = method
    response["view"] = view
    response["warnings"].extend(warnings)
    with tempfile.TemporaryDirectory(prefix="astrolog-calc-") as temp_name:
        temporary = Path(temp_name)
        chart_file = temporary / "natal.as"
        _write_chart_file(chart, settings, chart_file)
        utc: dt.datetime = target["utc"]
        progression_switch = "-pt" if method == "secondary" else "-p0t"
        base = ["-z", "0", "-z0", "0", "-i", str(chart_file)] + _settings_switches(settings)
        base += [progression_switch, str(utc.month), str(utc.day), str(utc.year), utc.strftime("%H:%M:%S")]
        graphic_args, graphic_path, output_format = _graphic_switches(request, temporary)
        args = base + (view_args if output_format == "text" else graphic_args)
        raw = _run_astrolog(args)
        response["result"] = {"raw_text": raw, "timescale": "UTC"}
        if output_format == "text" and output_dir:
            target_path = _prepare_output(output_dir, _artifact_name(request, "progressed-chart", ".txt"))
            target_path.write_text(raw + "\n", encoding="utf-8")
            response["artifacts"].append(
                {"type": "text", "path": str(target_path), "bytes": target_path.stat().st_size, "sha256": _sha256(target_path)}
            )
        elif output_format != "text":
            response["artifacts"].append(
                _copy_graphic(request, graphic_path, output_format, output_dir, "progressed-chart")
            )
    return response


def _operation_returns(request: dict[str, Any], output_dir: str | None) -> dict[str, Any]:
    chart = _normalize_chart(request.get("chart"), "chart")
    target = _target_moment(request)
    settings = _normalize_settings(request.get("settings"))
    _validate_text_only_output(request, "returns")
    local: dt.datetime = target["local"]
    warnings = _validate_ephemeris(settings, [chart["utc"].year, local.year])
    response = _base_response("returns", settings)
    response["chart"] = chart["metadata"]
    response["target"] = target["metadata"]
    response["warnings"].extend(warnings)
    with tempfile.TemporaryDirectory(prefix="astrolog-calc-") as temp_name:
        temporary = Path(temp_name)
        chart_file = temporary / "natal.as"
        _write_chart_file(chart, settings, chart_file)
        args = ["-z", "0", "-z0", "0", "-i", str(chart_file)] + _settings_switches(settings)
        response["search_month_local"] = f"{local.year:04d}-{local.month:02d}"
        args += ["-tr", str(local.month), str(local.year)]
        raw = _run_astrolog(args, timeout=60)
        response["result"] = {"raw_text": raw, "timescale": "UTC"}
        if output_dir:
            target_path = _prepare_output(output_dir, _artifact_name(request, "returns", ".txt"))
            target_path.write_text(raw + "\n", encoding="utf-8")
            response["artifacts"].append(
                {"type": "text", "path": str(target_path), "bytes": target_path.stat().st_size, "sha256": _sha256(target_path)}
            )
    return response


def _operation_relationship(request: dict[str, Any], output_dir: str | None) -> dict[str, Any]:
    chart1 = _normalize_chart(request.get("chart"), "chart")
    chart2 = _normalize_chart(request.get("chart2"), "chart2")
    settings = _normalize_settings(request.get("settings"))
    warnings = _validate_ephemeris(settings, [chart1["utc"].year, chart2["utc"].year])
    relationship_type = str(request.get("relationship_type", "synastry")).strip().lower()
    if relationship_type not in RELATIONSHIP_SWITCHES:
        raise RequestError(
            "Unsupported relationship_type. Choose one of: " + ", ".join(sorted(RELATIONSHIP_SWITCHES))
        )
    view, view_args = _view_switches(request, default="aspects")
    response = _base_response("relationship", settings)
    response["chart"] = chart1["metadata"]
    response["chart2"] = chart2["metadata"]
    response["relationship_type"] = relationship_type
    response["view"] = view
    response["warnings"].extend(warnings)
    with tempfile.TemporaryDirectory(prefix="astrolog-calc-") as temp_name:
        temporary = Path(temp_name)
        file1 = temporary / "chart1.as"
        file2 = temporary / "chart2.as"
        _write_chart_file(chart1, settings, file1)
        _write_chart_file(chart2, settings, file2)
        base = [RELATIONSHIP_SWITCHES[relationship_type], str(file1), str(file2)] + _settings_switches(settings)
        graphic_args, graphic_path, output_format = _graphic_switches(request, temporary)
        args = base + (view_args if output_format == "text" else graphic_args)
        raw = _run_astrolog(args)
        response["result"] = {"raw_text": raw}
        if output_format == "text" and output_dir:
            target_path = _prepare_output(output_dir, _artifact_name(request, "relationship-chart", ".txt"))
            target_path.write_text(raw + "\n", encoding="utf-8")
            response["artifacts"].append(
                {"type": "text", "path": str(target_path), "bytes": target_path.stat().st_size, "sha256": _sha256(target_path)}
            )
        elif output_format != "text":
            response["artifacts"].append(
                _copy_graphic(request, graphic_path, output_format, output_dir, "relationship-chart")
            )
    return response


def _operation_astrocartography(request: dict[str, Any], output_dir: str | None) -> dict[str, Any]:
    request = dict(request)
    request["view"] = "astrocartography"
    chart = _normalize_chart(request.get("chart"), "chart")
    settings = _normalize_settings(request.get("settings"))
    warnings = _validate_ephemeris(settings, [chart["utc"].year])
    response = _base_response("astrocartography", settings)
    response["chart"] = chart["metadata"]
    response["warnings"].extend(warnings)
    with tempfile.TemporaryDirectory(prefix="astrolog-calc-") as temp_name:
        temporary = Path(temp_name)
        graphic_args, graphic_path, output_format = _graphic_switches(request, temporary)
        args = _chart_switches(chart) + _settings_switches(settings) + ["-L"]
        if output_format != "text":
            args += graphic_args
        raw = _run_astrolog(args)
        response["result"] = {"raw_text": raw}
        if output_format == "text" and output_dir:
            target_path = _prepare_output(output_dir, _artifact_name(request, "astrocartography", ".txt"))
            target_path.write_text(raw + "\n", encoding="utf-8")
            response["artifacts"].append(
                {"type": "text", "path": str(target_path), "bytes": target_path.stat().st_size, "sha256": _sha256(target_path)}
            )
        elif output_format != "text":
            response["artifacts"].append(
                _copy_graphic(request, graphic_path, output_format, output_dir, "astrocartography")
            )
    return response


def _capabilities() -> dict[str, Any]:
    response = _base_response("capabilities")
    response["capabilities"] = {
        "operations": ["natal", "transits", "progression", "returns", "relationship", "astrocartography", "self-test"],
        "views": sorted(VIEW_SWITCHES),
        "graphics": ["svg", "png"],
        "zodiacs": ["tropical", "sidereal"],
        "ayanamsas": sorted(AYANAMSAS),
        "house_systems": sorted(HOUSE_SYSTEMS),
        "relationship_types": sorted(RELATIONSHIP_SWITCHES),
        "extra_objects": sorted(EXTRA_OBJECTS),
        "ephemeris_modes": ["swiss", "moshier"],
        "bundled_swiss_year_range": [SWISS_MIN_YEAR, SWISS_MAX_YEAR],
    }
    return response


def _angular_difference(a: float, b: float) -> float:
    return abs((a - b + 180) % 360 - 180)


def _self_test() -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    runtime = _runtime()
    checks.append({"name": "version", "passed": _probe_runtime(runtime)})
    fixture_request = {
        "chart": {
            "date": "1996-10-12",
            "time": "16:56:00",
            "timezone": "America/New_York",
            "latitude": 34.8526,
            "longitude": -82.3940,
        },
        "settings": {"zodiac": "sidereal", "ayanamsa": "lahiri", "house_system": "whole-sign"},
    }
    chart = _normalize_chart(fixture_request["chart"], "chart")
    settings = _normalize_settings(fixture_request["settings"])
    with tempfile.TemporaryDirectory(prefix="astrolog-self-test-") as temp_name:
        normalized, _ = _export_positions(chart, settings, Path(temp_name))
    by_name = {item["name"]: item for item in normalized["positions"]}
    expected = {"Sun": 175.9932, "Moon": 179.2889, "Mercury": 162.1222}
    for name, expected_longitude in expected.items():
        actual = by_name[name]["longitude"]
        checks.append(
            {
                "name": f"fixture-{name.lower()}",
                "passed": _angular_difference(actual, expected_longitude) < 0.02,
                "actual_longitude": actual,
                "expected_longitude": expected_longitude,
                "tolerance_degrees": 0.02,
            }
        )
    checks.append(
        {
            "name": "timezone-conversion",
            "passed": chart["metadata"]["utc_datetime"] == "1996-10-12T20:56:00Z",
            "actual": chart["metadata"]["utc_datetime"],
        }
    )
    response = _base_response("self-test")
    response["checks"] = checks
    response["passed"] = all(check["passed"] for check in checks)
    response["ok"] = response["passed"]
    return response


def execute(request: dict[str, Any], output_dir: str | None = None) -> dict[str, Any]:
    if not isinstance(request, dict):
        raise RequestError("The request root must be a JSON object.")
    version = str(request.get("schema_version", SCHEMA_VERSION))
    if version != SCHEMA_VERSION:
        raise RequestError(f"Unsupported schema_version {version!r}; expected {SCHEMA_VERSION!r}.")
    operation = str(request.get("operation", "")).strip().lower().replace("_", "-")
    aliases = {"chart": "natal", "return-search": "returns", "solar-arc": "progression"}
    operation = aliases.get(operation, operation)
    if operation == "natal":
        return _operation_natal(request, output_dir)
    if operation == "transits":
        return _operation_transits(request, output_dir)
    if operation == "progression":
        if str(request.get("operation", "")).strip().lower().replace("_", "-") == "solar-arc":
            request = dict(request)
            request["method"] = "solar-arc"
        return _operation_progression(request, output_dir)
    if operation == "returns":
        return _operation_returns(request, output_dir)
    if operation == "relationship":
        return _operation_relationship(request, output_dir)
    if operation == "astrocartography":
        return _operation_astrocartography(request, output_dir)
    if operation in ("capabilities", "version"):
        return _capabilities()
    if operation == "self-test":
        return _self_test()
    raise RequestError(
        "Unsupported operation. Choose natal, transits, progression, returns, relationship, astrocartography, capabilities, or self-test."
    )


def _load_request(path: str) -> dict[str, Any]:
    request_path = Path(path)
    if not request_path.is_file():
        raise RequestError(f"Request file does not exist: {request_path}")
    if request_path.stat().st_size > MAX_REQUEST_BYTES:
        raise RequestError("Request JSON exceeds the 256 KiB size limit.")
    try:
        value = json.loads(request_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RequestError(f"Request file is not valid UTF-8 JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise RequestError("Request JSON root must be an object.")
    return value


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the local Astrolog 8.00 calculation skill safely.")
    parser.add_argument("--request", help="Path to a UTF-8 JSON request file")
    parser.add_argument("--output-dir", help="Directory for requested text or graphic artifacts")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print the JSON response")
    parser.add_argument("--self-test", action="store_true", help="Run the deterministic built-in self-test")
    parser.add_argument("--capabilities", action="store_true", help="List supported operations and settings")
    args = parser.parse_args(argv)

    try:
        if args.self_test:
            request = {"operation": "self-test"}
        elif args.capabilities:
            request = {"operation": "capabilities"}
        elif args.request:
            request = _load_request(args.request)
        else:
            raise RequestError("Supply --request, --self-test, or --capabilities.")
        response = execute(request, args.output_dir)
        print(json.dumps(response, indent=2 if args.pretty else None, sort_keys=True))
        return 0 if response.get("ok") else 3
    except RequestError as exc:
        print(json.dumps({"schema_version": SCHEMA_VERSION, "ok": False, "error_type": "request", "error": str(exc)}, sort_keys=True))
        return 2
    except EngineError as exc:
        print(json.dumps({"schema_version": SCHEMA_VERSION, "ok": False, "error_type": "engine", "error": str(exc)}, sort_keys=True))
        return 3
    except Exception as exc:  # Fail closed while keeping stdout machine-readable.
        print(json.dumps({"schema_version": SCHEMA_VERSION, "ok": False, "error_type": "internal", "error": str(exc)}, sort_keys=True))
        return 4


if __name__ == "__main__":
    raise SystemExit(main())
