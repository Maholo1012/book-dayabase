# Operation map

Use the JSON wrapper; these are request choices, not raw Astrolog command-line switches.

| User intent | `operation` | Additional fields | Output |
|---|---|---|---|
| Natal or event chart | `natal` | `chart`, optional `view` | Normalized positions/houses/angles; text, SVG, or PNG |
| Transit at a moment | `transits` | `chart`, `target`, `mode: snapshot` | Text report |
| Monthly transits | `transits` | `chart`, `target`, `mode: month` | Text report |
| Secondary progression | `progression` | `chart`, `target`, `method: secondary` | Text, SVG, or PNG |
| Solar arc | `progression` | `chart`, `target`, `method: solar-arc` | Text, SVG, or PNG |
| Return search | `returns` | `chart`, `target` | Monthly text report |
| Synastry | `relationship` | `chart`, `chart2`, `relationship_type: synastry` | Text, SVG, or PNG |
| Two-wheel comparison | `relationship` | `chart`, `chart2`, `relationship_type: comparison` | Text, SVG, or PNG |
| Composite chart | `relationship` | `chart`, `chart2`, `relationship_type: composite` | Text, SVG, or PNG |
| Davison chart | `relationship` | `chart`, `chart2`, `relationship_type: davison` | Text, SVG, or PNG |
| Astrocartography | `astrocartography` | `chart` | Text, SVG, or PNG |
| Runtime verification | `self-test` | none | Deterministic JSON checks |
| Feature discovery | `capabilities` | none | Supported values as JSON |

For a text-oriented chart operation, choose one `view`: `positions`, `aspects`, `aspect-grid`, `midpoints`, `wheel-text`, `horizon`, or `astrocartography`. The default is `positions` for natal/progression and `aspects` for relationship charts.

The wrapper deliberately does not expose arbitrary Astrolog switches, configuration files, network access, interactive mode, or shell expansion. If a requested feature is absent from `--capabilities`, explain that it is not implemented instead of bypassing the wrapper.
