import assert from 'node:assert/strict';
import test from 'node:test';

import {
  buildResult,
  parseArgs,
  parseUtcOffset,
  shiftWallTime,
} from './chart.mjs';

test('parses supported CLI values', () => {
  assert.deepEqual(
    parseArgs(['--date', '1990-06-15', '--time', '14:30', '--timezone', 'Asia/Shanghai', '--compact']),
    {
      date: '1990-06-15',
      time: '14:30',
      timezone: 'Asia/Shanghai',
      compact: true,
    },
  );
  assert.equal(parseUtcOffset('+05:30'), 5.5);
  assert.equal(parseUtcOffset('-4'), -4);
});

test('shifts a local wall time across a date boundary', () => {
  assert.deepEqual(
    shiftWallTime('2000-01-01', '00:15', -30),
    { date: '1999-12-31', time: '23:45' },
  );
});

test('builds a complete deterministic chart summary', () => {
  const result = buildResult({
    date: '1990-06-15',
    time: '14:30',
    'utc-offset': '-5',
    name: 'Regression Sample',
  });

  assert.equal(result.subject.name, 'Regression Sample');
  assert.equal(result.subject.utcOffsetHours, -5);
  assert.equal(result.calculation.engine, 'natalengine 1.6.0');
  assert.match(result.calculation.trustChain.ephemeris, /astronomy-engine 2\.1\.19/);
  assert.match(result.calculation.trustChain.mode, /no remote chart database/);
  assert.equal(result.calculation.trustChain.officialJovianArchiveEngine, false);
  assert.equal(result.calculation.nodeType, 'true');
  assert.equal(result.foundations.type, 'Manifestor');
  assert.equal(result.foundations.strategy, 'Inform');
  assert.equal(result.foundations.authority, 'Emotional Authority');
  assert.equal(result.foundations.profile, '2/5');
  assert.deepEqual(result.channels.map((channel) => channel.key), ['12-22', '13-33']);
  assert.equal(result.centers.defined.length + result.centers.allUndefined.length, 9);
  assert.ok(result.centers.open.every((center) => result.centers.allUndefined.includes(center)));
  assert.ok(result.activations.personality.length >= 13);
  assert.ok(result.activations.design.length >= 13);
  assert.equal(result.sensitivity.checked, false);
});

test('reports whether core fields change inside an uncertainty window', () => {
  const result = buildResult({
    date: '1990-06-15',
    time: '14:30',
    timezone: 'America/New_York',
    'uncertainty-minutes': '30',
  });

  assert.equal(result.sensitivity.checked, true);
  assert.equal(result.sensitivity.windowMinutes, 30);
  assert.equal(result.subject.utcOffsetHours, -4);
  assert.equal(typeof result.sensitivity.stable, 'boolean');
  assert.equal(result.sensitivity.range.earlier.time, '14:00');
  assert.equal(result.sensitivity.range.later.time, '15:00');
});
